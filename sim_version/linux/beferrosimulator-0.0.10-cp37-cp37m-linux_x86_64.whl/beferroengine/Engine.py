from random import sample
from torch import nan
import torch
import numpy as np
import pdb
import time as tt
import warnings
import os
from torch._C import dtype
from tqdm import tqdm                 #pip install tqdm
import bz2
from decimal import Decimal 
import beferrosimulatorcuda as beferro
import pickle
import requests
import shutil
import json
from scipy import integrate
import scipy.special as scifun
import gc



import matplotlib.pyplot as plt

def CHECKTENSOR(tens, precision=torch.double, device='cuda'):
    if not torch.is_tensor(tens):
        return torch.tensor(tens, dtype=precision, device=device)
    else:
        return tens.to(precision).to(device)


########################################### USER FUNCTION TO GET THE CHARGE #####################################
def standard_get_fix_charge(contest, index):
    #in case of fixed charge index is useless
    return contest.sigmarow

def _Qset_from_output(contest, index):
    return contest.Qt_set[:, :, index].transpose(0,1).flatten()

#################################################################################################################

class Seed:
    def __init__(self, engine):
        #control parameters
        self.row                                = CHECKTENSOR(engine.row).clone()
        self.col                                = CHECKTENSOR(engine.col).clone()
        self.a                                  = CHECKTENSOR(engine.a).clone()
        self.b                                  = CHECKTENSOR(engine.b).clone()
        self.c                                  = CHECKTENSOR(engine.c).clone()
        self.d                                  = CHECKTENSOR(engine.d).clone()
        self.t_F                                = CHECKTENSOR(engine.t_F).clone()
        self.t_D                                = CHECKTENSOR(engine.t_D).clone()
        self.Vstart                             = CHECKTENSOR(engine.V[0]).item()
        self.set_cluster                        = engine.set_cluster
        self.clusterFE                          = engine.clusterFE

        #save parameters
        self.Pstart                             = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.Ec_dist                            = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.Pc_dist                            = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        if engine.AFE == 0:
            self.Pr_dist                        = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        else:
            self.Pb_dist                        = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        if engine.AFE == 1 and engine.numberofparam == 4:
            self.Eb_dist                        = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.a_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.b_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.c_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.d_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)


    def copy_seed(self, engine):
        #control parameters
        self.row                                = CHECKTENSOR(engine.row).clone()
        self.col                                = CHECKTENSOR(engine.col).clone()
        self.a                                  = CHECKTENSOR(engine.a).clone()
        self.b                                  = CHECKTENSOR(engine.b).clone()
        self.c                                  = CHECKTENSOR(engine.c).clone()
        self.d                                  = CHECKTENSOR(engine.d).clone()
        self.t_F                                = CHECKTENSOR(engine.t_F).clone()
        self.t_D                                = CHECKTENSOR(engine.t_D).clone()
        self.Vstart                             = CHECKTENSOR(engine.V[0]).item()
        self.set_cluster                        = engine.set_cluster
        self.clusterFE                         = engine.clusterFE

        #save parameters
        self.Pstart                             = CHECKTENSOR(engine.seed.Pstart).clone()
        self.Ec_dist                            = CHECKTENSOR(engine.seed.Ec_dist).clone()
        self.Pr_dist                            = CHECKTENSOR(engine.seed.Pr_dist).clone()
        self.Pc_dist                            = CHECKTENSOR(engine.seed.Pc_dist).clone()
        self.a_eff                              = CHECKTENSOR(engine.seed.a_eff).clone()
        self.b_eff                              = CHECKTENSOR(engine.seed.b_eff).clone()
        self.c_eff                              = CHECKTENSOR(engine.seed.c_eff).clone()
        self.d_eff                              = CHECKTENSOR(engine.seed.d_eff).clone()
    
    def is_compatible(self, engine):
        return (self.row == engine.row.cpu() and self.col == engine.col.cpu() and self.a == engine.a.cpu() and self.b == engine.b.cpu() and self.c == engine.c.cpu() and self.d == engine.d.cpu() and self.t_F == engine.t_F.cpu() and self.t_D == engine.t_D.cpu() and self.set_cluster == engine.set_cluster and self.clusterFE == engine.clusterFE)


class Engine:

    @torch.no_grad()
    def __init__(self, device='cuda', precision=torch.double):
        #print("Ciao Suzanne and Justine :)")
        self.device                             = device
        self.precision                          = precision    
        ## Paths        
        #path of var saving file        
        self.var_saving_path                    = 'vars/var.pkl'
        #path to save initialization var        iables 
        self.var_seed_path                      = 'vars/seed.pkl'
        #name file of Specogna program (        generated in init_params)
        self.struct_file_name                   = ''
        #path where the specogna program         is located in self PC (absolute is
        #better)        
        self.path_specogna                      = 'C:\\ngsolver\\specogna\\newistance\\'

        self.seed                               = None # MUST be implemented with Seed(self)
                
        ## General constants        
        self.Temp                               = 300                       # [K] temperature
        self.q                                  = 1.60217662e-19            # [C] fundamental charge value
        self.eps0                               = 8.8541878128e-12          # [F/m] Vacuum permittivity
        self.h_r                                = 1.05457168e-34            # [J*s] Planck's reduced constant
        self.Kb                                 = 1.380649e-23              # [J/K] Boltzmann const
        self.m0                                 = 9.109383e-31              # [Kg] Free-electron mass
        
            #   # Simulator Parameters      
        self.theta                              = 0.5                       # theta parameter 0.5=trapez, 1=Euler implicit
        self.structure_type                     = 1                         # 0=>'MFM', 1=>'MFIM', 2=>'MFMIM'
        self.distr_type                         = 'distrab'                 # 'distrab' or 'distrecpc'. realization control parameter
        self.bound_cond                         = 1                         # 'standard' = 0 or 'periodic' = 1
        self.traps                              = 0                         # 'none' = 0, 'static'= 1, 'dynamic (Nanoscale 2020)' = 2, 
                                                                            # 'dynimatic with tunneling' = 3, 'dynamic with tunneling, improved' = 4
        self.enable_integral                    = False                     # Enable the integral version for JMF and JMD (engine.traps == 3 only)

        self.var_J                              = 1e-7                     #epsilon for Jacobian calculation
                
        self.row                                = 6                         # Number of rows of domains
        self.col                                = 6                         # Number of columns of domains
        self.numberofparam                      = 2                         # Number of LKE parameters (alpha, beta, gamma)
        self.t_step                             = 0                         # Time step of the simulation
        #tunnelling parameters      
        self.energy_disc_tunnel                 = 300
        self.length_disc_tunnel                 = 600
                
                
        ## WKB and Band parameters      
        self.mu                                 = 1                         # Electrodes multiplicity
        self.WF_T                               = 4.45 *1.60217662e-19#*q	# [J] Work function top electrode (fe)
        self.WF_B                               = 4.45 *1.60217662e-19#*q	# [J] Work function bottom electrode (ox)
        self.Chi_fe                             = 2.1 *1.60217662e-19#*q	# [J] Electron affinity Ferroel
        self.Chi_ox                             = 1.35 *1.60217662e-19#*q	# [J] Electron affinity ox
        self.m_eff_fe                           = 0.3 *9.109383E-31#*m0     # [Kg] Effective mass ferroel
        self.m_eff_ox                           = 0.2 *9.109383E-31#*m0     # [Kg] Effective mass oxide
        
        
        ## General Model Constants
        self.rho                                = 300e-3                    # [Ohm*m] Damping constant/nominal resistivity of ferroel
        self.k_coupl                            = 2e-10#2e-9                # [m3/F] Domain wall factor     
        self.sigma                              = 0*-0.13                   # [C/m2] Fixed interface charge

        ## ferroelectric parameters
        self.t_F                                = 18.2e-9                   # [m] Ferroelectric thickness
        self.w                                  = 0.5e-9                    # energy-wall size [m]
        self.dd                                 = 5e-9                      # domain size [m]
        self.epsF                               = 33                        # Ferroelectric relative permittivity

        ## Oxide parameters (if Cs_th is set to zero, no oxide layer is considered)
        self.epsD                              = 8                         # Oxide relative permittivity
        self.t_D                               = 1.6e-9                    # [m] dielectric oxide thickness
        
        ## FERROELECTRIC coefficients for LKE
        self.a                                  = -9.45e8#-1.886e9          #[m/F]
        self.b                                  = 2.25e10#9e+10             #[m^5/F/coul^2]
        self.c                                  = 0                         #[m^9/F/coul^4]
        self.d                                  = 0
        self.Ec                                 = 0                         # [V/m] Corcitive Electric Field
        self.Pc                                 = 0                         # [C/m^2] Coercitive Polarization
        self.Pr                                 = 0                         # [C/m^2] Remnant Polarization

        self.sigmaRelEc_a                       = 0.08                      # [] Relative standard deviation of Coercitive Electric field, or alpha: sigma = Relsigma * Ec
        self.sigmaRelPc_b                       = 0.08                      # [] standard deviation of Coercitive Polarization, or beta: sigma = Relsigma * Pc
        self.sigmaRelPr_c                       = 0.08                      # [] standard deviation of Remnant Polarization, or gamma: sigma = Relsigma * Pr

        ## simulator fields     
        self.P                                  = []                        # [C/m^2] Polarization
        self.time                               = []                        # [s] interpolated time
        self.V                                  = []                        # [V] interpolated input voltage
        self.VD                                 = []                        # [V] 'average' voltage between ox and ferroel for each domain
        self.Efe_av                             = []                        # avarage Electric field in the ferroelectric ??? don't know
        self.Qt                                 = []                        # [C/m^2] Trapped charge inside between ferroelectric and dielectric materials
        self.Q                                  = []                        # [C] total charge (must be equal to Qmf or Qmd)
        self.Qmf                                = []                        # [C/m^2] charge at Ferroelectric-metal
        self.Qmd                                = []                        # [C/m^2] charge at Dielectric-metal
        self.P_av                               = []                        # [C/m^2] average polarization
        self.VD_av                              = []                        # [V] average oxide voltage
        self.index2                             = []                        # iterations per time step
        ## cluster FE

        self.set_cluster                        = 0                         #enabler for FE cluster
        self.clusterFE                          = 0.6                       #FE cluster fraction (0 = no FE, 1 = all FE)
        self.shuffleorder                       = []                        #shuffling of FE domains with DE domains

        #####################################################################
        #####################################################################
        #                      Tunneling model parameters                   
        # In self simulare are implemplemented 4 types of charge trapping    
        # models, you can select with engine.traps:                          
        # engine.traps = 0 -> no traps
        # -------------------------------------------------------------------
        # engine.traps = 1 -> static traps
        # -------------------------------------------------------------------
        # engine.traps = 2 -> dynamic traps (Nanoscale 2020)
        # -------------------------------------------------------------------
        #         dynamic traps with tunnelling parameters
        # engine.traps = 3 + engine.enable_integral = false -> approximated
        # version with Meff
        # engine.traps = 3 + engine.enable_integral = true -> numerical
        # calculation of the integral
        # -------------------------------------------------------------------
        # engine.traps = 4 -> dynamic traps with tunnelling parameters and 
        # detailed balance principle
        # 
        # -------------------------------------------------------------------
        #
        # engine.traps = 6 -> dynamic traps (nanoscale 2020) with donors
        # 
        #
        # engine.traps = 7 -> capture and emission freezing window
        #
        # engine.traps = 8 -> dynamic traps (nanoscale 2020) with donors and contact with MF
        #
        # engine.traps = 9 -> emission immediate after Fermi level, capture freezed for some eV
        #
        #                                                                 
        #####################################################################
        #####################################################################
        
        # ALL traps models parameters
        self.N_disc_traps                       = 10                        # number of traps levels
        self.notset_N_disc_traps_don            = 0                         # # of donor levels (NOT set self value in MAIN. This is calculated accordingly N_disc_traps)
        self.ntr                                = []                        # starting density of traps -> [row, col, trap_level, time]
        self.ntr_don                            = []
        self.Emin0                              = 4*1.60217e-19#*q          # [J] Minimum trap energy
        self.Emax0                              = -0 *1.60217e-19#*q        # [J] Maximum trap energy
        self.Emin0_don                          = 4*1.60217e-19
        self.Emax0_don                          = -0 *1.60217e-19
        self.Nacc                               = 1e17/1.60217e-19          # [1/eV/m^2 /e- charge]=[1/J/m^2]
        self.Nacc_don                           = 1e17/1.60217e-19
        self.Nt                                 = -1                        # [m-2] Trap density always taken as self.Nacc * abs(self.Emin0-self.Emax0) / self.N_disc_traps
        self.Nt_don                             = -1  
        # ------------------------------        -------------------------------------
        # model 1-2     
        self.en0                                = 5e7                       # [s^-1] bias indipendent emission rate 
        # -------------------------------------------------------------------
        # model 3-4
        self.nu                                 = 1e5                       # [s^-1] Escape Rate
        self.N_integr_points                    = 100                       # [] Integration Points (CPU only, not GPU)
        self.sigmaTraps                         = 1e-19                     # [m^2] Traps Area Cross-Section 
        self.sigmaTraps_don                     = 1e-19                     # [m^2] Traps Area Cross-Section 
        self.sigmaEnergy                        = 6.4087e-22                # [J] Traps Energy Cross-Section
        self.sigmaEnergy_don                    = 6.4087e-22                # [J] Traps Energy Cross-Section
        self.Meff                               = 1e14                      # [m^-2] Modes in the metal (only engine.traps = 3 and engine.enable_integral = false )
        self.Edepth                             = 10*1.60217662e-19         # [J] Range of energy integration
        self.IMF_in                             = []                        # [A/m^2] Input traps tunneling current (Metal-Dielectric side)
        self.IMF_out                            = []                        # [A/m^2] Input traps tunneling current (Metal-Dielectric side)
        self.IMD_in                             = []                        # [A/m^2] Input traps tunneling current (Metal-Dielectric side)
        self.IMD_out                            = []
        self.QtACC                              = []
        self.QtDON                              = []

        # -------------------------------------------------------------------
        # model 6

        self.en0_don                            = 5e7

        self.tr_occ_acc                         = torch.zeros((1), dtype=self.precision, device=self.device)
        self.tr_occ_don                         = torch.zeros((1), dtype=self.precision, device=self.device)
        # ----------------------------------------------------------------------
        # model 7
        self.enm                                = 200                       # [s^-1] Fermi level traps constant acceptors
        self.enm_don                            = 200                       # [s^-1] Fermi level traps constant donors
        self.Nb                                 = 10.0                      # [-] Smoothing factor emission profile
        self.Eb                                 = 4.0  *1.60217e-19#*q      # [J] Energy enlargment of fermi window

        # ----------------------------------------------------------------------
        # model 8

        self.en0_MF                             = 1e3
        self.en0_don_MF                         = 1e3


        # ----------------------------------------------------------------------
        # model 9

        self.cn0                                = 1e5                       #capture rates
        self.cn0_don                            = 1e5

        # ----------------------------------------------------------------------
        # model 10

        self.capture_profile                    = []
        self.capture_profile_don                = []
        self.emission_profile                   = []
        self.emission_profile_don               = []
        self.profile_length                     = []

        self.capture_rate                       = 1e5
        self.capture_rate_don                   = 1e5
        self.emission_rate                      = 1e5
        self.emission_rate_don                  = 1e5

        self.Erange_max                         = 5*1.60217e-19
        self.Erange_min                         = -5*1.60217e-19
        self.S                                  = 20
        self.E0phonon                           = 0.06*1.60217e-19



        # ----------------------------------------------------------------------
        # antiferroelectricity

        self.AFE                                = 0 #enabler for ferroelectricity
        self.Pb                                 = 0
        self.Eb                                 = 0
        self.sigmaRelPb_c                       = 0
        self.sigmaRelEb_d                       = 0
        self.Eb_dist                            = []

        return 
    
    
    @staticmethod
    def  TwoParamModel_extractabcd(Ec, Pc):
            # This function extract alpha, beta accordingly the 2
            # Parameters Model
            # Ec is the coercitive Electric field 
            # Pc is the coercitive Polarization
            c                                   = 0
            d                                  = 0
            #OLD VALUES
            a                                   = torch.real(3/4 * Ec/Pc)
            b                                   = -torch.real(1/8* Ec/torch.pow(Pc, 3))
            #b                                       = -1/8* Ec/Pc^3 -1/8/(Pc^2)/C0/t_F
            #a                                       = Ec/2/Pc -2*b*Pc^2
            
            return a,b,c,d
    
    
    @staticmethod
    def  TwoParamModel_extractEcPc(a, b): 
        #OLD VALUES 
        Ec                                  = torch.real(4/3*torch.abs(a)*torch.sqrt(torch.abs(a)/6/b))
        Pc                                   = -torch.real(torch.sqrt(torch.abs(a)/6/b))
        #Pc                                      = -sqrt((-a*2*t_F-1/C0)/12/b/t_fe)
        #Ec                                      = 2*a*Pc+4*b*Pc^3;
        Pr                                 = -torch.real(torch.sqrt(torch.abs(a)/2/b))

        return Ec,Pc,Pr

        # Three params model functions
    
    
    @staticmethod
    def ThreeParamModel_extractabcd(Ec, Pc, Pr):
        Ec = Ec.to(torch.float64)
        Pc = Pc.to(torch.float64)
        Pr = Pr.to(torch.float64)

        if Ec == 0 and Pc == 0 and Pr == 0:

            a                               = 0
            b                               = 0
            c                               = 0
            d                               = 0

        else:
            #3 model param must be computed numerically
            B                                   = torch.tensor([Ec, 0, 0], device = Ec.device, dtype=Ec.dtype)
            A = torch.tensor([  [ 2*Pc,   4*torch.pow(Pc, 3),   6*torch.pow(Pc, 5)],
                                [ 2*Pr,   4*torch.pow(Pr, 3),   6*torch.pow(Pr, 5)],
                                [ 2,     12*torch.pow(Pc, 2),  30*torch.pow(Pc, 4)]], device = Ec.device, dtype=Ec.dtype)
            sol                                 = torch.linalg.lstsq(A, B).solution
            a                                   = sol[0]
            b                                   = sol[1]
            c                                   = sol[2]
            d                                   = 0

        # if torch.isnan(torch.tensor([a, b, c, d])).any():
        #     

        return a,b,c,d
    
    
    @staticmethod
    def ThreeParamModel_extractEcPc(a, b, c):
        #get Corcitive values
        pol                                 = [30*c.item(), 0, 12*b.item(), 0, 2*a.item()]
        roo                                 = torch.from_numpy(np.roots(pol)).to(a.device)
        Pc                                  = -torch.real(roo[ torch.logical_and( torch.real(roo) > 0,  torch.imag(roo)==0)])
        Ec                                  = 2*a*Pc+4*b*torch.pow(Pc, 3)+6*c*torch.pow(Pc, 5)
        #get residual value
        pol1                                = [6*c.item(), 0, 4*b.item(), 0, 2*a.item(), 0]
        roo                                 = torch.from_numpy(np.roots(pol1)).to(a.device)
        Pr                                  = -torch.real(roo[ torch.logical_and( torch.real(roo) > 0,  torch.imag(roo)==0)])
        return Ec, Pc, Pr

    @staticmethod
    def ThreeParamModel_extractEcPc_AFE(a, b, c):
        #get Corcitive values

        pol                                 = [30*c.item(), 0, 12*b.item(), 0, 2*a.item()]
        roo                                 = torch.tensor(np.roots(pol), dtype = torch.cdouble).to(a.device)
        Pc                                  = torch.max(torch.real(roo[torch.logical_and(torch.real(roo)>0, torch.imag(roo) == 0)]))
        Ec                                  = 2*a*Pc+4*b*torch.pow(Pc, 3)+6*c*torch.pow(Pc, 5)
        # #get residual value
        # pol1                                = [6*c.item(), 0, 4*b.item(), 0, 2*a.item(), 0]
        # roo                                 = torch.from_numpy(np.roots(pol1)).to(a.device)
        Pb                                  = torch.min(torch.real(roo[torch.logical_and(torch.real(roo)>0, torch.imag(roo) == 0)]))
        return Ec, Pc, Pb

    @staticmethod
    def FourParamModel_extractEcPc_AFE(a, b, c, d):


        pol                                 = [54*d.item(), 0, 30*c.item(), 0, 12*b.item(), 0, 2*a.item()]
        roo                                 = torch.from_numpy(np.roots(pol)).to(a.device)
        Pc                                  = torch.max(torch.real(roo[torch.logical_and(torch.real(roo)>0, torch.imag(roo) == 0)]))
        Pb                                  = torch.min(torch.real(roo[torch.logical_and(torch.real(roo)>0, torch.imag(roo) == 0)]))
        Ec                                  = 2*a*Pc+4*b*torch.pow(Pc, 3)+6*c*torch.pow(Pc, 5)+8*d*torch.pow(Pc, 7)
        Eb                                  = 2*a*Pb+4*b*torch.pow(Pb, 3)+6*c*torch.pow(Pb, 5)+8*d*torch.pow(Pb, 7)


        return Ec, Pc, Eb, Pb

    @staticmethod
    def ThreeParamModel_extractabcd_AFE(Ec, Pc, Pb):

        if Ec == 0 and Pc == 0 and Pb == 0:
            a   = 0
            b   = 0
            c   = 0
            d   = 0
        else:
            a = 45*Ec*torch.pow(Pb, 2)/(4*Pc*(15*torch.pow(Pb, 2)-3*torch.pow(Pc, 2)))
            b = 15/8*Ec/torch.pow(Pc, 3)*(torch.pow(Pc, 2)+torch.pow(Pb, 2))/(3*torch.pow(Pc, 2)-15*torch.pow(Pb, 2))
            c = 3/4*Ec/torch.pow(Pc, 3)/(15*torch.pow(Pb, 2)-3*torch.pow(Pc, 2))
            d = 0


        return a, b, c, d

    @staticmethod
    def FourParamModel_extractabcd_AFE(Ec: torch.DoubleTensor, Pc: torch.DoubleTensor, Eb: torch.DoubleTensor, Pb: torch.DoubleTensor):

        if Ec == 0 and Pc == 0 and Eb == 0 and Pb == 0:
            a   = 0
            b   = 0
            c   = 0
            d   = 0
        else:
            d =  (Eb/Pb*(5-(torch.pow(Pc, 2))/(torch.pow(Pb, 2))) + Ec/Pc*((torch.pow(Pb, 2))/(torch.pow(Pc, 2))-5)) / (16*torch.pow(torch.pow(Pc, 2) -torch.pow(Pb, 2), 3))
            c = (-Eb/(8*torch.pow(Pb, 3))+Ec/(8*torch.pow(Pc, 3)))*(1/(3*(torch.pow(Pb, 2) -torch.pow(Pc, 2))))- 2*d*(torch.pow(Pb, 2) +torch.pow(Pc, 2))
            b = -Ec/(8*torch.pow(Pc, 3)) - 3*torch.pow(Pc, 2)*c -6*torch.pow(Pc, 4) *d
            a = 6*Ec/(8*Pc) + (3*torch.pow(Pc, 4))*c +8*torch.pow(Pc, 6)*d


        return a, b, c, d

    
    def capture_rate_sdevice(self, Etraps, Estart):

        Etraps      = CHECKTENSOR(Etraps, precision=self.precision, device="cpu")
        Estart      = CHECKTENSOR(Estart, precision=self.precision, device="cpu")
        Ef          = CHECKTENSOR(torch.tensor(0, dtype=torch.double), precision=self.precision, device="cpu")
        cn          = CHECKTENSOR(torch.zeros((len(Estart), len(Etraps)), dtype= torch.double), precision=self.precision, device="cpu")
        fb          = 1/(torch.exp(CHECKTENSOR(self.E0phonon/self.Kb/self.Temp, precision=self.precision, device="cpu"))-1)
        z           = CHECKTENSOR(2*self.S*torch.sqrt(fb*(fb+1)), precision=self.precision, device="cpu")
        # for i in range(0, len(Estart)):
            # for j in range(0, len(Etraps)):
                # p = (Estart[i]-Etraps[j])/E0phonon
                
                # if p < 0: #%|| mod(p,1)>0.0001%floor(p)~=p%|| mod(p,1)>0.001 #vedo se intero o negativo
                    # cn [i, j] = 0
                # else:
                    # cn[i, j] = S*(1-p/S)**2*np.exp(-(2*fb+1)*S+(Estart[i]-Etraps[j])/(2*engine.Kb*engine.Temp))*scifun.iv(p, z)*1/(1+np.exp((Estart[i]-Ef)/engine.Kb/engine.Temp))
    
        p = (Estart.unsqueeze(-1).repeat(1, len(Etraps))-Etraps)/self.E0phonon
    
        cn = self.S*(1-p/self.S)**2*torch.exp(-(2*fb+1)*self.S+(Estart.unsqueeze(-1).repeat(1, len(Etraps))-Etraps)/(2*self.Kb*self.Temp))*scifun.iv(p.cpu(), z.cpu()).to("cpu")*(1/(1+torch.exp((Estart-Ef)/self.Kb/self.Temp))).unsqueeze(-1)
    
        cn[p < 0] = 0

        del Etraps
        del Estart
        del z
        del p

        gc.collect()
    
        return torch.sum(cn, 0)/torch.max(torch.sum(cn, 0))

    @torch.no_grad()
    def init_params(self, fromEcPc="ab", distrEcPc="distrecpc", structure_type="MFIM"):
        """
        Initializes general fields of the Engine class 
        and the structure typology of the simulator.

        Parameters
        ----------
        fromEcPc
            String, "ab" the simulator exploits fields a, 
            b, c and d to generate the Landau constant equation, 
            while using "ecpc" it exploits the Ec, Pc and Pr fields

        distrEcPc
            String, "distrecpc" distribution on Ec, Pc, 
            and Pr, while "distrab" distribution on a, b, c Landau’s 
            parameters

        structure_type
            String, "MFM" Metal-Ferroelectrc-Metal structure, 
            "MFIM" Metal-Ferroelectrc-Insulator-Metal structure, 
            "MIFIM" Metal-Insulator-Ferroelectrc-Insulator-Metal structure
        

        Raises
        ------
        ValueError
            when the input is not recognized


        Returns
        ------
        None
        """
        #input parameters check
        self.a                                  = CHECKTENSOR(self.a                        , precision=self.precision, device=self.device)   
        self.b                                  = CHECKTENSOR(self.b                        , precision=self.precision, device=self.device)   
        self.c                                  = CHECKTENSOR(self.c                        , precision=self.precision, device=self.device)     
        self.d                                  = CHECKTENSOR(self.d                        , precision=self.precision, device=self.device)     
        self.t_F                                = CHECKTENSOR(self.t_F                      , precision=self.precision, device=self.device)   
        self.t_D                                = CHECKTENSOR(self.t_D                      , precision=self.precision, device=self.device)    
        self.epsF                               = CHECKTENSOR(self.epsF                     , precision=self.precision, device=self.device)   
        self.epsD                               = CHECKTENSOR(self.epsD                     , precision=self.precision, device=self.device)   
        self.k_coupl                            = CHECKTENSOR(self.k_coupl                  , precision=self.precision, device=self.device)   
        self.dd                                 = CHECKTENSOR(self.dd                       , precision=self.precision, device=self.device)   
        self.w                                  = CHECKTENSOR(self.w                        , precision=self.precision, device=self.device)   
        self.sigmaRelEc_a                       = CHECKTENSOR(self.sigmaRelEc_a             , precision=self.precision, device=self.device)   
        self.sigmaRelPc_b                       = CHECKTENSOR(self.sigmaRelPc_b             , precision=self.precision, device=self.device)   
        self.sigmaRelPr_c                       = CHECKTENSOR(self.sigmaRelPr_c             , precision=self.precision, device=self.device)
        self.sigmaRelEb_d                       = CHECKTENSOR(self.sigmaRelEb_d             , precision=self.precision, device=self.device)   
        self.rho                                = CHECKTENSOR(self.rho                      , precision=self.precision, device=self.device)   
        self.row                                = CHECKTENSOR(self.row                      , precision=torch.int64, device=self.device)   
        self.col                                = CHECKTENSOR(self.col                      , precision=torch.int64, device=self.device)     
        self.t_step                             = CHECKTENSOR(self.t_step                   , precision=self.precision, device=self.device)    
        self.out_i                              = 0   
        self.Vfb                                = CHECKTENSOR(0.0                           , precision=self.precision, device=self.device)   

        self.en0                                = CHECKTENSOR(self.en0                      , precision=self.precision, device=self.device) 
        self.en0_don                            = CHECKTENSOR(self.en0_don                  , precision=self.precision, device=self.device) 
        self.enm                                = CHECKTENSOR(self.enm                      , precision=self.precision, device=self.device) 
        self.enm_don                            = CHECKTENSOR(self.enm_don                  , precision=self.precision, device=self.device) 
        self.Nb                                 = CHECKTENSOR(self.Nb                       , precision=self.precision, device=self.device) 
        self.Eb                                 = CHECKTENSOR(self.Eb                       , precision=self.precision, device=self.device) 

        self.mu                                 = CHECKTENSOR(self.mu                       , precision=self.precision, device=self.device)# Electrodes multiplicity
        self.WF_T                               = CHECKTENSOR(self.WF_T                     , precision=self.precision, device=self.device)#*q	# [J] Work function top electrode (fe)
        self.WF_B                               = CHECKTENSOR(self.WF_B                     , precision=self.precision, device=self.device)#*q;	# [J] Work function bottom electrode (ox)
        self.Chi_fe                             = CHECKTENSOR(self.Chi_fe                   , precision=self.precision, device=self.device)#*q;	# [J] Electron affinity Ferroel
        self.Chi_ox                             = CHECKTENSOR(self.Chi_ox                   , precision=self.precision, device=self.device)#*q;	# [J] Electron affinity ox
        self.m_eff_fe                           = CHECKTENSOR(self.m_eff_fe                 , precision=self.precision, device=self.device)#*m0    # [Kg] Effective mass ferroel
        self.m_eff_ox                           = CHECKTENSOR(self.m_eff_ox                 , precision=self.precision, device=self.device)#*m0    # [Kg] Effective mass oxide
        self.N_disc_traps                       = CHECKTENSOR(self.N_disc_traps             , precision=torch.int64, device=self.device) # number of traps levels
        self.notset_N_disc_traps_don            = CHECKTENSOR(self.notset_N_disc_traps_don  , precision=torch.int64, device=self.device) # of donor levels (NOT set self value in MAIN. This is calculated accordingly N_disc_traps)
        self.ntr                                = CHECKTENSOR(self.ntr                      , precision=self.precision, device=self.device) # starting density of traps -> [row, col, trap_level, time]
        self.ntr_don                            = CHECKTENSOR(self.ntr_don                  , precision=self.precision, device=self.device)
        self.Emin0                              = CHECKTENSOR(self.Emin0                    , precision=self.precision, device=self.device)#*q # [J] Minimum trap energy
        self.Emax0                              = CHECKTENSOR(self.Emax0                    , precision=self.precision, device=self.device)#*q # [J] Maximum trap energy
        self.Emin0_don                          = CHECKTENSOR(self.Emin0_don                , precision=self.precision, device=self.device)
        self.Emax0_don                          = CHECKTENSOR(self.Emax0_don                , precision=self.precision, device=self.device)
        self.Nacc                               = CHECKTENSOR(self.Nacc                     , precision=self.precision, device=self.device) # [1/eV/m^2 /e- charge]=[1/J/m^2]
        self.Nacc_don                           = CHECKTENSOR(self.Nacc_don                 , precision=self.precision, device=self.device)
        self.Nt                                 = CHECKTENSOR(self.Nt                       , precision=self.precision, device=self.device) # [m-2] Trap density always taken as self.Nacc * abs(self.Emin0-self.Emax0) / self.N_disc_traps
        self.Nt_don                             = CHECKTENSOR(self.Nt_don                   , precision=self.precision, device=self.device)
        self.cn0                                = CHECKTENSOR(self.cn0                      , precision=self.precision, device=self.device) 
        self.cn0_don                            = CHECKTENSOR(self.cn0_don                  , precision=self.precision, device=self.device) 

        self.S                                  = CHECKTENSOR(self.S                        , precision=self.precision, device=self.device)

        self.capture_rate                       = CHECKTENSOR(self.capture_rate             , precision=self.precision, device=self.device)        
        self.capture_rate_don                   = CHECKTENSOR(self.capture_rate_don         , precision=self.precision, device=self.device)
        self.emission_rate                      = CHECKTENSOR(self.emission_rate            , precision=self.precision, device=self.device)
        self.emission_rate_don                  = CHECKTENSOR(self.emission_rate_don        , precision=self.precision, device=self.device)

        self.capture_profile                    = CHECKTENSOR(self.capture_profile          , precision=self.precision, device=self.device)
        self.capture_profile_don                = CHECKTENSOR(self.capture_profile_don      , precision=self.precision, device=self.device)
        self.emission_profile                   = CHECKTENSOR(self.emission_profile         , precision=self.precision, device=self.device)
        self.emission_profile_don               = CHECKTENSOR(self.emission_profile_don     , precision=self.precision, device=self.device)
        self.E0phonon                           = CHECKTENSOR(self.E0phonon                 , precision=self.precision, device=self.device)
        self.Erange_max                         = CHECKTENSOR(self.Erange_max               , precision=self.precision, device=self.device)
        self.Erange_min                         = CHECKTENSOR(self.Erange_min               , precision=self.precision, device=self.device)
        #input value check     
        if type(self.sigma) == float:                               
            self.sigma                          = torch.ones(self.row*self.col, dtype=self.precision, device=self.device)*self.sigma
        else:       
            self.sigma                          = CHECKTENSOR(self.sigma, precision=self.precision, device=self.device).flatten() #row array

        # structure_type, must be 'MFM' (not selectable), 'MFIM', 'MIFIM',defines the structure type 
        
        #error checking
        if (self.numberofparam == 2 and self.sigmaRelPr_c != 0):
            pass
            #warnings.warn('WARNING: numberofparam is setted as 2, but Pr is not 0 or sigmaRelPr is not 0')
        elif (self.numberofparam == 3 and self.sigmaRelPr_c == 0):
            pass
            #warnings.warn('WARNING: numberofparam is setted as 3, but Pr is 0 or sigmaRelPr is 0')
        if type(distrEcPc) == str:
            self.distr_type             = distrEcPc.lower()
        else:
            raise ValueError('ERROR 1: distribution selector not properly set')

            
        #check the condition error
        if self.a >=0 and self.AFE == 0:
            raise ValueError('ERROR 2: alpha must be negative')
        
        #structure_type, must be 'MFM' => 0 (not selectable), 'MFIM' => 1, 'MIFIM' => 2
        if type(structure_type) != str:
            raise ValueError('ERROR 3: structure type not regognized')
        if structure_type == 'MFM':
            self.structure_type         = 1
            self.t_D                    = CHECKTENSOR(0.2e-9)
            self.epsD                   = CHECKTENSOR(2000)
        elif structure_type == 'MFIM':
            self.structure_type         = 1
        elif structure_type == 'MIFIM':
            self.structure_type         = 2
            raise ValueError('ERROR 4851: Not debugged yet!')
        else:
            raise ValueError('ERROR 4: structure not implemented')
        
        self.Vfb                        = (self.WF_T-self.WF_B)/self.q; 

        ######################################################################
        ##          Constants definitions                                   ##
        ######################################################################

        if self.structure_type == 1:
            self.CD                             = self.eps0*self.epsD/self.t_D  # [F/m2] capacitï¿½ ossido sotto ferroel
            self.CF                             = self.epsF*self.eps0/self.t_F  # [F/m2]
            self.C0                             = self.CD+self.CF                 # [F/m2]
            self.CS                             = self.CF*self.CD/self.C0         # [F/m2]
            self.C_coupl                        = 1/self.C0             
            self.B                              = -self.CF/self.C0
        elif self.structure_type == 2:      
            self.CDT                            = self.eps0*self.epsD_T/self.t_D_T
            self.CDB                            = self.eps0*self.epsD_B/self.t_D_B
            self.CDS                            = torch.pow(torch.pow(self.CDB, -1) + torch.pow(self.CDT, -1), -1)   
            self.CF                             = self.epsF*self.eps0/self.t_F
            self.CS                             = torch.pow(torch.pow(self.CDB, -1) + torch.pow(self.CDT, -1) + torch.pow(self.CF, -1), -1)         
        else:
            raise ValueError('ERROR 6: structure not implemented')
        if fromEcPc == 'ecpc':
            if self.numberofparam == 2:
                [self.a, self.b, self.c, self.d]= Engine.TwoParamModel_extractabcd(self.Ec, self.Pc)
            elif self.numberofparam == 3:
                if self.AFE == 0:
                    [self.a, self.b, self.c, self.d]= Engine.ThreeParamModel_extractabcd(self.Ec, self.Pc, self.Pr)
                else:
                    [self.a, self.b, self.c, self.d]= Engine.ThreeParamModel_extractabcd_AFE(self.Ec, self.Pc, self.Pr)
            elif self.numberofparam == 4 and self.AFE == 1:
                    [self.a, self.b, self.c, self.d]= Engine.FourParamModel_extractabcd_AFE(self.Ec, self.Pc, self.Eb, self.Pb)                    
            else:
                raise ValueError('ERROR 8: Number of parameters (alpha, beta, gamma) not supported yet')
        elif fromEcPc == 'ab':
            if self.numberofparam == 2:
                [self.Ec, self.Pc, self.Pr]	= Engine.TwoParamModel_extractEcPc(self.a, self.b)
            elif self.numberofparam == 3:
                if self.AFE == 0:
                    [self.Ec, self.Pc, self.Pr]	= Engine.ThreeParamModel_extractEcPc(self.a, self.b,  self.c)
                else:
                    [self.Ec, self.Pc, self.Pb]	= Engine.ThreeParamModel_extractEcPc_AFE(self.a, self.b,  self.c)
            elif self.numberofparam == 4 and self.AFE == 1:
                [self.Ec, self.Pc, self.Eb, self.Pb]	= Engine.FourParamModel_extractEcPc_AFE(self.a, self.b,  self.c, self.d)
            else:
                raise ValueError('ERROR 9: Number of parameters(alpha, beta, gamma) not supported yet')
        else:
                raise ValueError('ERROR 9: Invalid argument fromEcPc in init_params(). Set <<ecpc>> to retrive model from Ec and Pc or <<ab>> to use static alpha and beta.')
            
        if self.traps == 2 and self.structure_type == 1:
            if len(self.Nacc.size()) == 0:
                self.Nt                         = torch.ones((self.N_disc_traps), dtype=self.precision, device=self.device)* self.Nacc * torch.abs(self.Emin0-self.Emax0) / self.N_disc_traps.to(self.precision)
            else:
                self.Nt                         = self.Nacc * torch.abs(self.Emin0-self.Emax0) / self.N_disc_traps.to(self.precision)
            
            if len(self.en0.size()) == 0 and self.structure_type == 1:                    
                self.en0                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.en0
        elif self.traps == 4 and self.structure_type == 1:
            #dE remain the same for boh types of traps (the reference
            #is calculated accordingly the donor type).
            if self.Emax0_don < self.Emax0:
                raise ValueError('ERROR 10: Emax0_don must be larger than Emax0')
            elif self.Emin0_don >= self.Edepth or self.Emin0 >= self.Edepth:
                raise ValueError('ERROR 10: Edepth must be much larger than Emin0  or Emin0_don')

            self.notset_N_disc_traps_don    = torch.ceil((self.Emin0_don-self.Emax0_don).abs()/((self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision))).to(torch.int64)
            if len(self.Nacc.size()) == 0 :
                self.Nt                         = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device) * self.Nacc * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don               	    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)   * self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            else:   
                self.Nt                         = self.Nacc     * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don             	    = self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)

        elif self.traps == 6 and self.structure_type == 1:

            #dE remain the same for boh types of traps (the reference
            #is calculated accordingly the donor type).
            if self.Emax0_don < self.Emax0:
                raise ValueError('ERROR 10: Emax0_don must be larger than Emax0')
            elif self.Emin0_don >= self.Edepth or self.Emin0 >= self.Edepth:
                raise ValueError('ERROR 10: Edepth must be much larger than Emin0  or Emin0_don')

            self.notset_N_disc_traps_don        = torch.round((self.Emin0_don-self.Emax0_don).abs()/((self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision))).to(torch.int64)
            if len(self.Nacc.size()) == 0 :
                self.Nt                         = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device) * self.Nacc * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don               	    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)   * self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            else:   
                self.Nt                         = self.Nacc     * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don             	    = self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            if len(self.en0.size()) == 0 and self.structure_type == 1:                    
                self.en0                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.en0
                self.en0_don                    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.en0_don
        
        elif self.traps == 7 and self.structure_type == 1:

            #dE remain the same for boh types of traps (the reference
            #is calculated accordingly the donor type).
            if self.Emax0_don < self.Emax0:
                raise ValueError('ERROR 10: Emax0_don must be larger than Emax0')
            elif self.Emin0_don >= self.Edepth or self.Emin0 >= self.Edepth:
                raise ValueError('ERROR 10: Edepth must be much larger than Emin0  or Emin0_don')

            self.notset_N_disc_traps_don        = torch.round((self.Emin0_don-self.Emax0_don).abs()/((self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision))).to(torch.int64)
            if len(self.Nacc.size()) == 0 :
                self.Nt                         = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device) * self.Nacc * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don               	    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)   * self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            else:   
                self.Nt                         = self.Nacc     * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don             	    = self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            if len(self.en0.size()) == 0 and self.structure_type == 1:                    
                self.en0                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.en0
                self.en0_don                    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.en0_don
            if len(self.enm.size()) == 0 and self.structure_type == 1:                    
                self.enm                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.enm
            if len(self.enm_don.size()) == 0 and self.structure_type == 1: 
                self.enm_don                    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.enm_don
            if len(self.Nb.size()) == 0 and self.structure_type == 1: 
                self.Nb                         = torch.ones(self.row*self.col, dtype=self.precision, device=self.device)*self.Nb
            if len(self.Eb.size()) == 0 and self.structure_type == 1: 
                self.Eb                         = torch.ones(self.row*self.col, dtype=self.precision, device=self.device)*self.Eb

        elif self.traps == 8 and self.structure_type == 1:

            #dE remain the same for boh types of traps (the reference
            #is calculated accordingly the donor type).
            # if self.Emax0_don < self.Emax0:
                # raise ValueError('ERROR 10: Emax0_don must be larger than Emax0')
            # elif self.Emin0_don >= self.Edepth or self.Emin0 >= self.Edepth:
                # raise ValueError('ERROR 10: Edepth must be much larger than Emin0  or Emin0_don')

            self.notset_N_disc_traps_don        = torch.round((self.Emin0_don-self.Emax0_don).abs()/((self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision))).to(torch.int64)
            if len(self.Nacc.size()) == 0 :
                self.Nt                         = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device) * self.Nacc * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don               	    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)   * self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            else:   
                self.Nt                         = self.Nacc     * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don             	    = self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            if len(self.en0.size()) == 0 and self.structure_type == 1:                    
                self.en0                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.en0
                self.en0_don                    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.en0_don
                self.en0_MF                     = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.en0_MF
                self.en0_don_MF                 = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.en0_don_MF

        elif self.traps == 9 and self.structure_type == 1:

            #dE remain the same for boh types of traps (the reference
            #is calculated accordingly the donor type).
            if self.Emax0_don < self.Emax0:
                raise ValueError('ERROR 10: Emax0_don must be larger than Emax0')
            elif self.Emin0_don >= self.Edepth or self.Emin0 >= self.Edepth:
                raise ValueError('ERROR 10: Edepth must be much larger than Emin0  or Emin0_don')

            self.notset_N_disc_traps_don        = torch.round((self.Emin0_don-self.Emax0_don).abs()/((self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision))).to(torch.int64)
            if len(self.Nacc.size()) == 0 :
                self.Nt                         = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device) * self.Nacc * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don               	    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)   * self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            else:   
                self.Nt                         = self.Nacc     * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don             	    = self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            if len(self.cn0.size()) == 0 and self.structure_type == 1:                    
                self.cn0                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.cn0
                self.cn0_don                    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.cn0_don

        elif self.traps == 10 and self.structure_type == 1:

            #dE remain the same for boh types of traps (the reference
            #is calculated accordingly the donor type).
            if self.Emax0_don < self.Emax0:
                raise ValueError('ERROR 10: Emax0_don must be larger than Emax0')
            elif self.Emin0_don >= self.Edepth or self.Emin0 >= self.Edepth:
                raise ValueError('ERROR 10: Edepth must be much larger than Emin0  or Emin0_don')

            self.notset_N_disc_traps_don        = torch.round((self.Emin0_don-self.Emax0_don).abs()/((self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision))).to(torch.int64)
            if len(self.Nacc.size()) == 0 :
                self.Nt                         = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device) * self.Nacc * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don               	    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)   * self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            else:   
                self.Nt                         = self.Nacc     * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don             	    = self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            if len(self.en0.size()) == 0 and self.structure_type == 1:                    
                self.en0                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.en0
                self.en0_don                    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.en0_don
            if len(self.capture_profile.size()) == 0 and self.structure_type == 1:
                self.capture_profile            = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.capture_profile
                self.capture_profile_don        = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.capture_profile_don
                self.emission_profile           = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.emission_profile
                self.emission_profile_don       = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)*self.emission_profile_don
        elif self.traps > 10:
            raise ValueError('ERROR 11: engine.traps > 6 are not allowed!')
        elif self.traps >=1 and self.structure_type != 1:
            raise ValueError('ERROR 11: Double layer with traps are not implemented yet!')

        if self.row*self.col>1:
                # load electrostatic matrices:
                #file_name                      	= strcat('FTJ_',str(self.row*self.col),'_size',str((self.dd)*1e9),'nm_Tox',str(fix(self.t_D*1e10)),'_Tfe',str(round(self.t_F*1e9)),'_Al2O3');     
                #new name format
                #B is -CB/C0/dd^2
                if self.structure_type == 1:
                    name                        = "n{:n}tf{:g}td{:g}eox{:g}ef{:g}d{:g}".format(self.row*self.col, self.t_F*1e9, self.t_D*1e9, self.epsD, self.epsF, self.dd*1e9)
                    namefile                    = f'desc_files/{name}/{name}'
                    if (not os.path.isdir(f'desc_files/{name}')) or (not os.path.isfile(namefile+'.conf_vmat.txt')) or (not os.path.isfile(namefile+'.conf_glob.txt')):
                        print(f"Creating {name}")
                        if not os.path.isdir(f'desc_files/{name}'):
                            os.makedirs(f'desc_files/{name}')
                        self.download_structure(name)
                    else: 
                        print(f"Loading {name} structure...")

                    #CHECK THE FILE
                    if os.path.isfile(namefile+'.conf_vmat.txt') or os.path.isfile(namefile+'.conf_glob.txt'):
                        delete_ = False
                        with open(namefile+'.conf_vmat.txt', "r") as f:
                            lines = f.readlines()
                            if "not found" in lines[0].lower():
                                delete_ = True
                        
                        with open(namefile+'.conf_glob.txt', "r") as f:
                            lines = f.readlines()
                            if "not found" in lines[0].lower():
                                delete_ = True
                        
                        if delete_:
                            os.remove(namefile+'.conf')
                            os.remove(namefile+'.conf_glob.txt')
                            os.remove(namefile+'.conf_vmat.txt')
                            raise Exception("ERROR 57714: The requested structure is not present in the repository. Please contact Riccardo (fontanini.riccardo@spes.uniud.it)")

                    else:
                        raise Exception("ERROR 15626: Something wrong happend. Contact Riccardo (fontanini.riccardo@spes.uniud.it)")

                    c_temp                      = torch.from_numpy(np.loadtxt(namefile+'.conf_vmat.txt',usecols=2)).to(self.precision).to(device=self.device)
                    b_temp_tot                  = torch.from_numpy(np.loadtxt(namefile+'.conf_glob.txt',usecols=3)).to(self.precision).to(device=self.device)
                    self.B                      = (b_temp_tot[1::2]/self.dd**2).to(self.precision).to(device=self.device)
                    self.D                      = (b_temp_tot[::2]/self.dd**2).to(self.precision).to(device=self.device)
                    self.C_coupl                = torch.reshape(c_temp,(self.row*self.col,self.row*self.col)).to(self.precision).to(device=self.device)
                    self.CpC                    = (self.C_coupl+self.C_coupl.t())
                    

                elif self.structure_type == 2:
                    self.struct_file_name      	= 'n'+str(self.row*self.col)+'tf'+str(self.t_F*1e9)+'tdt'+str(self.t_D_T*1e9)+'tdb'+str(self.t_D_B*1e9)+'edt'+str(self.epsD_T)+'edb'+str(self.epsD_B)+'ef'+str(self.epsF)+'d'+str((self.dd)*1e9)    
                    fileID_C                  	= './desc_files/'+self.struct_file_name+'/'+self.struct_file_name+'.conf_vmat.txt'   #'*_mat.txt'
                    fileID_B                  	= './desc_files/',self.struct_file_name+'/'+self.struct_file_name+'.conf_glob.txt'   #'*_glob.txt'
                    C_temp                    	= torch.from_numpy(np.loadtxt(fileID_C).to(self.precision).to(device=self.device))
                    B_temp                     	= torch.from_numpy(np.loadtxt(fileID_B).to(self.precision).to(device=self.device))
                    self.C_coupl_T             	= -torch.reshape(C_temp[:,3],(self.row*self.col,self.row*self.col)) # 1/C(i,j) elements % TODO: check negative values
                    self.C_coupl_B              = torch.reshape(C_temp[:,2],(self.row*self.col,self.row*self.col))
                    self.B                     	= 1/self.dd^2*B_temp[1:2:-1, 4] # diagonal battery elements 
                    self.D                     	= 1/self.dd^2*B_temp[0:2:-1, 4] # diagonal battery elements 
                    self.C_coupl                = self.C_coupl_T + self.C_coupl_B
                    self.CpC                   	= self.C_coupl + self.C_coupl.t()
                else:
                    raise ValueError('Impossibile type of structure, init_params, Engine')
        
    @torch.no_grad()
    def set_simulator(self, Vsig, time, t_step=0, last_seed=False, P_init=None, Q_set=None, sampling_idx=None, sampling_variables=["tr_occ_acc", "tr_occ_don"]):
        """
        Sets the input signal to the simulator and calculates the starting point of polarization and input traps charge.

        Parameters
        ----------
        Vsig
            Tensor of fp, input signal 

        distrEcPc
            Tensor of fp, time reference

        t_step=0
            float, time step of the simulator (Standard: 0)
        last_seed
            if last_seed=False this fuction calculates a 
            new starting point, otherwise it loads an existing one (Standard: False)
        P_init
            2D Tensor of fp, starting initialization of spontaneous polarization (Standard: None)
        Q_set
            2D Tensor of fp, starting initialization of fixed charges at FE/DE interface (Standard: None)
        sampling_idx
            Tensor of integers, time sampling indices (Standard: None)
        sampling_variables
            List of Strings, variables to sample (Standard: ["tr_occ_acc", "tr_occ_don"])
        
        

        Raises
        ------
        ValueError
            when the input is not recognized


        Returns
        ------
        None

        """
        self.V                                  = CHECKTENSOR(Vsig)
        self.time                               = CHECKTENSOR(time)
        self.t_step                             = CHECKTENSOR(t_step)
        self.index2                             = torch.zeros(len(self.V), dtype = self.precision, device = "cpu")


        ######################################## SAMPLING CHECK ############################################################
        if sampling_variables is None:
            self.sampling_variables             = []
        elif type(sampling_variables) is list:
            self.sampling_variables             = [c.lower() for c in sampling_variables]
        else:
            raise Exception("sampling_variables type not recognized")

        if sampling_idx is None:
            self.sampling_idx                   = torch.tensor([len(self.V)-1], dtype=torch.int64)
        elif type(sampling_idx) is list or type(sampling_idx) is np.ndarray:
            self.sampling_idx                   = torch.tensor(sampling_idx, dtype=torch.int64)
        elif type(sampling_idx) is torch.Tensor:
            if len(sampling_idx.shape) == 1 and sampling_idx.shape[0] < len(self.V):
                self.sampling_idx               = sampling_idx.to(torch.int64)
            else:
                raise Exception("sampling_idx is not well formatted")
        elif type(sampling_idx) is int or type(sampling_idx) is float:
            if int(sampling_idx) < 0:
                raise Exception("sampling_idx is negative")
            else:
                self.sampling_idx               = torch.tensor([int(sampling_idx)])
        else:
            raise Exception("type of sampling_idx not recognized")
        

        if "tr_occ_acc" in self.sampling_variables:
            self.tr_occ_acc                     = torch.zeros((self.row, self.col, self.N_disc_traps, len(self.sampling_idx)), dtype=self.precision, device="cpu")
        else:
            self.tr_occ_acc                     = torch.zeros((self.row, self.col, self.N_disc_traps, len(self.V)), dtype=self.precision, device="cpu")
        
        if "tr_occ_don" in self.sampling_variables:
            self.tr_occ_don                     = torch.zeros((self.row, self.col, self.notset_N_disc_traps_don, len(self.sampling_idx)), dtype=self.precision, device="cpu")
        else:
            self.tr_occ_don                     = torch.zeros((self.row, self.col, self.notset_N_disc_traps_don, len(self.V)), dtype=self.precision, device="cpu")
        
        if "imd_in" in self.sampling_variables:
            self.IMD_in                         = torch.zeros((self.row, self.col, len(self.sampling_idx)), dtype=self.precision, device="cpu")
        else:
            self.IMD_in                         = torch.zeros((self.row, self.col, len(self.V)), dtype=self.precision, device="cpu")
        
        if "imd_out" in self.sampling_variables:
            self.IMD_out                        = torch.zeros((self.row, self.col, len(self.sampling_idx)), dtype=self.precision, device="cpu")
        else:
            self.IMD_out                        = torch.zeros((self.row, self.col, len(self.V)), dtype=self.precision, device="cpu")
        
        if "imf_in" in self.sampling_variables:
            self.IMF_in                         = torch.zeros((self.row, self.col, len(self.sampling_idx)), dtype=self.precision, device="cpu")
        else:
            self.IMF_in                         = torch.zeros((self.row, self.col, len(self.V)), dtype=self.precision, device="cpu")
        
        if "imf_out" in self.sampling_variables:
            self.IMF_out                        = torch.zeros((self.row, self.col, len(self.sampling_idx)), dtype=self.precision, device="cpu")
        else:
            self.IMF_out                        = torch.zeros((self.row, self.col, len(self.V)), dtype=self.precision, device="cpu")
        
        ###################################################################################################################

        ############################################ FIXED CHARGE ########################################################
        #add last index value 
        if not len(self.V) in self.sampling_idx:
            self.sampling_idx                   = torch.cat([self.sampling_idx, torch.tensor([len(self.V)])])

        if not (Q_set is None):
            self.Qt_set                         = CHECKTENSOR(Q_set)
            self._get_fix_charge                = _Qset_from_output #replacing the function
        else:
            self.Qt_set                         = 0.0
            self.sigmarow                       = self.sigma.flatten()
            self._get_fix_charge                = standard_get_fix_charge

        ########################################## INITIALIZATION ########################################################
        self.P                                  = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
        self.Qt                                 = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
        if self.traps == 4 or self.traps == 6 or self.traps==7 or self.traps == 8 or self.traps == 9 or self.traps == 10:
            self.QtACC                          = torch.zeros(self.V.shape[-1], device=self.device, dtype=self.precision)
            self.QtDON                          = torch.zeros(self.V.shape[-1], device=self.device, dtype=self.precision)   

        self.seed = Seed(self)
        if last_seed:
            self.load_seed(self.var_seed_path)
            if self.seed.is_compatible(self):
                self.P[:,:,0]                   = self.seed.Pstart
            else:
                raise ValueError('ERROR 55: Error loading seed in set_simulator(). You are tring to load a seed with different parameters. Check your parameters a, b, c, d Pc Ec and V_sign(1).')            
        else:
            if P_init is None:
                #warnings.warn('P_init not chosen, will be generated by simulator instead, in set_simulator')

                self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.seed.Pstart = self.disp_NORM(self.V[0])

                self.P[:,:,0]                   = self.seed.Pstart
            else:
                P_init                          = CHECKTENSOR(P_init)
                if P_init.shape[0] != self.row or P_init.shape[1] != self.col:
                    raise ValueError('ERROR 56: Initial Polarization vector size not matching with size of engine.P(:,:,0) in set_simulator')
                #Controllare l'inizializzazione!!!!!!!!!!!!!!!!!!!!!!!!!
                self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.seed.Pstart = self.disp_NORM(self.V[0])
                self.P[:,:,0]             	    = P_init
                self.seed.Pstart                = P_init.clone()
        #####################################################################################################################
        
        
        if self.structure_type == 1:
            if self.traps == 0:
                self.ntr                        = torch.zeros((self.row, self.col, self.N_disc_traps), dtype=self.precision, device=self.device)
            elif self.traps == 2:  #'dynamic'
                self.ntr                        = torch.zeros((self.row, self.col, self.N_disc_traps), dtype=self.precision, device=self.device)
                Vd                              = torch.mv(self.C_coupl.t(), self.P[:,:,0].transpose(0, 1).flatten()+self.sigma) + self.CF/self.C0*(self.V[0]-self.Vfb)
                Vd                              = torch.reshape(Vd, (self.row, self.col)).transpose(0, 1)
                js                              = torch.arange(0, self.N_disc_traps, dtype=self.precision, device=self.device)
                for i in range(0, self.row):
                    for j in range(0, self.col):
                        Et                      = self.WF_B - (self.Chi_ox + self.Emax0) - self.q * Vd[i, j] - (self.Emin0-self.Emax0).abs()/(self.N_disc_traps).to(self.precision)*js 
                        self.ntr[i, j, :]       = self.Nt*(1.0/(1.0+torch.exp(Et/self.Kb/self.Temp)))
                
                self.Qt[:, :, 0]                = -self.q * self.ntr.sum(2)
                self.ntr                        = torch.reshape(self.ntr.transpose(0, 1), (self.row * self.col, self.N_disc_traps)).transpose(0, 1).flatten()

            elif self.traps == 4:  # dynamic
                self.ntr                        = torch.zeros((self.row, self.col, self.N_disc_traps), dtype=self.precision, device=self.device)
                self.ntr_don                    = torch.zeros((self.row, self.col, self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                Vd                              = torch.mv(self.C_coupl.t(), self.P[:,:,0].transpose(0, 1).flatten()+self.sigma) + self.CF/self.C0*(self.V[0]-self.Vfb)
                Vd                              = torch.reshape(Vd, (self.row, self.col)).transpose(0, 1)
                dE                              = torch.abs(self.Emin0-self.Emax0)/(self.N_disc_traps).to(self.precision)
                js_acc                          = torch.arange(0, self.N_disc_traps, dtype=self.precision, device=self.device)
                js_don                          = torch.arange(0, self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)
                
                for i in range(0, self.row):
                    for j in range(0, self.col):
                        Et_acc                  = self.WF_B - (self.Chi_ox + self.Emax0) - self.q * Vd[i, j] - dE*js_acc
                        #remember: dE remains the same for both
                        Et_don                  = self.WF_B - (self.Chi_ox + self.Emax0_don) - self.q * Vd[i, j] - dE*js_don; 
                        self.ntr[i, j, :]       = self.Nt.flatten()*(1.0/(1.0+torch.exp(Et_acc/self.Kb/self.Temp)))
                        self.ntr_don[i, j, :]   = self.Nt_don.flatten()*(1.0/(1.0+torch.exp(Et_don/self.Kb/self.Temp)))
                
                self.Qt[:, :, 0]                = -self.q*self.ntr.sum(2) + self.q*(self.Nt_don[0]*(self.notset_N_disc_traps_don).to(self.precision) - self.ntr_don.sum(2))
                self.ntr                        = torch.reshape(self.ntr.transpose(0, 1), (self.row * self.col, self.N_disc_traps)).transpose(0, 1).flatten()
                self.ntr_don                    = torch.reshape(self.ntr_don.transpose(0, 1), (self.row * self.col, self.notset_N_disc_traps_don)).transpose(0, 1).flatten()

            elif self.traps == 6 or self.traps == 7 or self.traps == 8 or self.traps == 9 or self.traps == 10:  #'dynamic'
                self.ntr                        = torch.zeros((self.row, self.col, self.N_disc_traps), dtype=self.precision, device=self.device)
                self.ntr_don                    = torch.zeros((self.row, self.col, self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                
                Vd                              = torch.mv(self.C_coupl.t(), self.P[:,:,0].transpose(0, 1).flatten()+self.sigma) + self.CF/self.C0*(self.V[0]-self.Vfb)
                Vd                              = torch.reshape(Vd, (self.row, self.col)).transpose(0, 1)
                js_acc                          = torch.arange(0, self.N_disc_traps, dtype=self.precision, device=self.device)
                js_don                          = torch.arange(0, self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)
                for i in range(0, self.row):
                    for j in range(0, self.col):
                        Et_acc                  = self.WF_B - (self.Chi_ox + self.Emax0) - self.q * Vd[i, j] - (self.Emin0-self.Emax0).abs()/(self.N_disc_traps).to(self.precision)*js_acc
                        Et_don                  = self.WF_B - (self.Chi_ox + self.Emax0_don) - self.q * Vd[i, j] - (self.Emin0-self.Emax0).abs()/(self.N_disc_traps).to(self.precision)*js_don 
                        self.ntr[i, j, :]       = self.Nt*(1.0/(1.0+torch.exp(Et_acc/self.Kb/self.Temp)))
                        self.ntr_don[i, j, :]   = self.Nt_don*(1.0/(1.0+torch.exp(Et_don/self.Kb/self.Temp)))
                
                
                self.Qt[:, :, 0]                = -self.q * self.ntr.sum(2) + self.q * (self.Nt_don.sum() - self.ntr_don.sum(2))
                self.ntr                        = torch.reshape(self.ntr.transpose(0, 1), (self.row * self.col, self.N_disc_traps)).transpose(0, 1).flatten()
                self.ntr_don                    = torch.reshape(self.ntr_don.transpose(0, 1), (self.row * self.col, self.notset_N_disc_traps_don)).transpose(0, 1).flatten()
                
            else:
                raise ValueError('ERROR 5: Traps not implemented for this structure type')   
        elif self.structure_type == 2:
            self.Qt                             = torch.zeros((self.row, self.col))
            self.ntr                            = torch.zeros((self.row*self.col*self.N_disc_traps))

        self.transfermemory("cpu")
        self.save_seed(self.var_seed_path)  
        gc.collect()
        torch.cuda.empty_cache()
    
    def simulate(self, index_start="all"):
        """
        The main method of the simulator. It runs the simulation. 

        Usage
        -----
        plt.simulate("all")

        Parameters
        ----------
        index_start
            when "all" the simulation until reaching the final index of the input signal
            when "prev" the simulation begins from the last point of a previous simulation. 
            Using "prev" multiple simulations could be concatenated.
        

        Raises
        ------
        ValueError
            when the input is not recognized


        Returns
        ------
        None
            
        """
        with torch.no_grad():

            self.transfermemory("cuda", seed = False)
                        
            ################################# ADAPTATION FOR MATLAB ################################
            flat_a_eff                          = torch.flatten(self.seed.a_eff.transpose(0, 1)).to(self.device)
            flat_b_eff                          = torch.flatten(self.seed.b_eff.transpose(0, 1)).to(self.device)
            flat_c_eff                          = torch.flatten(self.seed.c_eff.transpose(0, 1)).to(self.device)
            flat_d_eff                          = torch.flatten(self.seed.d_eff.transpose(0, 1)).to(self.device)
            ########################################################################################
                
                
            
            #initialization of NR
            self.out_i                          = 1
            DP_succ                             = torch.tensor(1)
            setup                               = 1
            setup_2                             = 0
            Pol_old                             = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            Qt_old                              = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            f_old                               = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            f                                   = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            Qt_1                                = torch.zeros((self.row*self.col), device= self.device, dtype = self.precision)
            Pol_1                               = torch.zeros((self.row*self.col), device= self.device, dtype = self.precision)
            Pdyn                                = torch.zeros((self.row*self.col, self.row*self.col), dtype=self.precision, device=self.device)
            I                                   = torch.eye(self.row*self.col, dtype=self.precision, device=self.device)
            I_varJ                              = I*self.var_J
            if index_start == 'all':
                self.out_i                      = 1                   	
                DP_succ                         = torch.tensor(1)
                setup                           = 1                      	# enable setup = 1
                setup_2                         = 0                     	# enable reset setup
                nan_flag                        = 0                      	# flag to report a NaN Jacobian and retry with smaller step
                PP                              = torch.flatten(self.P[:,:, self.out_i-1].transpose(0,1).clone())
                Pol_1[:]                        = PP
                QQ                              = torch.flatten(self.Qt[:,:, self.out_i-1].transpose(0,1).clone())
                static_                         = torch.mv(self.CpC, PP+QQ+self._get_fix_charge(self, self.out_i-1))
                
                beferro.MFIMsolver(f, PP, self.V[self.out_i-1], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i-1), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
            elif index_start=='prev':
                DP_succ                         = torch.tensor(1)
                setup                           = 0                     	# enable setup = 1
                setup_2                         = 0                     	# enable reset setup
                nan_flag                        = 0                      	# flag to report a NaN Jacobian and retry with smaller step
                PP                              = torch.flatten(self.P[:,:, self.out_i-1].transpose(0,1).clone())
                QQ                              = torch.flatten(self.Qt[:,:, self.out_i-1].transpose(0,1).clone())
                static_                         = torch.mv(self.CpC, PP+QQ+self._get_fix_charge(self, self.out_i-1))
                
                beferro.MFIMsolver(f, PP, self.V[self.out_i-1], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i-1), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
            else:
                raise ValueError('ERROR 0: Value of index_start not recognized')
            
            if self.traps == 0:
                ntr_1                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ptr_1                           = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)

            elif self.traps == 2:
                ntr_1                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_last                        = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_1[:]                        = self.ntr
                cn_ijk                          = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                en_ijk                          = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk_old                       = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                d_f_ijk                         = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
            elif self.traps == 4:
                ntr_1                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_1[:]                        = self.ntr
                ptr_1                           = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                ptr_1[:]                        = self.ntr_don
                ntr_last                        = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ptr_last                        = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                TMD                             = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps)).to(torch.int64)), dtype=self.precision, device=self.device)
                TMF                             = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps)).to(torch.int64)), dtype=self.precision, device=self.device)     
                dE                              = (self.Emax0-self.Emin0).abs()/self.N_disc_traps
                self.IMD_in                     = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)#MUST BE ON CPU TO REDUCE THE AMOUNT OF MEMORY USED DURING THE SIMULATION
                self.IMD_out                    = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
                self.IMF_in                     = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
                self.IMF_out                    = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
                cnmd                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                cnmf                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                enmd                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                enmf                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)  
                cnmd_don                     	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                cnmf_don                      	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                enmd_don                      	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                enmf_don                        = torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)  
                
                f_ijk                           = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                d_f_ijk                         = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk_don                    	= torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                d_f_ijk_don                   	= torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                f_ijk_old                       = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk_don_old                   = torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)

            elif self.traps == 6 or self.traps == 7 or self.traps == 9 or self.traps == 10:
                ntr_1                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_1[:]                        = self.ntr
                ptr_1                           = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                ptr_1[:]                        = self.ntr_don
                ntr_last                        = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ptr_last                        = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                dE                              = (self.Emax0-self.Emin0).abs()/self.N_disc_traps
                cn                              = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                en                              = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                cn_don                     	    = torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                en_don                      	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                
                f_ntr                           = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ptr                        	= torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                f_ntr_old                       = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ptr_old                       = torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                debug_solver_ntr_sentaurus      = torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                field_precision                 = torch.zeros((self.col*self.row), dtype=torch.int32, device=self.device)
                field_precision_don             = torch.zeros((self.col*self.row), dtype=torch.int32, device=self.device)
            elif self.traps == 8:
                ntr_1                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_1[:]                        = self.ntr
                ptr_1                           = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                ptr_1[:]                        = self.ntr_don
                ntr_last                        = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ptr_last                        = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                dE                              = (self.Emax0-self.Emin0).abs()/self.N_disc_traps
                cn                              = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                en                              = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                cn_don                     	    = torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                en_don                      	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)

                cn_MF                           = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                en_MF                           = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                cn_don_MF                 	    = torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                en_don_MF                     	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                
                
                f_ntr                           = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ptr                        	= torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                f_ntr_old                       = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ptr_old                       = torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)    

            pbar = tqdm(total = self.V.shape[0])


            while self.out_i < self.V.shape[0]:
                if( DP_succ>1e-5 and setup ==1 ):
                    print(f"SETUP Convergence: {torch.abs(DP_succ)}")
                    
                    self.out_i                  = 1
                    if setup_2 == 0:        
                        setup_2                 = 1
                    else:       
                        self.P[:,:,0]           = self.P[:,:,self.out_i]
                elif setup_2 == 1:  
                    print(f"END of SETUP, starting the simulation... ")
                    
                    self.out_i                  = 1
                    self.P[:,:,0]               = self.P[:,:,self.out_i]
                    self.Qt[:,:,0]              = self.Qt[:,:,self.out_i]
                    if (self.traps == 4 or self.traps == 6 or self.traps == 7 or self.traps == 8 or self.traps == 9 or self.traps == 10) and self.structure_type == 1:
                        self.QtACC[0]           = -torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1).mean()*self.q
                        self.QtDON[0]           = -torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1).mean()*self.q +self.Nt_don.sum()*self.q
                    setup                       = 0
                    setup_2                     = 0
                    pbar.update(1)
                    pbar.update(1)
                else:
                    pbar.set_description_str("V(t) = {:2.1f}V".format(self.V[self.out_i]))
                    pbar.update(1)
                
                

                # Pol_old[:]                      = torch.flatten(self.P[:,:, self.out_i-1].transpose(0, 1)) ### TRANSPOSE FOR MATLAB ACCORDANCE
                # Qt_old[:]                       = torch.flatten(self.Qt[:,:, self.out_i-1].transpose(0, 1)) ### TRANSPOSE FOR MATLAB ACCORDANCE
                Pol_old[:]                      = Pol_1
                Qt_old[:]                       = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                static_                         = torch.mv(self.CpC, Pol_old + Qt_old + self._get_fix_charge(self, self.out_i-1))
                f_old[:]                        = f #copy the values, not cloning
                
                beferro.MFIMsolver(f_old, Pol_old, self.V[self.out_i-1], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i-1), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
                
                Vd                              = torch.mv(self.C_coupl.t(), (Pol_old+self._get_fix_charge(self, self.out_i-1)+Qt_old)) + self.CF/self.C0*(self.V[self.out_i-1]-self.Vfb)
                if self.traps == 0:
                    relative_delta_ntr          = torch.tensor(0, dtype=self.precision, device=self.device)
                    Qt_1[:]                     = Qt_old
                elif self.traps == 2 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference                    
                    beferro.solver_ntr(f_ijk_old, cn_ijk, en_ijk, Pol_old, Vd, self.row, self.col, ntr_last, self.en0, self.Nt, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.N_disc_traps, self.Temp)
                    delta_ntr                   = self.t_step*f_ijk_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1)
                    relative_delta_ntr          = torch.max(torch.abs(delta_ntr/ntr_1))
                elif self.traps == 4 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference
                    ptr_last[:]                 = ptr_1 #copy of the reference
                    
                    beferro.calc_TMD_TMF(TMD, TMF, self.row, self.col, self.V[self.out_i-1], Vd, self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp)
                    beferro.solver_ntr_dbpm_accanddon(f_ijk_old, d_f_ijk, f_ijk_don_old, d_f_ijk_don, cnmd, enmd, cnmf, enmf, cnmd_don, enmd_don, cnmf_don, enmf_don, ntr_1, ptr_1, TMD, TMF, self.row, self.col, self.V[self.out_i-1], Vd, self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 1)
                    delta_ntr                   = self.t_step*f_ijk_old
                    delta_ptr                   = self.t_step*f_ijk_don_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    ptr_1[:]                    = ptr_last + delta_ptr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don[0]*self.notset_N_disc_traps_don - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    relative_delta_ntr   	    = torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0).max()
                elif self.traps == 6 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference
                    ptr_last[:]                 = ptr_1 #copy of the reference
                    beferro.solver_ntr_don(f_ntr_old, f_ptr_old, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_last, ptr_last, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                    
                    
                    delta_ntr                   = self.t_step*f_ntr_old
                    delta_ptr                   = self.t_step*f_ptr_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    ptr_1[:]                    = ptr_last + delta_ptr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    relative_delta_ntr   	    = torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0).max()
                elif self.traps == 7 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference
                    ptr_last[:]                 = ptr_1 #copy of the reference
                    
                    beferro.solver_model7(f_ntr_old, f_ptr_old, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_last, ptr_last, self.en0, self.en0_don, self.enm, self.enm_don, self.Nb, self.Eb, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                    
                    delta_ntr                   = self.t_step*f_ntr_old
                    delta_ptr                   = self.t_step*f_ptr_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    ptr_1[:]                    = ptr_last + delta_ptr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    relative_delta_ntr   	    = torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0).max()
                elif self.traps == 8 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference
                    ptr_last[:]                 = ptr_1 #copy of the reference
                    beferro.solver_ntr_don_MF(f_ntr_old, f_ptr_old, cn, en, cn_don, en_don, cn_MF, en_MF, cn_don_MF, en_don_MF, Vd, self.V[self.out_i-1], self.row, self.col, ntr_last, ptr_last, self.en0, self.en0_don, self.en0_MF, self.en0_don_MF, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                    
                    
                    delta_ntr                   = self.t_step*f_ntr_old
                    delta_ptr                   = self.t_step*f_ptr_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    ptr_1[:]                    = ptr_last + delta_ptr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    relative_delta_ntr   	    = torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0).max()

                elif self.traps == 9 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference
                    ptr_last[:]                 = ptr_1 #copy of the reference
                    beferro.solver_ntr_don_shifted(f_ntr_old, f_ptr_old, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_last, ptr_last, self.cn0, self.cn0_don, self.Eb, self.Nb, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                    
                    
                    delta_ntr                   = self.t_step*f_ntr_old
                    delta_ptr                   = self.t_step*f_ptr_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    ptr_1[:]                    = ptr_last + delta_ptr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    relative_delta_ntr   	    = torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0).max()

                elif self.traps == 10 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference
                    ptr_last[:]                 = ptr_1 #copy of the reference
                    beferro.solver_ntr_don_sentaurus(f_ntr_old, f_ptr_old, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_last, ptr_last, self.emission_profile, self.emission_profile_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.Erange_max, self.Erange_min, self.capture_profile, self.capture_profile_don, self.profile_length, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp, field_precision, field_precision_don, debug_solver_ntr_sentaurus)
                    
                    
                    delta_ntr                   = self.t_step*f_ntr_old
                    delta_ptr                   = self.t_step*f_ptr_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    ptr_1[:]                    = ptr_last + delta_ptr


                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    relative_delta_ntr   	    = torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0).max()                    
                else:
                    raise ValueError('ERROR 1: Not implemented trap model')
                    

                delta                           = self.t_step * f_old
                Pol_1[:]                        = Pol_old + delta
                relative_delta                  = torch.max(torch.abs(delta/Pol_1))
                index                           = 0
                

                while (relative_delta>1e-7 or relative_delta_ntr>1e-7 ):

                    if self.traps == 2 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1 + self._get_fix_charge(self, self.out_i) + Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.solver_ntr(f_ijk, cn_ijk, en_ijk, Pol_1, Vd, self.row, self.col, ntr_1, self.en0, self.Nt, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.N_disc_traps, self.Temp)
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ijk_old - (1-self.theta)*f_ijk)/(1/self.t_step + (1-self.theta)*(cn_ijk+en_ijk))
                        ntr_1                   = ntr_1 - delta_ntr
                        Qt_1                    = -self.q*torch.sum(torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t(), 1)
                        
                    elif self.traps == 4 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1+self._get_fix_charge(self, self.out_i)+Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.calc_TMD_TMF(TMD, TMF, self.row, self.col, self.V[self.out_i], Vd, self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, torch.abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp)
                        beferro.solver_ntr_dbpm_accanddon(f_ijk, d_f_ijk, f_ijk_don, d_f_ijk_don, cnmd, enmd, cnmf, enmf, cnmd_don, enmd_don, cnmf_don, enmf_don, ntr_1, ptr_1, TMD, TMF, self.row, self.col, self.V[self.out_i], Vd, self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 1)
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ijk_old - (1-self.theta)*f_ijk)/(1/self.t_step - (1-self.theta)*d_f_ijk)
                        ntr_1                   = ntr_1 - delta_ntr
                        delta_ptr               = ((ptr_1 - ptr_last)/self.t_step - self.theta*f_ijk_don_old - (1-self.theta)*f_ijk_don)/(1/self.t_step - (1-self.theta)*d_f_ijk_don)
                        ptr_1                   = ptr_1 - delta_ptr
                        Qt_1                    = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1)+ self.q*(self.Nt_don[0]*self.notset_N_disc_traps_don - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))   
                    elif self.traps == 6 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1 + self._get_fix_charge(self, self.out_i) + Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.solver_ntr_don(f_ntr, f_ptr, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_1, ptr_1, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                        
                        
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ntr_old - (1-self.theta)*f_ntr)/(1/self.t_step + (1-self.theta)*(cn+en))
                        delta_ptr               = ((ptr_1 - ptr_last)/self.t_step - self.theta*f_ptr_old - (1-self.theta)*f_ptr)/(1/self.t_step + (1-self.theta)*(cn_don+en_don))
                        ntr_1                   = ntr_1 - delta_ntr
                        ptr_1                   = ptr_1 - delta_ptr
                        Qt_1                    = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    elif self.traps == 7 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1 + self._get_fix_charge(self, self.out_i) + Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.solver_model7(f_ntr, f_ptr, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_1, ptr_1, self.en0, self.en0_don, self.enm, self.enm_don, self.Nb, self.Eb, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                        
                        
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ntr_old - (1-self.theta)*f_ntr)/(1/self.t_step + (1-self.theta)*(cn+en))
                        delta_ptr               = ((ptr_1 - ptr_last)/self.t_step - self.theta*f_ptr_old - (1-self.theta)*f_ptr)/(1/self.t_step + (1-self.theta)*(cn_don+en_don))
                        ntr_1                   = ntr_1 - delta_ntr
                        ptr_1                   = ptr_1 - delta_ptr
                        Qt_1                    = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    
                    elif self.traps == 8 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1 + self._get_fix_charge(self, self.out_i) + Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.solver_ntr_don_MF(f_ntr, f_ptr, cn, en, cn_don, en_don, cn_MF, en_MF, cn_don_MF, en_don_MF, Vd, self.V[self.out_i], self.row, self.col, ntr_1, ptr_1, self.en0, self.en0_don, self.en0_MF, self.en0_don_MF, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                        
                        
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ntr_old - (1-self.theta)*f_ntr)/(1/self.t_step + (1-self.theta)*(cn+en+cn_MF+en_MF))
                        delta_ptr               = ((ptr_1 - ptr_last)/self.t_step - self.theta*f_ptr_old - (1-self.theta)*f_ptr)/(1/self.t_step + (1-self.theta)*(cn_don_MF+en_don_MF))
                        ntr_1                   = ntr_1 - delta_ntr
                        ptr_1                   = ptr_1 - delta_ptr
                        Qt_1                    = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))
                    elif self.traps == 9 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1 + self._get_fix_charge(self, self.out_i) + Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.solver_ntr_don_shifted(f_ntr, f_ptr, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_1, ptr_1, self.cn0, self.cn0_don, self.Eb, self.Nb, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
                        
                        
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ntr_old - (1-self.theta)*f_ntr)/(1/self.t_step + (1-self.theta)*(cn+en))
                        delta_ptr               = ((ptr_1 - ptr_last)/self.t_step - self.theta*f_ptr_old - (1-self.theta)*f_ptr)/(1/self.t_step + (1-self.theta)*(cn_don+en_don))
                        ntr_1                   = ntr_1 - delta_ntr
                        ptr_1                   = ptr_1 - delta_ptr
                        Qt_1                    = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))

                    elif self.traps == 10 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1 + self._get_fix_charge(self, self.out_i) + Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.solver_ntr_don_sentaurus(f_ntr, f_ptr, cn, en, cn_don, en_don, Vd, self.row, self.col, ntr_1, ptr_1, self.emission_profile, self.emission_profile_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.Erange_max, self.Erange_min, self.capture_profile, self.capture_profile_don, self.profile_length, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp, field_precision, field_precision_don, debug_solver_ntr_sentaurus)
                        
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ntr_old - (1-self.theta)*f_ntr)/(1/self.t_step + (1-self.theta)*(cn+en))
                        delta_ptr               = ((ptr_1 - ptr_last)/self.t_step - self.theta*f_ptr_old - (1-self.theta)*f_ptr)/(1/self.t_step + (1-self.theta)*(cn_don+en_don))
                        ntr_1                   = ntr_1 - delta_ntr
                        ptr_1                   = ptr_1 - delta_ptr
                        Qt_1                    = -self.q*torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1) + self.q*(self.Nt_don.sum() - torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1))

                        if False: #debugging
                            cndr = torch.reshape(cn_don, (self.notset_N_disc_traps_don, self.row*self.col)).t().cpu()

                            endr = torch.reshape(en_don, (self.notset_N_disc_traps_don, self.row*self.col)).t().cpu()

                            ppr = torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().cpu()
                            ppr_last = torch.reshape(ptr_last, (self.notset_N_disc_traps_don, self.row*self.col)).t().cpu()
                            fpr = torch.reshape(f_ptr, (self.notset_N_disc_traps_don, self.row*self.col)).t().cpu()
                            fpr_old = torch.reshape(f_ptr_old, (self.notset_N_disc_traps_don, self.row*self.col)).t().cpu()
                            deltan = torch.reshape((delta_ntr/ntr_1).abs().cpu(), (self.N_disc_traps, self.row*self.col)).t()
                            deltap = torch.reshape((delta_ptr/ptr_1).abs().cpu(), (self.notset_N_disc_traps_don, self.row*self.col)).t()
                            dd = torch.reshape(debug_solver_ntr_sentaurus, (self.notset_N_disc_traps_don, self.row*self.col)).t()
                            print("dd[59, :] = ",dd[59,:])
                            pdb.set_trace()


                    static_                     = torch.mv(self.CpC, Pol_1+Qt_1+ self._get_fix_charge(self, self.out_i))
                    beferro.MFIMsolver(f, Pol_1, self.V[self.out_i], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
                    f_tot                       = (Pol_1-Pol_old)/self.t_step + (self.theta*f+(1.0-self.theta)*f_old)
                    Peps                        = ((Pol_1.unsqueeze(-1).repeat( (1, self.row*self.col)) + I*self.var_J))
                    Qeps                        = (Pol_1+Qt_1+self._get_fix_charge(self, self.out_i)).unsqueeze(-1).repeat((1, self.row*self.col)) + I_varJ
                    static_eps                  = torch.matmul(self.CpC, Qeps)
                    beferro.eval_variation(Pdyn, torch.flatten(Peps.transpose(0, 1)), self.V[self.out_i], torch.flatten(static_eps.transpose(0, 1)), self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
                    Pdyn_trasp                  = Pdyn.transpose(0, 1) 
                    fp                          = (Pdyn_trasp - f.unsqueeze(-1).repeat(1, self.row*self.col))/self.var_J
                    Jacobian                    = I/self.t_step + fp*self.theta




                    delta                       = -torch.linalg.lstsq(Jacobian, f_tot, rcond=None).solution
                    Pol_1                       = Pol_1 + delta

                    if torch.isnan(Pol_1).any():
                        raise ValueError('ERROR 69449: Pol_1 became NaN in simulate!!')
                    if self.traps == 2:
                        if torch.isnan(ntr_1).any():
                            raise ValueError('ERROR 15963: ntr_1 became NaN in simulate!!')
                    elif self.traps == 4 or self.traps == 6 or self.traps == 7 or self.traps == 8 or self.traps == 9 or self.traps == 10:
                        if torch.isnan(ntr_1).any() or torch.isnan(ptr_1).any():
                            raise ValueError('ERROR 15963: ntr_1 or ptr_1 became NaN in simulate!!')
                    
                    relative_delta              = torch.max(torch.abs(delta/Pol_1))
                    if self.traps == 0 or self.traps == 1:
                        relative_delta_ntr     	= torch.tensor([0]) #useless placeholder value
                    elif self.traps == 2 or self.traps == 3:
                        relative_delta_ntr   	= torch.max(torch.abs(delta_ntr/ntr_1))
                    elif self.traps == 4 or self.traps == 6 or self.traps== 7 or self.traps == 8 or self.traps == 9 or self.traps == 10:
                        relative_delta_ntr   	= torch.max(torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0))
                    else:
                        raise ValueError('error')

                    index               += 1
                #this.index2(this.out_i)      	= index;


                self.index2[self.out_i]         = index
                self.P[:,:,self.out_i]        	= torch.reshape(Pol_1, (self.row, self.col)).transpose(0, 1) #% [C/m2]
                self.Qt[:,:,self.out_i]         = torch.reshape(Qt_1 , (self.row, self.col)).transpose(0, 1)
                
                #if self.traps == 3 and self.structure_type == 1:
                #    
                #    self.ntr                    = torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps))
                #    self.IMD_in[:, self.out_i]  = torch.sum(torch.reshape(Imdin, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                #    self.IMD_out[:, self.out_i] = -torch.sum(torch.reshape(Imdout, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                #    self.IMF_in[:, self.out_i]  = torch.sum(torch.reshape(Imfin, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                #    self.IMF_out[:, self.out_i] = -torch.sum(torch.reshape(Imfout, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                if self.traps == 4 and self.structure_type == 1:
                    #self.ntr                    = torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps))
                    #self.ntr_don                = torch.reshape(ptr_1, (self.row*self.col, self.notset_N_disc_traps_don))
                    self.QtACC[self.out_i]      = -torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1).mean()*self.q
                    self.QtDON[self.out_i]      = -torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1).mean()*self.q +self.Nt_don.sum()*self.q
                    
                    
                    ################################################# SAMPLING #####################################################
                    #no reshape or transpose
                    
                    if "tr_occ_acc" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                     = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        self.tr_occ_acc[:, :, :,idx]      = (ntr_1/self.Nt[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    elif not "tr_occ_acc" in self.sampling_variables:
                        idx                     = self.out_i
                        self.tr_occ_acc[:, :, :,idx]      = (ntr_1/self.Nt[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    
                    if "tr_occ_don" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                     = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        self.tr_occ_don[:, :, :,idx]      = (ptr_1/self.Nt_don[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    elif not "tr_occ_don" in self.sampling_variables:
                        idx                     = self.out_i
                        self.tr_occ_don[:, :, :, idx]      = (ptr_1/self.Nt_don[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    
                    
                    if "imd_in" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                         = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        swap                        = torch.reshape(torch.reshape(cnmd*(1-ntr_1/self.Nt[0]),    (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMD_in[:, :,idx]       = swap + torch.reshape(torch.reshape(cnmd_don*(1-ptr_1/self.Nt_don[0]),    (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    elif not "imd_in" in self.sampling_variables:
                        idx                         = self.out_i
                        swap                        = torch.reshape(torch.reshape(cnmd*(1-ntr_1/self.Nt[0]),    (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMD_in[:, :,idx]       = swap + torch.reshape(torch.reshape(cnmd_don*(1-ptr_1/self.Nt_don[0]),    (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    
                    if "imd_out" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                         = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        swap                        = torch.reshape(torch.reshape(enmd*ntr_1/self.Nt[0],        (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMD_out[:, :,idx]      = -(swap  + torch.reshape(torch.reshape(enmd_don*    ptr_1/self.Nt_don[0],    (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1) )
                    elif not "imd_out" in self.sampling_variables:
                        idx                         = self.out_i
                        swap                        = torch.reshape(torch.reshape(enmd*ntr_1/self.Nt[0],        (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMD_out[:, :,idx]      = -(swap  + torch.reshape(torch.reshape(enmd_don*    ptr_1/self.Nt_don[0],    (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1) )
                    
                    
                    if "imf_in" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                         = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        swap                        = torch.reshape(torch.reshape(cnmf*(1-ntr_1/self.Nt[0]),    (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMF_in[:, :,idx]       = swap     + torch.reshape(torch.reshape(cnmf_don*(1-ptr_1/self.Nt_don[0]),    (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    elif not "imf_in" in self.sampling_variables :
                        idx                         = self.out_i
                        swap                        = torch.reshape(torch.reshape(cnmf*(1-ntr_1/self.Nt[0]),    (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMF_in[:, :,idx]       = swap     + torch.reshape(torch.reshape(cnmf_don*(1-ptr_1/self.Nt_don[0]),    (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    
                    

                    if "imf_out" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                         = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        swap                        = torch.reshape(torch.reshape(enmf*ntr_1/self.Nt[0],        (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMF_out[:, :,idx]      = -(swap  + torch.reshape(torch.reshape(enmf_don*ptr_1/self.Nt_don[0],        (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1) )
                    elif not "imf_out" in self.sampling_variables:
                        idx                         = self.out_i
                        swap                        = torch.reshape(torch.reshape(enmf*ntr_1/self.Nt[0],        (self.N_disc_traps, self.col*self.row)).t().sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                        self.IMF_out[:, :,idx]      = -(swap  + torch.reshape(torch.reshape(enmf_don*ptr_1/self.Nt_don[0],        (self.notset_N_disc_traps_don, self.col*self.row)).t().sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1) )
                    
                    
                    #################################################################################################################
                    if self.out_i == len(self.V)-1:
                        self.ntr                    = torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t()
                        self.ntr_don                = torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t()

                elif (self.traps == 6 or self.traps == 7 or self.traps == 8 or self.traps == 9 or self.traps == 10) and self.structure_type == 1:
                    self.QtACC[self.out_i]      = -torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t().sum(1).mean()*self.q
                    self.QtDON[self.out_i]      = -torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t().sum(1).mean()*self.q +self.Nt_don.sum()*self.q
                    
                    
                    if "tr_occ_acc" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                     = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        self.tr_occ_acc[:, :, :,idx]      = (ntr_1/self.Nt[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    elif not "tr_occ_acc" in self.sampling_variables:
                        idx                     = self.out_i
                        self.tr_occ_acc[:, :, :,idx]      = (ntr_1/self.Nt[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    

                    if "tr_occ_don" in self.sampling_variables and self.out_i in self.sampling_idx:
                        idx                     = torch.where(self.sampling_idx == self.out_i)[0][0].item()
                        self.tr_occ_don[:, :, :,idx]      = (ptr_1/self.Nt_don[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    elif "tr_occ_don" in self.sampling_variables:
                        idx                     = self.out_i
                        self.tr_occ_don[:, :, :,idx]      = (ptr_1/self.Nt_don[0]).cpu().reshape((self.N_disc_traps, self.col*self.row)).transpose(0, 1).reshape((self.col, self.row, self.N_disc_traps)).transpose(0, 1)
                    
                    
                    if self.out_i == len(self.V)-1:
                        self.ntr                    = torch.reshape(ntr_1, (self.N_disc_traps, self.row*self.col)).t()
                        self.ntr_don                = torch.reshape(ptr_1, (self.notset_N_disc_traps_don, self.row*self.col)).t()

                if setup > 0:

                    if self.set_cluster == 1:

                        Pol_1[flat_b_eff == 0]     = Pol_old[flat_b_eff == 0]
                        Qt_1[flat_b_eff == 0]      = Qt_old[flat_b_eff == 0]

                    DP_succ                     = torch.max(torch.tensor([torch.abs((Pol_1-Pol_old)/Pol_old).max(), torch.abs((Qt_1-Qt_old)/Qt_old).max()], dtype = self.precision, device = self.device))
                self.out_i                      = self.out_i +1
                #if self.out_i % 100 == 0:
                #    print(str(self.out_i)+'-step: Signal [V]: '+str(self.V[self.out_i].item())+' Completion percentage: '+str(((self.time[self.out_i]/self.time[-1])*100).item())+' %')    
            pbar.close()
            self.calculate_charge()
            self.calculate_voltagefields()
            self.transfermemory("cpu")
            self.calculate_IMD()
            self.calculate_IMF()

    def calculate_IMD(self, ):
        """
        This function calculates the MD current. It combines the derivative of the QMD plus
        the trap assisted tunneling current. It returns also all current components. 
        This function saves also the average current into IMD field 

        Usage
        -----
        plt.plot(engine.calculate_IMD()[0])

        Parameters
        ----------
        None
        

        Raises
        ------
        None


        Returns
        ------
        IMD
            the current flowing throught the MD contact
        
        IQMD
            the current component releated the charge displacement variation in time
        
        IMDin
            the input current component releated to the traps assisted tunneling

        IMDout
            the output current component releated to the traps assisted tunneling

        """
        if self.traps == 4:
            if "imd_in" in self.sampling_variables and "imd_out" in self.sampling_variables:
                IMDin       = self.IMD_in.mean([0, 1])
                IMDout      = self.IMD_out.mean([0, 1])
                IQMD        = torch.cat([torch.tensor([0]), torch.diff(self.Qmd)])[len(self.sampling_idx)]/self.t_step
            elif "imd_in" in self.sampling_variables and (not "imd_out" in self.sampling_variables):
                IMDin       = self.IMD_in.mean([0, 1])
                IMDout      = self.IMD_out.mean([0, 1])
                IQMD        = torch.cat([torch.tensor([0]), torch.diff(self.Qmd)])[len(self.sampling_idx)]/self.t_step
            elif (not "imd_in" in self.sampling_variables) and "imd_out" in self.sampling_variables:
                IMDin       = self.IMD_in.mean([0, 1])
                IMDout      = self.IMD_out.mean([0, 1])
                IQMD        = torch.cat([torch.tensor([0]), torch.diff(self.Qmd)])[len(self.sampling_idx)]/self.t_step
            else:
                IMDin       = self.IMD_in.mean([0, 1])
                IMDout      = self.IMD_out.mean([0, 1])
                IQMD        = torch.cat([torch.tensor([0]), torch.diff(self.Qmd)])/self.t_step
            #signs of IMDin, IMDout must agree 
            self.IMD        = IQMD - (IMDin + IMDout)
            return self.IMD, IQMD , IMDin , IMDout
        else:
            IQMD        = torch.cat([torch.tensor([0]), torch.diff(self.Qmd)])/self.t_step
            #signs of IMDin, IMDout must agree 
            self.IMD        = IQMD
            return self.IMD, IQMD , None , None
    
    def calculate_IMF(self, ):
        """
        This function calculates the MF current. It combines the derivative of the QMF plus
        the trap assisted tunneling current. It returns also all current components. 
        This function saves also the average current into IMF field 

        Usage
        -----
        plt.plot(engine.calculate_IMF()[0])

        Parameters
        ----------
        None
        

        Raises
        ------
        None


        Returns
        ------
        IMF
            the current flowing throught the MF contact
        
        IQMF
            the current component releated the charge displacement variation in time
        
        IMFin
            the input current component releated to the traps assisted tunneling

        IMFout
            the output current component releated to the traps assisted tunneling

        """

        if "imf_in" in self.sampling_variables and "imf_out" in self.sampling_variables:
            IMFin       = self.IMF_in.mean([0, 1])
            IMFout      = self.IMF_out.mean([0, 1])
            IQMF        = torch.cat([torch.tensor([0]), torch.diff(self.Qmf)])[len(self.sampling_idx)]/self.t_step
        elif "imf_in" in self.sampling_variables and (not "imf_out" in self.sampling_variables):
            IMFin       = self.IMF_in.mean([0, 1])
            IMFout      = self.IMF_out.mean([0, 1])
            IQMF        = torch.cat([torch.tensor([0]), torch.diff(self.Qmf)])[len(self.sampling_idx)]/self.t_step
        elif (not "imf_in" in self.sampling_variables) and "imf_out" in self.sampling_variables:
            IMFin       = self.IMF_in.mean([0, 1])
            IMFout      = self.IMF_out.mean([0, 1])
            IQMF        = torch.cat([torch.tensor([0]), torch.diff(self.Qmf)])[len(self.sampling_idx)]/self.t_step
        else:
            IMFin       = self.IMF_in.mean([0, 1])
            IMFout      = self.IMF_out.mean([0, 1])
            IQMF        = torch.cat([torch.tensor([0]), torch.diff(self.Qmf)])/self.t_step

        self.IMF        = IQMF - (IMFin + IMFout)
        return self.IMF, IQMF, IMFin , IMFout




    @torch.no_grad()
    def band_diagram(self, timeindex, index_structure=None):
        """
        This function calculates the band diagram. If index_structure is None, 
        it calculates the band diagram with VD_av, otherwise you have to specify in 
        the domain index in index_structure as a tuple

        Usage
        -----
        plt.plot(*engine.band_diagram(idx))

        Parameters
        ----------
        timeindex: int
            time index to calculate the band diagram

        index_structure: tuple of int, optional
            index of the domain to consider (default is None)

        Raises
        ------
        ValueError 
            If timeindex or index_structure are wrong

        """
        if timeindex <0 or timeindex >= len(self.V) or timeindex is None:
            raise ValueError("ERROR 8367: Not valid index in timeindex")

        if index_structure is None:
            VD                          = self.VD_av[timeindex]
        else:
            if len(index_structure) != 2:
                raise ValueError("ERROR 548466: Not valid index in index_structure")
            if index_structure[0] < 0 or index_structure[0] >=self.row or index_structure[1] < 0 or index_structure[1] >self.col:
                raise ValueError("ERROR 563284: Not valid index in index_structure")
            VD                          = self.VD[index_structure[0], index_structure[1], timeindex] 
        
        Ubottom                         = 0
        UD_M                            = self.WF_B/self.q-self.Chi_ox/self.q                                   # [eV] Band at the Metal-Ox disc.
        UD_F                            = self.WF_B/self.q - VD - self.Chi_ox/self.q;                           # [eV] Band at the Ox-Fe discontinuity (for the oxide)
        UF_D                            = self.WF_B/self.q - VD - self.Chi_fe/self.q;                           # [eV] Band at the Ox-Fe discontinuity (for the ferroel)
        UF_M                            = self.WF_B/self.q - self.V[timeindex]+self.Vfb - self.Chi_fe/self.q;   # [eV] Band of ferroelectric at the top contact
        Utop                            = self.WF_B/self.q - self.V[timeindex]+self.Vfb - self.WF_T/self.q;     # [eV] Fermi level of the top contact
        
        y                               = [       Ubottom,   Ubottom,      UD_M, UD_F, UF_D,     UF_M,     Utop,          Utop] 
        x                               = [-1e-9-self.t_D, -self.t_D, -self.t_D,    0,    0, self.t_F, self.t_F, self.t_F+1e-9]
        return [x, y]
        

    @torch.no_grad()
    def band_ACC(self, timeindex, index_structure=None):
        """
        This function calculates the band of acceptor traps. If index_structure is None, 
        it calculates the band diagram with VD_av, otherwise you have to specify in 
        the domain index in index_structure as a tuple

        Usage
        -----
        plt.plot(*engine.band_ACC(idx))

        Parameters
        ----------
        timeindex: int
            time index to calculate the band diagram

        index_structure: tuple of int, optional
            index of the domain to consider (default is None)

        Raises
        ------
        ValueError 
            If timeindex or index_structure are wrong

        """
        if self.traps == 2 or self.traps == 4 or self.traps == 6 or self.traps == 7 or self.traps == 8 or self.traps == 9 or self.traps == 10:
            pass
        else:
            return [] 

        if timeindex <0 or timeindex >= len(self.V) or timeindex is None:
            raise ValueError("ERROR 8367: Not valid index in timeindex")

        if index_structure is None:
            VD                          = self.VD_av[timeindex]
        else:
            if len(index_structure) != 2:
                raise ValueError("ERROR 548466: Not valid index in index_structure")
            if index_structure[0] < 0 or index_structure[0] >=self.row or index_structure[1] < 0 or index_structure[1] >self.col:
                raise ValueError("ERROR 563284: Not valid index in index_structure")
            VD                          = self.VD[index_structure[0], index_structure[1], timeindex] 
        
        Utop                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emax0/self.q;               # [eV] Top of the  traps
        Ubot                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emin0/self.q;               # [eV] Bottom of the  traps
        y                               = [ Utop, Ubot] 
        x                               = [    0,    0]
        return [x, y]

    @torch.no_grad()
    def band_DON(self, timeindex, index_structure=None):
        """
        This function calculates the band of donor traps. If index_structure is None, 
        it calculates the band diagram with VD_av, otherwise you have to specify in 
        the domain index in index_structure as a tuple

        Usage
        -----
        plt.plot(*engine.band_DON(idx))

        Parameters
        ----------
        timeindex: int
            time index to calculate the band diagram

        index_structure: tuple of int, optional
            index of the domain to consider (default is None)

        Raises
        ------
        ValueError 
            If timeindex or index_structure are wrong

        """
        if self.traps == 4 or self.traps == 6 or self.traps == 7 or self.traps == 8 or self.traps == 9 or self.traps == 10:
            pass
        else:
            return [] 

        if timeindex <0 or timeindex >= len(self.V) or timeindex is None:
            raise ValueError("ERROR 8367: Not valid index in timeindex")

        if index_structure is None:
            VD                          = self.VD_av[timeindex]
        else:
            if len(index_structure) != 2:
                raise ValueError("ERROR 548466: Not valid index in index_structure")
            if index_structure[0] < 0 or index_structure[0] >=self.row or index_structure[1] < 0 or index_structure[1] >self.col:
                raise ValueError("ERROR 563284: Not valid index in index_structure")
            VD                          = self.VD[index_structure[0], index_structure[1], timeindex] 
        
        Utop                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emax0_don/self.q;               # [eV] Top of the  traps
        Ubot                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emin0_don/self.q;               # [eV] Bottom of the  traps
        y                               = [ Utop, Ubot] 
        x                               = [    0,    0]
        return [x, y]
        

    @torch.no_grad()
    def load(self, path = './var.pkl'):
        if path.lower().endswith('.pkl'):

            with bz2.BZ2File(path, "rb") as data:
                loaded                      = pickle.load(data)
                self.__dict__.update(loaded.__dict__)
                del loaded
        elif path.lower().endswith(".json"):
            with open(path) as f:
                data                    = json.load(f)
                self.__dict__.update(data)
                #############################################
                # PUT HERE CORRECTIONS FOR INCOMPATIBILITY
                # only few adjustments for retrocompatibility
                self.t_D                = data["t_ox"]
                del self.t_ox
                self.t_F                = data["t_fe"]
                del self.t_fe
                self.epsD               = data["er_ox"]
                del self.er_ox
                self.epsF               = data["eps_B"]
                del self.eps_B

                self.CF                 = data["CB"]
                del self.CB

                self.t_step             = data["t_step_new"]
                del self.t_step_new

                self.time               = data["tempo"]
                del self.tempo

                self.seed               = Seed(self)
                self.seed.a_eff         = torch.reshape(torch.tensor(data["av"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                self.seed.b_eff         = torch.reshape(torch.tensor(data["bv"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                self.seed.c_eff         = torch.reshape(torch.tensor(data["cv"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                self.seed.d_eff         = torch.reshape(torch.tensor(data["dv"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                del self.av
                del self.bv
                del self.cv
                del self.dv
                ##########################################
                for k in dir(self):
                    v               = getattr(self, k)
                    if type(v) is list:
                        setattr(self, k, torch.tensor(v, dtype=self.precision, device="cpu")) 
                
                
        else:
            raise Exception('File type not recognized!') 
        

    @torch.no_grad()
    def save(self, path = './var.pkl'):

        head, tail                          = os.path.split(path)
        if not os.path.isdir(head):
            os.makedirs(head)
        self.var_saving_path                    = path
        with bz2.BZ2File(path, "wb") as f: 
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)
    
    @torch.no_grad()
    def load_seed(self, path = './seed.pkl'):

        if path.lower().endswith(".pkl"):
            self.var_seed_path                      = path
            loaded                                  = pickle.load(open(path, 'rb'))
            if self.seed is None:
                self.seed                           = loaded 
            else:
                self.seed.__dict__.update(loaded.__dict__)
            del loaded

        elif path.lower().endswith(".json"):
            with open(path) as f:
                data                    = json.load(f)
                valuecheck              =   data[0] == self.a*self.t_F and \
                                            data[1] == self.b*self.t_F and \
                                            data[2] == self.c*self.t_F and \
                                            data[3] == self.d*self.t_F and \
                                            data[6] == self.V[0]
                
                if valuecheck:
                    self.seed.a_eff     = torch.tensor(data[7], dtype=self.precision)
                    self.seed.b_eff     = torch.tensor(data[8], dtype=self.precision)
                    self.seed.c_eff     = torch.tensor(data[9], dtype=self.precision)
                    self.seed.d_eff     = torch.tensor(data[10], dtype=self.precision)
                    self.seed.Pstart    = torch.tensor(data[13], dtype=self.precision)
                else: 
                    raise Exception('Loading seed not possible! Wrong initial parameters!') 
                
        else:
            raise Exception('File type not recognized!') 

    @torch.no_grad()
    def save_seed(self, path = './seed.pkl'):
        head, tail = os.path.split(path)
        if not os.path.isdir(head):
            os.makedirs(head)
        self.var_seed_path                      = path
        pickle.dump(self.seed, open(path, 'wb'))

    @torch.no_grad()
    def disp_NORM(self, V_iniz):
        a_eff                              	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        b_eff                            	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        c_eff                              	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        d_eff                              	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        P_iniz                             	    = torch.ones([self.row, self.col], device=self.device, dtype=self.precision)
        
        #std. dev. calculation
        if self.distr_type == 'distrecpc':
            sigmaEc_a                        	= torch.abs(self.sigmaRelEc_a * self.Ec)
            sigmaPc_b                          	= torch.abs(self.sigmaRelPc_b * self.Pc)
            if self.numberofparam == 2:
                    sigmaPr_c                	= 0
            elif self.numberofparam == 3:
                if self.AFE == 0:
                    sigmaPr_c                 	= torch.abs(self.sigmaRelPr_c * self.Pr)
                else:
                    sigmaPb_c                 	= (self.sigmaRelPb_c * self.Pb).abs()
            elif self.numberofparam == 4 and self.AFE == 1:
                sigmaPb_c                 	= (self.sigmaRelPb_c * self.Pb).abs()
                sigmaEb_d                 	= (self.sigmaRelEb_d * self.Eb).abs()
            else:
                    raise ValueError('Error 98: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')
        elif self.distr_type == 'distrab':
            sigmaEc_a                        	= torch.abs(self.sigmaRelEc_a * self.a)
            sigmaPc_b                          	= torch.abs(self.sigmaRelPc_b * self.b)
            if self.numberofparam == 2:
                sigmaPr_c                	    = 0
            elif self.numberofparam == 3:
                if self.AFE == 0:
                    sigmaPr_c                 	    = abs(self.sigmaRelPr_c * self.c)
                else:
                    sigmaPb_c                       = abs(self.sigmaRelPb_c * self.c)
            elif self.numberofparam == 4 and self.AFE == 1:
                sigmaPb_c                   = abs(self.sigmaRelPb_c * self.c)
                sigmaEb_d                   = abs(self.sigmaRelEb_d * self.d)
            else:
                raise ValueError('Error 99: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')
        else:
            raise ValueError('Error 100: Selector of realization (distr_type) is not setted properly, disp_NORM')


        onemat                                  = torch.ones([self.row,  self.col], dtype=self.precision, device = self.device)
        #realizations
        if self.distr_type=='distrecpc':

            if self.AFE == 0:

                if self.set_cluster == 0:
                    self.seed.Ec_dist                  	    = torch.normal(self.Ec * onemat, sigmaEc_a * onemat)
                    self.seed.Pc_dist                       = torch.normal(self.Pc * onemat, sigmaPc_b * onemat)
                    if self.numberofparam == 2:
                        self.seed.Pr_dist                   = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
                    elif self.numberofparam == 3:
                        self.seed.Pr_dist          	        = torch.normal(self.Pr * onemat, sigmaPr_c * onemat)
                    else:
                        raise ValueError('Error 101: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')

                elif self.set_cluster == 1:

                    if torch.numel(self.shuffleorder) == 0:
                        raise ValueError('Error 102: engine.shuffleorder cannot be empty, disp_NORM')

                    # Ec_dist_FE                      = sigmaEc_a*randn(1,ceil(this.cluster_f*this.row*this.col)) + this.Ec
                    # Pc_dist_FE                      = sigmaPc_b*randn(1,ceil(this.cluster_f*this.row*this.col)) + this.Pc

                    Ec_dist_FE                      = torch.normal(self.Ec * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device), sigmaEc_a * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device))
                    Pc_dist_FE                      = torch.normal(self.Pc * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device), sigmaPc_b * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device))


                    Ec_dist_DE                      = torch.zeros(int(self.row*self.col-torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device)
                    Pc_dist_DE                      = torch.zeros(int(self.row*self.col-torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device)
                    Ec_dist                         = torch.cat([Ec_dist_FE, Ec_dist_DE], 0)
                    Pc_dist                         = torch.cat([Pc_dist_FE, Pc_dist_DE], 0)
                    Ec_dist_shuffle                 = Ec_dist[self.shuffleorder]
                    Pc_dist_shuffle                 = Pc_dist[self.shuffleorder]

                    self.seed.Ec_dist               = torch.reshape(Ec_dist_shuffle, (self.row,self.col))
                    self.seed.Pc_dist               = torch.reshape(Pc_dist_shuffle, (self.row,self.col))


                    if self.numberofparam == 2:
                            self.seed.Pr_dist           	= torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
                    elif self.numberofparam == 3:
                            Pr_dist_FE              = torch.normal(self.Pr * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device), sigmaPr_c * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device))
                            Pr_dist_DE              = torch.zeros(int(self.row*self.col-torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device)
                            Pr_dist                 = torch.cat([Pr_dist_FE, Pr_dist_DE], 0)
                            Pr_dist_shuffle         = Pr_dist[self.shuffleorder]
                            self.seed.Pr_dist      	= torch.reshape(Pr_dist_shuffle, (self.row,self.col))
                else:
                    raise ValueError('Error 103: engine.set_cluster not valid, disp_NORM')                            
            else:

                if self.set_cluster == 0:
                    self.seed.Ec_dist               = torch.normal(self.Ec, sigmaEc_a, (self.row, self.col), dtype = torch.double, device = self.device)#sigmaEc_a*randn(self.row,self.col) + self.Ec;
                    self.seed.Pc_dist               = torch.normal(self.Pc, sigmaPc_b, (self.row, self.col), dtype = torch.double, device = self.device) #sigmaPc_b*randn(self.row,self.col) + self.Pc;
                    if self.numberofparam == 2:
                         self.seed.Pb_dist               = []
                    elif self.numberofparam == 3:
                        Pb = 0
                        for j in range(0, self.row):
                            for k in range (0, self.col):
                                while(Pb <= self.seed.Pc_dist[j,k]/torch.sqrt(torch.tensor(5, dtype = torch.double, device = self.device)) or Pb > self.seed.Pc_dist[j,k]):
                                    Pb = torch.normal(self.Pb, sigmaPb_c) #sigmaPb_c*randn()+self.Pb;
                                self.seed.Pb_dist[j,k] = Pb
                                Pb = 0                
                    elif self.numberofparam == 4:
                        Pb = 0
                        for j in range(0, self.row):
                            for k in range(0, self.col):
                                while(Pb <= self.seed.Pc_dist[j,k]/torch.sqrt(torch.tensor(5)) or Pb > self.seed.Pc_dist[j,k]):
                                    Pb = torch.normal(self.Pb, sigmaPb_c)#sigmaPb_c*randn()+self.Pb
                                self.seed.Pb_dist[j,k] = Pb
                                Pb = 0

                        Eb = 0
                        for j in range(0, self.row):
                            for k in range(0, self.col):
                                Ebthreshold = (5*torch.pow(self.seed.Pc_dist[j, k], 2)-torch.pow(self.seed.Pb_dist[j, k], 2))/(5*torch.pow(self.seed.Pb_dist[j, k], 2)-torch.pow(self.seed.Pc_dist[j, k], 2))*(torch.pow(self.seed.Pb_dist[j, k], 3)/torch.pow(self.seed.Pc_dist[j, k], 3))*self.seed.Ec_dist[j, k]

                                if Ebthreshold < self.Eb-3*sigmaEb_d or Ebthreshold > self.Eb+3*sigmaEb_d:
                                    warnings.warn('Positive delta condition is out of 99% range of std distribution, consider lowering sigmaPb_c, sigmaPc_b or raising sigmaEb_d, or prepare to wait forever :D, in DISP_NORM')
                                while(Eb <= Ebthreshold):
                                    Eb = torch.normal(self.Eb, sigmaEb_d) #sigmaEb_d*randn()+self.Eb
                                self.seed.Eb_dist[j,k] = Eb
                                Eb = 0

                                # self.seed.Eb_dist[j,k] = Ebthreshold + 0.1*Ebthreshold


                elif self.set_cluster == 1:

                    if torch.numel(self.shuffleorder) == 0:
                        raise ValueError('Error 102: engine.shuffleorder cannot be empty, disp_NORM')

                    # Ec_dist_FE                      = sigmaEc_a*randn(1,ceil(this.cluster_f*this.row*this.col)) + this.Ec
                    # Pc_dist_FE                      = sigmaPc_b*randn(1,ceil(this.cluster_f*this.row*this.col)) + this.Pc

                    Ec_dist_FE                      = torch.normal(self.Ec * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device), sigmaEc_a * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device))
                    Pc_dist_FE                      = torch.normal(self.Pc * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device), sigmaPc_b * torch.ones(int(torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device))


                    Ec_dist_DE                      = torch.zeros(int(self.row*self.col-torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device)
                    Pc_dist_DE                      = torch.zeros(int(self.row*self.col-torch.ceil(self.clusterFE*self.row*self.col)), dtype= self.precision, device = self.device)
                    Ec_dist                         = torch.cat([Ec_dist_FE, Ec_dist_DE], 0)
                    Pc_dist                         = torch.cat([Pc_dist_FE, Pc_dist_DE], 0)
                    Ec_dist_shuffle                 = Ec_dist[self.shuffleorder]
                    Pc_dist_shuffle                 = Pc_dist[self.shuffleorder]

                    self.seed.Ec_dist                    = torch.reshape(Ec_dist_shuffle, (self.row,self.col))
                    self.seed.Pc_dist                    = torch.reshape(Pc_dist_shuffle, (self.row,self.col))


                    if self.numberofparam == 2:
                            self.Pb_dist           	= []
                    elif self.numberofparam == 3:
                        Pb = 0
                        Pb_dist = torch.zeros(self.row*self.col)


                        for j in range(0, self.row*self.col):

                            if self.seed.Pc_dist.reshape((self.row*self.col))[j] == 0 and self.seed.Ec_dist.reshape((self.row*self.col))[j] == 0:
                                Pb_dist[j] == 0

                            else:
                                while(Pb <= self.seed.Pc_dist.reshape((self.row*self.col))[j]/torch.sqrt(torch.tensor(5, dtype = torch.double, device = self.device)) or Pb > self.seed.Pc_dist.reshape((self.row*self.col))[j]):
                                    Pb = torch.normal(self.Pb, sigmaPb_c) #sigmaPb_c*randn()+self.Pb;
                                Pb_dist[j] = Pb
                                Pb = 0
                        self.seed.Pb_dist      	= torch.reshape(Pb_dist, (self.row,self.col))
                    elif self.numberofparam == 4:

                        Pb = 0
                        Pb_dist = torch.zeros(self.row*self.col, dtype = torch.double, device = self.device)


                        for j in range(0, self.row*self.col):

                            if self.seed.Pc_dist.reshape((self.row*self.col))[j] == 0 and self.seed.Ec_dist.reshape((self.row*self.col))[j] == 0:
                                Pb_dist[j] == 0

                            else:
                                while(Pb <= self.seed.Pc_dist.reshape((self.row*self.col))[j]/torch.sqrt(torch.tensor(5, dtype = torch.double, device = self.device)) or Pb > self.seed.Pc_dist.reshape((self.row*self.col))[j]):
                                    Pb = torch.normal(self.Pb, sigmaPb_c) #sigmaPb_c*randn()+self.Pb;
                                Pb_dist[j] = Pb
                                Pb = 0
                        self.seed.Pb_dist      	= torch.reshape(Pb_dist, (self.row,self.col))

                        Eb_dist = torch.zeros(self.row*self.col, dtype = torch.double, device = self.device)
                        Eb = 0


                        for j in range(0, self.row*self.col):
                            if self.seed.Pb_dist.reshape((self.row*self.col))[j] == 0 and self.seed.Pc_dist.reshape((self.row*self.col))[j] == 0:
                                Eb_dist[j] = 0
                            else:
                                Ebthreshold = (5*torch.pow(self.seed.Pc_dist.reshape((self.row*self.col))[j], 2)-torch.pow(self.seed.Pb_dist.reshape((self.row*self.col))[j], 2))/(5*torch.pow(self.seed.Pb_dist.reshape((self.row*self.col))[j], 2)-torch.pow(self.seed.Pc_dist.reshape((self.row*self.col))[j], 2))*(torch.pow(self.seed.Pb_dist.reshape((self.row*self.col))[j], 3)/torch.pow(self.seed.Pc_dist.reshape((self.row*self.col))[j], 3))*self.seed.Ec_dist.reshape((self.row*self.col))[j]
                                if Ebthreshold < self.Eb-3*sigmaEb_d or Ebthreshold > self.Eb+3*sigmaEb_d:
                                    warnings.warn('Positive delta condition is out of 99% range of std distribution, consider lowering sigmaPb_c, sigmaPc_b or raising sigmaEb_d, or prepare to wait forever :D, in DISP_NORM')
                                while(Eb <= Ebthreshold):
                                    Eb = torch.normal(self.Eb, sigmaEb_d) #sigmaEb_d*randn()+self.Eb
                                Eb_dist[j] = Eb
                                Eb = 0
                        self.seed.Eb_dist   = Eb_dist.reshape((self.row, self.col))
                else:
                    raise ValueError('Error 103: engine.set_cluster not valid, disp_NORM')                            


        elif self.distr_type == 'distrab':
                a_eff                           = torch.normal(self.a * onemat, sigmaEc_a * onemat)
                b_eff                           = torch.normal(self.b * onemat, sigmaPc_b * onemat)
                if self.numberofparam == 2:
                    c_eff                       = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
                elif self.numberofparam == 3:
                    if self.AFE == 0:
                        c_eff                       = torch.normal(self.c * onemat, sigmaPr_c * onemat)
                    else:
                        c_eff                       = torch.normal(self.c, sigmaPb_c, (self.row, self.col), dtype=self.precision, device = self.device)
                elif self.numberofparam == 4:
                    if self.AFE == 1:
                        d_eff                       = torch.normal(self.d, sigmaEb_d, (self.row, self.col), dtype = self.precision, device = self.device)
                else:
                    raise ValueError('Error 102: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')                
        else:
            raise ValueError('Error 103: Selector of realization (distr_type) is not setted properly, disp_NORM')

        #conversions
        for xx in range(0, self.row):
            for yy in range(0, self.col):
                # get alpha, beta of (xx, yy) domain, according to the
                # pre-generated distribution
                if self.distr_type == 'distrecpc':
                    if self.AFE == 0:
                        if self.numberofparam == 2:
                            [a_, b_, c_, d_]      	= Engine.TwoParamModel_extractabcd(self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy])
                        elif self.numberofparam == 3:
                            [a_, b_, c_, d_]     	= Engine.ThreeParamModel_extractabcd(self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Pr_dist[xx, yy])
                        else:
                            raise ValueError('Error 104: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')

                        if a_ == 0 and b_ == 0 and c_ == 0 and d_ == 0:
                            a_ = torch.tensor(1e13, dtype= self.precision, device=self.device)
                    else:
                        if self.numberofparam == 2:
                            raise ValueError('Error 105: not yet implemented 2 params extraction for AFE, put sigmac_Pr = 0')
                        elif self.numberofparam == 3:
                            [a_, b_, c_, d_]     	= Engine.ThreeParamModel_extractabcd_AFE(self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Pb_dist[xx, yy])
                        elif self.numberofparam == 4:
                            [a_, b_, c_, d_]     	= Engine.FourParamModel_extractabcd_AFE(self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Eb_dist[xx, yy], self.seed.Pb_dist[xx, yy])
                        else:
                            raise ValueError('Error 106: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')

                        if a_ == 0 and b_ == 0 and c_ == 0 and d_ == 0:
                            a_ = torch.tensor(1e13, dtype= self.precision, device=self.device)


                    a_eff[xx, yy]               = a_ * self.t_F # I have to multiply tfe for retrocompatibility
                    b_eff[xx, yy]               = b_ * self.t_F
                    c_eff[xx, yy]               = c_ * self.t_F
                    d_eff[xx, yy]               = d_ * self.t_F

                elif self.distr_type == 'distrab':

                    if self.AFE == 0:
                        if self.numberofparam == 2:
                            self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Pr_dist[xx, yy] = Engine.TwoParamModel_extractEcPc(a_eff[xx, yy], b_eff[xx, yy])
                        elif self.numberofparam == 3:
                            self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Pr_dist[xx, yy] = Engine.ThreeParamModel_extractEcPc(a_eff[xx, yy], b_eff[xx, yy],  c_eff[xx, yy])
                        else:
                            raise ValueError('Error 107: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')
                    else:
                        if self.numberofparam == 2:
                            raise ValueError('two param model not available for AFE, disp_norm')
                        elif self.numberofparam == 3:
                            self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Pb_dist[xx, yy] = Engine.ThreeParamModel_extractEcPc_AFE(a_eff[xx, yy], b_eff[xx, yy],  c_eff[xx, yy])
                        elif self.numberofparam == 4:
                            self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Eb_dist[xx, yy], self.seed.Pb_dist[xx, yy] = Engine.FourParamModel_extractEcPc_AFE(a_eff[xx, yy], b_eff[xx, yy],  c_eff[xx, yy], d_eff[xx, yy])
                        else:
                            raise ValueError('Error 109: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')                        
                    

                    a_eff[xx, yy]               = a_eff[xx, yy] * self.t_F # I have to multiply tfe for retrocompatibility
                    b_eff[xx, yy]               = b_eff[xx, yy] * self.t_F
                    c_eff[xx, yy]               = c_eff[xx, yy] * self.t_F
                    d_eff[xx, yy]               = d_eff[xx, yy] * self.t_F
                

                if self.structure_type == 1: #MFIM
                    # calcuclation of starting Polarization  
                    # 
                    # pdb.set_trace()                     

                    P_roots                     = np.roots([8*d_eff[xx, yy].item(), 0, 6*c_eff[xx, yy].item(), 0, 4*b_eff[xx, yy].item(), 0, 2*a_eff[xx, yy].item()+1/(self.C0.item()), -(V_iniz*self.CD/self.C0).item()])
                    P_roots                     = np.real(P_roots[P_roots.imag == 0 ])    # Only real roots
                    
                    P0                          = np.min(P_roots)

                    if V_iniz > 0:
                        P0                      = np.abs(P0)
                    else:
                        P0                      = -np.abs(P0)

                    P_iniz[xx, yy]              = P0; 
                elif self.structure_type == 2: #MIFIM 
                    P_roots                     = np.roots([8*d_eff[xx,yy], 0, 6*c_eff[xx,yy], 0, 4*b_eff[xx,yy], 0, 2*a_eff[xx,yy]+(self.Cs/(self.CF*self.CDS)), -V_iniz*self.Cs/self.CF])
                    P_roots                     = np.real(P_roots[P_roots.imag == 0 ])    # Only real roots
                    P0                          = np.min(P_roots) # ho tolto il valore assoluto per eliminare P=0
                    if V_iniz > 0:
                        P0                      = np.abs(P0)
                    else:
                        P0                      = -np.abs(P0)
                    P_iniz[xx,yy]               = P0


        return a_eff, b_eff, c_eff, d_eff, P_iniz
    
    @torch.no_grad()
    def conv_pickseed_to_mat(self, name_pick, name_mat):
        import numpy, scipy.io
        import pickle, sys
        self.load_seed(name_pick)
        aa = self.seed
        tf = aa.t_F.item()
        scipy.io.savemat(name_mat, mdict={"seed" : np.array([aa.a.item()*tf, aa.b.item()*tf, aa.c.item()*tf, aa.d.item()*tf, CHECKTENSOR(self.Ec).item(), CHECKTENSOR(self.Pc).item(), aa.Vstart, aa.a_eff.cpu().numpy(), aa.b_eff.cpu().numpy(), aa.c_eff.cpu().numpy(), aa.d_eff.cpu().numpy(), aa.Ec_dist.cpu().numpy(), aa.Pc_dist.cpu().numpy(), aa.Pstart.cpu().numpy()])}  )
    
    @torch.no_grad()
    def calculate_charge (self):
        """
        This function calculates the most important charge fields of the structure in post-production

        Usage
        -----
        engine.calculate_charge()
        engine.Qmf

        Parameters
        ----------
        None
        

        Raises
        ------
        None


        Returns
        ------
        None

        """
        static_charge                           = torch.zeros((self.row*self.col, len(self.V)), dtype=self.precision, device = self.P.device)
        for i in range(len(self.V)):
            static_charge[:, i]                 = self._get_fix_charge(self, i)
        if self.structure_type == 1:
            self.P_av                           = torch.reshape(self.P, (self.row*self.col, len(self.V))).mean(0)
            self.Qt_av                          = torch.reshape(self.Qt, (self.row*self.col, len(self.V))).mean(0)
            self.Qint                           = self.Qt_av + torch.reshape(static_charge, (self.row*self.col, len(self.V))).mean(0)
            self.Qmf               	            = (self.dd**2) *torch.matmul(self.B, static_charge) + (self.dd**2) * torch.matmul(self.B, torch.reshape(self.Qt, (self.row*self.col, len(self.V)))) + (self.dd**2)*torch.matmul(self.B+1, torch.reshape(self.P, (self.row*self.col, len(self.V)))) + self.V*self.CS*(self.dd**2)*self.row*self.col
            self.Qmd              	            = (self.dd**2) *torch.matmul(self.D, static_charge) + (self.dd**2) * torch.matmul(self.D, torch.reshape(self.Qt, (self.row*self.col, len(self.V)))) + (self.dd**2)*torch.matmul(self.D, torch.reshape(self.P, (self.row*self.col, len(self.V)))) - self.V*self.CS*(self.dd**2)*self.row*self.col
            self.Qmf                            = self.Qmf/(self.dd**2)/self.row/self.col
            self.Qmd                            = self.Qmd/(self.dd**2)/self.row/self.col
            if self.traps == 0:
                self.Q                          = self.Qmf
            else:
                self.Q                          = None

    @torch.no_grad()
    def calculate_voltagefields(self):
        Presh                                       = torch.reshape(self.P.transpose(0, 1), (self.row*self.col, len(self.V)))
        Qtresh                                      = torch.reshape(self.Qt.transpose(0, 1), (self.row*self.col, len(self.V)))

        static_charge                               = torch.zeros((self.row*self.col, len(self.V)), dtype=self.precision, device = self.device)
        for i in range(len(self.V)):
            static_charge[:, i]                     = self._get_fix_charge(self, i)
        static_charge                               = torch.reshape(static_charge.transpose(0, 1), (self.row*self.col, len(self.V)))
        
        if self.structure_type == 1:
            self.VD                                     = torch.matmul(self.C_coupl.t(), Presh + Qtresh + static_charge) + self.CF/self.C0*(self.V-self.Vfb)
            self.VD                                     = torch.reshape(self.VD, (self.row, self.col, len(self.V))).transpose(0, 1)
            self.VD_av                                  = torch.reshape(self.VD, (self.row*self.col, len(self.V))).mean(0)
            self.Efe_av                                 = self.CD/self.t_F/self.C0*(self.V-self.Vfb) +1/(self.row*self.col*self.eps0*self.epsF)*torch.matmul((Presh + Qtresh + static_charge).t(), self.B);  

    @torch.no_grad()
    def get_tau(self):
        return self.rho/2/torch.abs(CHECKTENSOR(self.a))

    @torch.no_grad()
    def transfermemory(self, device, seed = True):
        for k in dir(self):
            v               = getattr(self, k)
            if type(v) is torch.Tensor:
                setattr(self, k, v.to(device))

        if seed:
            for k in dir(self.seed):
                v               = getattr(self.seed, k)
                if type(v) is torch.Tensor:
                    setattr(self.seed, k, v.to(device))


    def download_file(self, url, filepath):
        with requests.get(url, allow_redirects=True) as r:
            with open(filepath, 'wb') as f:
                f.write(r.content)

    def download_structure(self, name):
        conf_url                        = "https://raw.githubusercontent.com/riccardo25/ferro_python/main/MFIM/{:s}/{:s}.conf".format(name, name)
        conf_file                       = "./desc_files/{:s}/{:s}.conf".format(name, name)
        glob_url                        = "https://raw.githubusercontent.com/riccardo25/ferro_python/main/MFIM/{:s}/{:s}.conf_glob.txt".format(name, name)
        glob_file                       = "./desc_files/{:s}/{:s}.conf_glob.txt".format(name, name)
        vmat_url                        = "https://raw.githubusercontent.com/riccardo25/ferro_python/main/MFIM/{:s}/{:s}.conf_vmat.txt".format(name, name)
        vmat_file                       = "./desc_files/{:s}/{:s}.conf_vmat.txt".format(name, name)
        self.download_file(conf_url, conf_file)
        self.download_file(glob_url, glob_file)
        self.download_file(vmat_url, vmat_file)
        
        
        if os.path.exists(conf_file) and os.path.exists(glob_file) and os.path.exists(vmat_file):
            pass      
        else:
            raise UsageError("ERROR 46625: Something went wrong during the downloading of the structure. Contact Riccardo (fontanini.riccardo@spes.uniud.it)")

    @torch.no_grad()
    def display_charges(self):

        plt.figure()
        
        if self.traps == 3 or self.traps == 4:           
            chargeadd =self.t_step*integrate.cumtrapz(torch.mean(self.IMF_in, 0)-torch.mean(self.IMF_out, 0))
        
        else:
           chargeadd = torch.zeros(torch.numel(self.time))

        charge = torch.sum(torch.reshape(self.Qt, (self.row*self.col, self.Qt.shape[-1])), 0)/self.row/self.col+self.sigma[0]

        colors = plt.rcParams["axes.prop_cycle"].by_key()['color']

        plt.plot(self.time*1e3, (self.Qmf+chargeadd)*100, linewidth = 2, label =  '$Q_{MF}$', color = colors[0])
        plt.plot(self.time*1e3, self.P_av*100, linewidth = 2, label =  '$P_{AV}$', color = colors[1])
        plt.plot(self.time*1e3, self.QtACC*100,'-r',linewidth =2,label = '$Q_{t,acc}$')
        plt.plot(self.time*1e3, self.QtDON*100,'-g',linewidth =2,label = '$Q_{t,don}$')
        plt.plot(self.time*1e3, charge*100,'--', linewidth = 4, label =  '$Q_{int,AV}$', color = 'c')
        plt.xlabel('time [ms]', fontsize = 18)
        plt.ylabel('Charge $[\mu C/cm^2]$', fontsize = 18)

        plt.tick_params('both', which='major', labelsize=18)
        
        ax1 = plt.gca()
        ax1.grid()
        ax2 = ax1.twinx()
        ax2.plot(self.time*1e3, self.V, linewidth = 2, label = '$V_T$', color = 'k')
        # ax2.set_xlabel('time [ms]')
        ax2.set_ylabel('$V_{T}$ [V]', fontsize = 18)
        ax2.set_yticks(np.arange(self.V.min().item(), self.V.max().item()+1, 1))
        ax2.grid(False)
        lines, labels = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax2.legend(lines + lines2, labels + labels2, fontsize = 18, ncol = 2)
        plt.tick_params('both', which='major', labelsize=18)
        fig = plt.gcf()
        fig.set_size_inches(10, 7.5)
        fig.tight_layout()
        plt.show(block = False)

    @torch.no_grad()
    def trap_position(self, reference):

        dE          = abs(self.Emax0-self.Emin0)/self.N_disc_traps
        Et_a        = np.linspace(self.Emax0, self.Emin0, self.N_disc_traps) - reference
        Et_d        = np.linspace(self.Emax0_don, self.Emin0_don, self.notset_N_disc_traps_don) - reference

        nfig        = plt.gcf().number+1
        plt.figure(nfig)
        plt.plot(Et_a/self.q, self.Nt*self.q/dE*1e-4, linewidth = 2, label = "$N_{acc}$")
        plt.plot(Et_d/self.q, self.Nt_don*self.q/dE*1e-4, linewidth = 2, label = "$N_{don}$")

        plt.xlabel("Trap energies [eV]", fontsize = 18)
        plt.ylabel("Trap density [cm$^{-2}$eV$^{-1}$]", fontsize = 18)
        plt.ticklabel_format(style='sci', axis='y', useMathText=True)
        plt.tick_params('both', which='major', labelsize=18)
        plt.legend(fontsize = 16)
        plt.grid()
        plt.gca().yaxis.offsetText.set_fontsize(16)
        fig = plt.gcf()
        fig.set_size_inches(10, 7.5)
        fig.tight_layout()
        plt.show(block = False)

    def linearization(self, index, frequency):
        index                                                   = CHECKTENSOR(index)
        f_pol                                                   = torch.zeros(self.row*self.col, device=self.device, dtype=self.precision)
        f_acc                                                   = torch.zeros(self.row*self.col*self.N_disc_traps, device=self.device, dtype=self.precision)
        f_don                                                   = torch.zeros(self.row*self.col*self.notset_N_disc_traps_don, device=self.device, dtype=self.precision)
        Npt                                                     = torch.numel(f_pol)+ torch.numel(f_acc)+ torch.numel(f_don)
        Ylin                                                    = torch.zeros(Npt, device=self.device, dtype=self.precision)
        Ycompl                                                  = torch.zeros((index.int().item()), device=self.device, dtype=self.precision)
        nc                                                      = torch.zeros((index.int().item()), device=self.device, dtype=self.precision)
        self.Edepth                                             = 5*self.q
        TMD_0                                                   = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), device=self.device, dtype=self.precision)
        TMF_0                                                   = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), device=self.device, dtype=self.precision)
        TMD                                                     = torch.zeros(((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), Npt), device=self.device, dtype=self.precision)
        TMF                                                     = torch.zeros(((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), Npt), device=self.device, dtype=self.precision)
        f_var                                                   = torch.zeros((Npt,Npt), device=self.device, dtype=self.precision)
        
        dE                                                      = torch.tensor((self.Emax0 -self.Emin0).abs()/self.N_disc_traps, device=self.device, dtype=self.precision)
        eps                                                     = torch.tensor(1e-6, device=self.device, dtype=self.precision)
        null_v                                                  = torch.tensor([], dtype=self.precision, device=self.device)
        for k in range(0, torch.numel(index)):
            Pol_0                                               = self.P[:, :, index[k].int().item()].transpose(0,1).flatten()
            fixedcharge                                         = self._get_fix_charge(self, k)
            if torch.numel(torch.tensor(self.tr_occ_acc.size())) > 1:                            
                tr_occ_acc_0                                        = self.tr_occ_acc[:, index[k]]
                tr_occ_don_0                                        = self.tr_occ_don[:, index[k]]
            else:

                tr_occ_acc_0                                        = self.tr_occ_acc
                tr_occ_don_0                                        = self.tr_occ_don


            Qt_0                                                = self.Qt[:, :, index[k].int().item()].transpose(0,1).flatten()
            beferro.calc_TMD_TMF(TMD_0, TMF_0, self.row, self.col, self.V[index[k].int().item()], self.VD[:, :, index[k].int().item()].transpose(0,1).flatten(), self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, torch.abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp)
            
            beferro.solver_ntr_dbpm_accanddon(f_acc, null_v, f_don, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, tr_occ_acc_0*self.Nt[0], tr_occ_don_0*self.Nt_don[0], TMD_0, TMF_0, self.row, self.col, self.V[index[k].int().item()], self.VD[:, :, index[k].int().item()].transpose(0,1).flatten(), self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 0)
            static_                                             = self.CpC*(Pol_0+Qt_0+fixedcharge)
            beferro.MFIMsolver(f_pol, Pol_0, self.V[index[k].int().item()], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, 0, self.rho, self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.B, 0, self.structure_type)
            
            f_notvar                                            = torch.cat((f_pol, f_acc, f_don), 0).unsqueeze(-1).repeat(1, Npt)
            
            y_var                                               = torch.cat((Pol_0, tr_occ_acc_0, tr_occ_don_0), 0).unsqueeze(-1).repeat(1, Npt) + eps*torch.eye(Npt, device = self.device, dtype = self.precision)
            Pol                                                 = y_var[0:self.row*self.col,:]
            ntr                                                 = y_var[self.row*self.col:(self.row*self.col+self.row*self.col*self.N_disc_traps), :] *self.Nt[0]
            ptr                                                 = y_var[self.row*self.col+self.row*self.col*self.N_disc_traps:self.row*self.col+self.row*self.col*self.N_disc_traps+self.row*self.col*self.notset_N_disc_traps_don, :] * self.Nt_don[0]
            Qt                                                  = -self.q*torch.reshape(ntr.transpose(0,1), (self.row*self.col, self.N_disc_traps, Npt)).sum(1) + self.q*(self.Nt_don[0]*self.notset_N_disc_traps_don - torch.reshape(ptr.transpose(0,1), (self.row*self.col, self.notset_N_disc_traps_don, Npt)).sum(1))
            Vd                                                  = torch.matmul(self.C_coupl.transpose(0,1), (Pol+fixedcharge.unsqueeze(-1).repeat(1, Npt) +Qt)) + self.CF/self.C0*(self.V[index[k].int().item()]-self.Vfb)
            static_var                                          = torch.matmul(self.CpC, (Pol+Qt+fixedcharge.unsqueeze(-1).repeat(1, Npt)))
            beferro.eval_TMD_TMF(TMD, TMF, self.row, self.col, self.V[index[k].int().item()], Vd, self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp, self.N_disc_traps, self.notset_N_disc_traps_don)
            beferro.eval_bigJ_linear(f_var, TMD, TMF, Pol, self.V[index[k].int().item()], static_var, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self.t_D, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, 0, self.rho, self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.B, 0, self.structure_type, ntr, ptr, Vd, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don)
            Jacobian                                            = -(f_var-f_notvar)/eps
            beferro.solver_ntr_dbpm_accanddon(f_acc, null_v, f_don, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, tr_occ_acc_0*self.Nt[0], tr_occ_don_0*self.Nt_don[0], TMD_0, TMF_0, self.row, self.col, self.V[index[k].int().item()]+eps, self.VD[:, :, index[k].int().item()].transpose(0,1).flatten(), self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 0)
            beferro.MFIMsolver(f_pol, Pol_0, self.V[index[k].int().item()]+eps, static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, 0, self.rho, self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.B, 0, self.structure_type)
            
            #Jacobian for V = df/dV_eps 
            Jacobian_V                                          = (torch.cat([f_pol, f_acc, f_don], 0) - f_notvar[:,0].flatten())/eps

            Jp_an                                               = 1/(self.t_F*self.rho)*((-2*torch.reshape(self.seed.a_eff.transpose(0, 1), ((self.row*self.col).item(), ) ) - 12*torch.reshape(self.seed.b_eff.transpose(0,1), ((self.row*self.col).item(), ) )*(Pol_0+Qt_0)**2-30*torch.reshape(self.seed.c_eff.transpose(0,1), ((self.row*self.col).item(), ) )*(Pol_0 + Qt_0)**4 * torch.eye(Pol_0.shape[0], device=self.device, dtype=self.precision))-0.5*self.CpC)
            
            

            dJ                                                  = torch.abs(torch.diag(Jacobian))
            idx                                                 = dJ[dJ<=1e-5]
            Jacobian[idx,:]                                     = []
            Jacobian[:,idx]                                     = []
            Jacobian_V[idx,:]                                   = []
            
            A                                                   = torch.complex(0,1) *2*torch.pi*frequency*torch.eye(Npt)-Jacobian
            
            #MATLAB EQUILIBRATION: P R C equilibration matrices,
            #starting system => Ay=b, A ill-conditioned, use
            #equilibrate to get matrix B which has better rcond(B) and
            #then solve system Bx=d with d = RPb, the starting y will be y=Cx
            
            
            #[P, R, C]                                           = equilibrate(A)
            #
            #B                                                   = gpuArray(R*P*A*C)
            #
            #d                                                   = R*P*Jacobian_V
            #
            #x                                                   = B\d
            
            
            #    Ylin(:,k)                                           = A\(Jacobian_V);
            #    Ylin(:,k)                                           = x;
            #
            #Ylin(:,k)                                           = [C*x; zeros(numel(idx),1)];
            
            Ylin                                                = torch.linalg.lstsq(A.to(self.device), Jacobian_V.to(self.device), rcond=None).solution

            Pol_lin                                             = Ylin[0:self.row*self.col-1, k]
            ntr_lin                                             = Ylin[self.row*self.col:self.row*self.col+self.row*self.col*self.N_disc_traps-1, k]
            ptr_lin                                             = Ylin[self.row*self.col+self.row*self.col*self.N_disc_traps:-1, k]
            
            Iqs_lin                                             = 0
            Pav_lin                                             = torch.mean(Pol_lin)
            ntr_sum                                             = torch.sum(torch.reshape(ntr_lin.transpose(0,1)*self.Nt[0], self.row*self.col, self.N_disc_traps), 1)
            ptr_sum                                             = torch.sum(torch.reshape(ptr_lin.transpose(0,1)*self.Nt_don[0], self.row*self.col, self.notset_N_disc_traps_don), 1)
            Qtav_lin                                            = -self.q*torch.mean(ntr_sum+ptr_sum)
            Ycompl[k]                                           = torch.complex(0,1)*2*torch.pi*frequency*self.CS + torch.complex(0,1)*2*torch.pi*frequency*(self.CD/self.C0*Pav_lin-self.CF/self.C0*Qtav_lin) + Iqs_lin
            nc[k]                                               = 1/torch.linalg.cond(A)
            print(f'Elaboration percentage: {k/torch.numel(index)*100}% -- V(t) = {self.V[index[k]].item()}V')

        return Ycompl, nc


    def linearization_Rollo(self, index, frequency, save_rcond = False):

        import nvidia_smi

        self.transfermemory("cuda")
        # w                                       = 2*np.pi*frequency

        Npt                                     = int(self.row*self.col*(1+self.N_disc_traps+self.notset_N_disc_traps_don))

        dummy                                   = torch.zeros((self.row*self.col, self.N_disc_traps), device = self.device, dtype=self.precision)

        dummy_don                               = torch.zeros((self.row*self.col, self.notset_N_disc_traps_don), device = self.device, dtype=self.precision)
            
        f_pol                                   = torch.zeros((self.row*self.col), device = self.device, dtype=self.precision)
        f_ntr                                   = torch.zeros((self.row*self.col*self.N_disc_traps), device = self.device, dtype=self.precision)
        f_ptr                                   = torch.zeros((self.row*self.col*self.notset_N_disc_traps_don), device = self.device, dtype=self.precision)
        Y                                       = torch.zeros(Npt, device=self.device, dtype=self.precision)
        Ycompl                                  = torch.complex(torch.zeros(torch.numel(frequency), device="cpu", dtype=self.precision), torch.zeros(torch.numel(frequency), device="cpu", dtype=self.precision))
        if save_rcond:
            nc                                      = torch.zeros(torch.numel(frequency), device="cpu", dtype=self.precision)
        
        flat_av                                 = self.seed.a_eff.transpose(0, 1).flatten().to(self.device)
        flat_bv                                 = self.seed.b_eff.transpose(0, 1).flatten().to(self.device)
        flat_cv                                 = self.seed.c_eff.transpose(0, 1).flatten().to(self.device)
        flat_dv                                 = self.seed.d_eff.transpose(0, 1).flatten().to(self.device)
    
        Jacobian                                = torch.zeros((Npt, Npt))
        eps                                     = torch.tensor(1e-5, device = "cpu", dtype=self.precision)
        Pol_0                                   = self.P[:, :, index].transpose(0, 1).flatten()
        Qt_0                                    = self.Qt[:, :, index].transpose(0, 1).flatten()

        ntr_0                                   = self.ntr.flatten().clone()
        ptr_0                                   = self.ntr_don.flatten().clone()

        # 


        delta                                   = eps*torch.cat((Pol_0, ntr_0, ptr_0), 0).cpu() + torch.cat((1e-5*torch.ones(int(self.row*self.col), device = "cpu", dtype=self.precision), 1e5*torch.ones(int(self.row*self.col*(self.N_disc_traps+self.notset_N_disc_traps_don)), device = "cpu", dtype=self.precision)))*(torch.cat((torch.abs(Pol_0), ntr_0, ptr_0), 0).cpu() <= torch.cat((torch.zeros(int(self.row*self.col), device = "cpu", dtype = self.precision), 1e10*torch.ones(int(self.row*self.col*(self.N_disc_traps+self.notset_N_disc_traps_don)), device = "cpu", dtype = self.precision))))

        y_var                                   = torch.cat((Pol_0, ntr_0, ptr_0),  0).cpu().unsqueeze(-1).repeat(1, Npt) +  delta*torch.eye(Npt, device = "cpu", dtype = self.precision)
        fixedcharge                             = self._get_fix_charge(self, index)
        static_                                 = torch.mv(self.CpC, Pol_0+Qt_0+fixedcharge)
        beferro.MFIMsolver(f_pol, Pol_0, self.V[index], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, int(0), self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)
        f_pol0                                  = -f_pol

        ntr_0                                   = torch.reshape(ntr_0, (self.row*self.col, self.N_disc_traps)).t().flatten()
        ptr_0                                   = torch.reshape(ptr_0, (self.row*self.col, self.notset_N_disc_traps_don)).t().flatten()

        Vd0                                     = torch.mv(self.C_coupl.transpose(0, 1), Pol_0+fixedcharge+Qt_0) + self.CF/self.C0*(self.V[index]-self.Vfb)
        beferro.solver_ntr_don(f_ntr, f_ptr, dummy, dummy, dummy_don, dummy_don, Vd0, self.row, self.col, ntr_0, ptr_0, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
        f_notvar                                = torch.cat((f_pol0, self.q*f_ntr, self.q*f_ptr), 0)
        
        Pol_var                                 = y_var[:self.row*self.col, :]
        ntr_var                                 = torch.reshape(y_var[self.row*self.col:self.row*self.col*(1+self.N_disc_traps), :], (self.row*self.col, self.N_disc_traps, Npt))
        ptr_var                                 = torch.reshape(y_var[self.row*self.col*(1+self.N_disc_traps):, :], (self.row*self.col, self.notset_N_disc_traps_don, Npt))
        Qt_var                                  = -self.q*ntr_var.sum(1) + self.q*(self.Nt_don.sum().cpu() - ptr_var.sum(1))
        static_var_tot                          = torch.matmul(self.CpC.cpu(), (Pol_var+Qt_var+fixedcharge.unsqueeze(-1).repeat((1, Npt)).cpu()))
        Vd_var                                  = torch.matmul(self.C_coupl.t().cpu(),(Pol_var+Qt_var+fixedcharge.unsqueeze(-1).repeat((1, Npt)).cpu())) + (self.CF/self.C0*(self.V[index]-self.Vfb)).cpu()



        for r in range (0, Npt):
            Pol                                 = Pol_var[:, r].to(self.device)
            # ntr                                 = torch.reshape(y_var[self.row*self.col:self.row*self.col*(1+self.N_disc_traps), r], (self.row*self.col, self.N_disc_traps)).to(self.device)
            # ptr                                 = torch.reshape(y_var[self.row*self.col*(1+self.N_disc_traps):, r], (self.row*self.col, self.notset_N_disc_traps_don)).to(self.device)
            # Qt                                  = -self.q*ntr.sum(1) + self.q*(self.Nt_don.sum()-ptr.sum(1))
            static_var                          = static_var_tot[:, r].to(self.device)
            Vd                                  = Vd_var[:, r].to(self.device)

            ntr                                 = ntr_var[:, :, r].t().flatten().to(self.device)            
            ptr                                 = ptr_var[:, :, r].t().flatten().to(self.device)

            beferro.solver_ntr_don(f_ntr, f_ptr, dummy, dummy, dummy_don, dummy_don, Vd, self.row, self.col, ntr, ptr, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
            beferro.MFIMsolver(f_pol, Pol, self.V[index], static_var, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, int(0), self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)
            Jacobian[:, r]                      = ((torch.cat((-f_pol, self.q*f_ntr, self.q*f_ptr), 0)-f_notvar)/delta[r]).cpu()
        

        Jacobian[:, self.row*self.col:]         = Jacobian[:, self.row*self.col:]/self.q


        deltaV                                  = eps*self.V[index] + eps*(self.V[index] == 0)

        Vd_V                                    = torch.mv(self.C_coupl.transpose(0, 1), Pol_0+fixedcharge+Qt_0) + self.CF/self.C0*(self.V[index]+deltaV-self.Vfb)
        beferro.solver_ntr_don(f_ntr, f_ptr, dummy, dummy, dummy_don, dummy_don, Vd_V, self.row, self.col, ntr_0, ptr_0, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
        beferro.MFIMsolver(f_pol, Pol_0, self.V[index]+deltaV, static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, int(0), self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)
        Jacobian_V                              = ((torch.cat((-f_pol, self.q*f_ntr, self.q*f_ptr), 0) - f_notvar)/deltaV).cpu()

        for k in range(0, torch.numel(frequency)):
            
            #

            nvidia_smi.nvmlInit()
            handle = nvidia_smi.nvmlDeviceGetHandleByIndex(0)
            info = nvidia_smi.nvmlDeviceGetMemoryInfo(handle)


            omega                               = 2*np.pi*frequency[k]
            A                                   = (torch.complex(torch.tensor(0, dtype=self.precision), torch.tensor(1, dtype=self.precision))*omega*torch.eye(Npt, device="cpu", dtype=self.precision)-Jacobian)

            
            #
            Y                                   = (torch.linalg.lstsq(A.to(self.device), torch.complex(Jacobian_V.to(self.device), torch.zeros(torch.numel(Jacobian_V), device = self.device, dtype = self.precision)), rcond=None).solution).cpu()
        
            Pav_lin                             = torch.mean(Y[:self.row*self.col])
            ntr_lin                             = torch.reshape(Y[self.row*self.col:self.row*self.col*(1+self.N_disc_traps)], (self.row*self.col, self.N_disc_traps))
            ptr_lin                             = torch.reshape(Y[self.row*self.col*(1+self.N_disc_traps):], (self.row*self.col, self.notset_N_disc_traps_don))
            Qtav_lin                            = -(torch.mean(ntr_lin.sum(1))+torch.mean(ptr_lin.sum(1)))
            Ycompl[k]                           = torch.complex(torch.tensor(0, dtype = self.precision), torch.tensor(1, dtype = self.precision))*omega*self.CS + torch.complex(torch.tensor(0, dtype = self.precision), torch.tensor(1, dtype = self.precision))*omega*(self.CD/self.C0*Pav_lin-self.CF/self.C0*Qtav_lin)
        
            if save_rcond:
                print(f'WARNING: Evaluating rcond requires lot of GPU RAM, check the total amount before proceeding, in linearization_Rollo')
                nc[k]                               = 1/torch.linalg.cond(A.to(self.device))
                
        if save_rcond:
            return Ycompl, nc

        else:
            return Ycompl
        

    def linearization_Rollo_parallel(self, index, frequency, save_rcond =False):

        import nvidia_smi

        self.transfermemory("cuda")
        # w                                       = 2*np.pi*frequency

        Npt                                             = int(self.row*self.col*(1+self.N_disc_traps+self.notset_N_disc_traps_don))
        
        dummy                                           = torch.zeros((self.row*self.col*self.N_disc_traps, Npt), device = self.device, dtype=self.precision)
        dummy_don                                       = torch.zeros((self.row*self.col*self.notset_N_disc_traps_don, Npt), device = self.device, dtype=self.precision)
                    
        f_pol                                           = torch.zeros((self.row*self.col), device = self.device, dtype=self.precision)
        f_ntr                                           = torch.zeros((self.row*self.col*self.N_disc_traps), device = self.device, dtype=self.precision)
        f_ptr                                           = torch.zeros((self.row*self.col*self.notset_N_disc_traps_don), device = self.device, dtype=self.precision)
        f_var                                           = torch.zeros((Npt, Npt), device = self.device, dtype=self.precision)
        Y                                               = torch.zeros(Npt, device=self.device, dtype=self.precision)
        Ycompl                                          = torch.complex(torch.zeros(torch.numel(frequency), device="cpu", dtype=self.precision), torch.zeros(torch.numel(frequency), device="cpu", dtype=self.precision))
        if save_rcond:
            nc                                              = torch.zeros(torch.numel(frequency), device="cpu", dtype=self.precision)
        
        flat_av                                         = self.seed.a_eff.transpose(0, 1).flatten().to(self.device)
        flat_bv                                         = self.seed.b_eff.transpose(0, 1).flatten().to(self.device)
        flat_cv                                         = self.seed.c_eff.transpose(0, 1).flatten().to(self.device)
        flat_dv                                         = self.seed.d_eff.transpose(0, 1).flatten().to(self.device)
            
        Jacobian                                        = torch.zeros((Npt, Npt))
        eps                                             = torch.tensor(1e-5, device = "cpu", dtype=self.precision)
        Pol_0                                           = self.P[:, :, index].transpose(0, 1).flatten()
        Qt_0                                            = self.Qt[:, :, index].transpose(0, 1).flatten()
        
        ntr_0                                           = self.ntr.flatten().clone()
        ptr_0                                           = self.ntr_don.flatten().clone()

        # 


        delta                                           = (eps*torch.cat((Pol_0, ntr_0, ptr_0), 0).cpu() + torch.cat((1e-5*torch.ones(int(self.row*self.col), device = "cpu", dtype=self.precision), 1e5*torch.ones(int(self.row*self.col*(self.N_disc_traps+self.notset_N_disc_traps_don)), device = "cpu", dtype=self.precision)))*(torch.cat((torch.abs(Pol_0), ntr_0, ptr_0), 0).cpu() <= torch.cat((torch.zeros(int(self.row*self.col), device = "cpu", dtype = self.precision), 1e10*torch.ones(int(self.row*self.col*(self.N_disc_traps+self.notset_N_disc_traps_don)), device = "cpu", dtype = self.precision)))))

        y_var                                           = torch.cat((Pol_0, ntr_0, ptr_0),  0).cpu().unsqueeze(-1).repeat(1, Npt) +  delta*torch.eye(Npt, device = "cpu", dtype = self.precision)
        fixedcharge                                     = self._get_fix_charge(self, index)
        static_                                         = torch.mv(self.CpC, Pol_0+Qt_0+fixedcharge)

        beferro.MFIMsolver(f_pol, Pol_0, self.V[index], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, int(0), self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)

        f_pol0                                          = -f_pol
        ntr_0                                           = torch.reshape(ntr_0, (self.row*self.col, self.N_disc_traps)).t().flatten()
        ptr_0                                           = torch.reshape(ptr_0, (self.row*self.col, self.notset_N_disc_traps_don)).t().flatten()
        Vd0                                             = torch.mv(self.C_coupl.transpose(0, 1), Pol_0+fixedcharge+Qt_0) + self.CF/self.C0*(self.V[index]-self.Vfb)

        beferro.solver_ntr_don(f_ntr, f_ptr, dummy, dummy, dummy_don, dummy_don, Vd0, self.row, self.col, ntr_0, ptr_0, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)

        f_notvar                                        = torch.cat((f_pol0, self.q*f_ntr, self.q*f_ptr), 0)

        Pol_var                                         = y_var[:self.row*self.col, :]
        ntr_var                                         = torch.reshape(y_var[self.row*self.col:self.row*self.col*(1+self.N_disc_traps), :], (self.row*self.col, self.N_disc_traps, Npt))
        ptr_var                                         = torch.reshape(y_var[self.row*self.col*(1+self.N_disc_traps):, :], (self.row*self.col, self.notset_N_disc_traps_don, Npt))
        Qt_var                                          = -self.q*ntr_var.sum(1) + self.q*(self.Nt_don.sum().cpu() - ptr_var.sum(1))
        ntr_var                                         = torch.flatten(torch.transpose(ntr_var, 0, 1), 0, 1)
        ptr_var                                         = torch.flatten(torch.transpose(ptr_var, 0, 1), 0, 1)
        static_var_tot                                  = torch.matmul(self.CpC.cpu(), (Pol_var+Qt_var+fixedcharge.unsqueeze(-1).repeat((1, Npt)).cpu()))
        Vd_var                                          = torch.matmul(self.C_coupl.t().cpu(),(Pol_var+Qt_var+fixedcharge.unsqueeze(-1).repeat((1, Npt)).cpu())) + (self.CF/self.C0*(self.V[index]-self.Vfb)).cpu()

        # 

        del y_var       

        Pol_var                                         =    Pol_var.to(self.device).t().flatten()
        ntr_var                                         =    ntr_var.to(self.device).t().flatten()
        ptr_var                                         =    ptr_var.to(self.device).t().flatten()
        Qt_var                                          =    Qt_var.to(self.device).t().flatten()
        static_var_tot                                  =    static_var_tot.to(self.device).t().flatten()
        Vd_var                                          =    Vd_var.to(self.device).t().flatten()




        beferro.bigJ_rollo(f_var, Pol_var, self.V[index], static_var_tot, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self.t_D, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, int(0), self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type, dummy, dummy, dummy_don, dummy_don, Vd_var, ntr_var, ptr_var, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)

        # 


        del Pol_var
        del ntr_var
        del ptr_var
        del Qt_var
        del static_var_tot
        del Vd_var

        torch.cuda.empty_cache()

        f_var                                           = f_var.t()

        #

        f_var[:self.row*self.col, :]                    = -f_var[:self.row*self.col, :] #perchè rollo ha scritto la funzione col segno girato

        f_var[self.row*self.col:, :]                    = f_var[self.row*self.col:, :]*self.q

        
        Jacobian                                        = (f_var-f_notvar.unsqueeze(-1).repeat((1, Npt)))/delta.to(self.device)




        Jacobian[:, self.row*self.col:]                 = Jacobian[:, self.row*self.col:]/self.q

        #

        deltaV                                          = eps*self.V[index] + eps*(self.V[index] == 0)

        Vd_V                                            = torch.mv(self.C_coupl.transpose(0, 1), Pol_0+fixedcharge+Qt_0) + self.CF/self.C0*(self.V[index]+deltaV-self.Vfb)
        beferro.solver_ntr_don(f_ntr, f_ptr, dummy, dummy, dummy, dummy, Vd_V, self.row, self.col, ntr_0, ptr_0, self.en0, self.en0_don, self.Nt, self.Nt_don, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.Emin0_don, self.Emax0_don, self.N_disc_traps, self.notset_N_disc_traps_don, self.Temp)
        beferro.MFIMsolver(f_pol, Pol_0, self.V[index]+deltaV, static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, int(0), self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)
        Jacobian_V                                      = ((torch.cat((-f_pol, self.q*f_ntr, self.q*f_ptr), 0) - f_notvar)/deltaV).cpu()

        for k in range(0, torch.numel(frequency)):
            
            nvidia_smi.nvmlInit()

            handle = nvidia_smi.nvmlDeviceGetHandleByIndex(0)

            info = nvidia_smi.nvmlDeviceGetMemoryInfo(handle)


            omega                               = 2*np.pi*frequency[k]
            A                                   = (torch.complex(torch.tensor(0, device=self.device, dtype=self.precision), torch.tensor(1, device=self.device, dtype=self.precision))*omega*torch.eye(Npt, device=self.device, dtype=self.precision)-Jacobian)


            Y                                   = (torch.linalg.lstsq(A, torch.complex(Jacobian_V.to(self.device), torch.zeros(torch.numel(Jacobian_V), device = self.device, dtype = self.precision)), rcond=None).solution).cpu()
        
            Pav_lin                             = torch.mean(Y[:self.row*self.col])
            ntr_lin                             = torch.reshape(Y[self.row*self.col:self.row*self.col*(1+self.N_disc_traps)], (self.row*self.col, self.N_disc_traps))
            ptr_lin                             = torch.reshape(Y[self.row*self.col*(1+self.N_disc_traps):], (self.row*self.col, self.notset_N_disc_traps_don))
            Qtav_lin                            = -(torch.mean(ntr_lin.sum(1))+torch.mean(ptr_lin.sum(1)))
            Ycompl[k]                           = torch.complex(torch.tensor(0, dtype = self.precision), torch.tensor(1, dtype = self.precision))*omega*self.CS + torch.complex(torch.tensor(0, dtype = self.precision), torch.tensor(1, dtype = self.precision))*omega*(self.CD/self.C0*Pav_lin-self.CF/self.C0*Qtav_lin)
        
            if save_rcond:
                print(f'WARNING: Evaluating rcond requires lot of GPU RAM, check the total amount before proceeding, in linearization_Rollo_parallel')
                nc[k]                               = 1/torch.linalg.cond(A.to(self.device))


        if save_rcond:
            return Ycompl, nc

        else:
            return Ycompl

    def CurrentFTJ_TAT(self, indices, trap_position, sigmaNt, energy_diff, calculate_direct):

        if calculate_direct:
            sigmaNt                                 = 1
            trap_position                           = torch.tensor([self.t_F+self.t_D])


        trap_position                               = torch.sort(trap_position)[0]
        J_tat_matrix_eV                             = torch.zeros((self.energy_disc_tunnel, trap_position.numel(), self.row*self.col))
        J_tat_matrix                                = torch.zeros((1, trap_position.numel(), self.row*self.col))
        J_dom_tat                                   = torch.zeros((self.row, self.col, indices.numel()))
        J_tat_mean                                  = torch.zeros((indices.numel(), trap_position.numel()))
        x                                           = torch.linspace(0, self.t_F+self.t_D, self.length_disc_tunnel)
        x_fe                                        = x[x<=self.t_F]
        x_ox                                        = x[x>self.t_F]
        x0                                          = trap_position.repeat(self.energy_disc_tunnel, 1)

        for ind in range(0, indices.numel()):

            for k in range(0, self.row):
                for j in range(0, self.col):

                    deltaV                                  = self.q*self.V[indices[ind]]
                    EF_B                                    = 0
                    EF_T                                    = -deltaV

                    fermi_emitter                           = torch.max(torch.tensor([EF_B, EF_T]))
                    fermi_collector                         = torch.min(torch.tensor([EF_B, EF_T]))
                    energy_min                              = fermi_collector-(150*self.Kb*self.Temp)
                    energy_max                              = fermi_emitter+(150*self.Kb*self.Temp)
                    trap_energies                           = torch.linspace(energy_min, energy_max, self.energy_disc_tunnel)

                    costante_impinging                      = self.mu*(self.m0**(3/2)*self.Kb*self.Temp*self.q)/(2*np.pi**2*np.sqrt(self.m0)*self.h_r**3)

                    jUP                                     = torch.sign(deltaV)*costante_impinging*np.exp((fermi_emitter-trap_energies)/(self.Kb*self.Temp), dtype=np.float64)
                    jDW                                     = torch.sign(deltaV)*costante_impinging*np.log(1 + np.exp((fermi_emitter-trap_energies)/(self.Kb*self.Temp), dtype = np.float64), dtype=np.float64)
                    limEM                                   = np.exp((fermi_emitter-trap_energies)/(self.Kb*self.Temp), dtype = np.float64) < 1e-10


                    j_impinging_em                          = jUP*limEM.to(int)
                    j_impinging_em                          = j_impinging_em+jDW*(~limEM).to(int)

                    jUP                                     = torch.sign(deltaV)*costante_impinging*np.exp((fermi_collector-trap_energies)/(self.Kb*self.Temp), dtype = np.float64)
                    jDW                                     = torch.sign(deltaV)*costante_impinging*np.log(1 + np.exp((fermi_collector-trap_energies)/(self.Kb*self.Temp), dtype = np.float64), dtype = np.float64)
                    limCO                                   = np.exp((fermi_collector-trap_energies)/(self.Kb*self.Temp), dtype = np.float64) < 1e-10
                    j_impinging_co                          = jUP*limCO.to(int)
                    j_impinging_co                          = j_impinging_co+jDW*(~limCO).to(int)

                    j_norm                                  = j_impinging_em-j_impinging_co

                    j_norm                                  = j_norm.unsqueeze(-1).repeat((1, trap_position.numel()))

                    Eox                                     = self.VD[k, j, indices[ind]]/self.t_D
                    Efe                                     = (self.V[indices[ind]]-self.VD[k, j, indices[ind]])/self.t_F

                    #alpha_energy                            = torch.tensor(self.WF_T - self.Chi_fe - self.V[indices[ind]]*self.q - trap_energies, dtype = torch.cdouble)
                    alpha_energy                            = (self.WF_T - self.Chi_fe - self.V[indices[ind]]*self.q - trap_energies).type(torch.cdouble)
                    #beta_energy                             = torch.tensor(self.WF_T - self.Chi_ox - self.VD[k, j, indices[ind]]*self.q - trap_energies, dtype = torch.cdouble)
                    beta_energy                             = (self.WF_T - self.Chi_ox - self.VD[k, j, indices[ind]]*self.q - trap_energies).type(torch.cdouble)


                    alpha_energy                            = alpha_energy.unsqueeze(-1).repeat((1, trap_position.numel()))
                    beta_energy                             = beta_energy.unsqueeze(-1).repeat((1, trap_position.numel()))

                    lnT1_pre                                = -4/(3*self.h_r*self.q)*np.sqrt(2*self.m_eff_fe)/Efe*((alpha_energy+self.q*Efe*x0)**(3/2)-alpha_energy**(3/2))
                    lnT2_pre                                = -4/(3*self.h_r*self.q)*(np.sqrt(2*self.m_eff_fe)/Efe*((alpha_energy+self.q*Efe*self.t_F)**(3/2)-(alpha_energy+self.q*Efe*x0)**(3/2)) + np.sqrt(2*self.m_eff_ox)/Eox*((beta_energy+self.q*Eox*self.t_D)**(3/2) - beta_energy**(3/2)))

                    lnT1_pre                                = lnT1_pre * (x0 < self.t_F)
                    lnT2_pre                                = lnT2_pre * (x0 < self.t_F)


                    lnT1_post                               = -4/(3*self.h_r*self.q)*(np.sqrt(2*self.m_eff_fe)/Efe*((alpha_energy+self.q*Efe*self.t_F)**(3/2)-alpha_energy**(3/2)) +np.sqrt(2*self.m_eff_ox)/Eox*((beta_energy+self.q*Eox*(x0-self.t_F))**(3/2)-beta_energy**(3/2)))
                    lnT2_post                               = -4/(3*self.h_r*self.q)*np.sqrt(2*self.m_eff_ox)/Eox*((beta_energy+self.q*Eox*self.t_D)**(3/2)-(beta_energy+self.q*Eox*(x0-self.t_F))**(3/2))
                    lnT1_post     	                        = lnT1_post * (x0>self.t_F)
                    lnT2_post                               = lnT2_post * (x0>self.t_F)

                    lnT1_int                                = -4/(3*self.h_r*self.q)*np.sqrt(2*self.m_eff_fe)/Efe*((alpha_energy+self.q*Efe*self.t_F)**(3/2)-alpha_energy**(3/2))
                    lnT2_int                                = -4/(3*self.h_r*self.q)*np.sqrt(2*self.m_eff_ox)/Eox*((beta_energy+self.q*Eox*self.t_D)**(3/2)-beta_energy**(3/2))

                    lnT1_int    	                        = lnT1_int * (x0==self.t_F)
                    lnT2_int                                = lnT2_int * (x0==self.t_F)

                    lnT1           	                        = lnT1_pre + lnT1_post +lnT1_int
                    lnT2           	                        = lnT2_pre + lnT2_post +lnT2_int
                    T1                                      = abs(torch.exp(lnT1))
                    T2            	                        = abs(torch.exp(lnT2))


                    U_fe                                    = self.WF_T - self.Chi_fe - deltaV + (Efe*x_fe)*self.q
                    U_ox                                    = U_fe[-1] + self.Chi_fe - self.Chi_ox + (Eox*(x_ox - self.t_F))*self.q 
                    U                                       = torch.cat([U_fe, U_ox], 0)

                    space                                   = x.unsqueeze(0).repeat((trap_position.numel(),1))
                    space                                   = space * (x <= trap_position.t()).to(int)
                    idlast                                  = torch.max(space[:, 1:], 1)[1]+1
                    #energy_pos                              = torch.gather(space, 1, idlast.unsqueeze(-1))


                    if calculate_direct:        

                        J_tat_x_eV	                        = (sigmaNt * j_norm * (T1 * T2)/(T1 + T2)).flatten()

                    else:                        

                        trap_energy_max                     = U[idlast] - energy_diff
                        J_tat_x_eV	                        = (sigmaNt * j_norm * (T1 * T2)/(T1 + T2) * (trap_energies.unsqueeze(1).repeat((1, trap_position.numel())) <= trap_energy_max.unsqueeze(0).repeat((trap_energies.numel(),1)))).flatten()


                    if len(J_tat_x_eV.shape) < 2:
                        J_tat_x_eV                          = J_tat_x_eV.unsqueeze(-1)

                    J_tat_matrix_eV[:,:, k*self.row+j]  = J_tat_x_eV.clone()
                        
                    J_tat_x                                 = torch.tensor(integrate.trapz(J_tat_x_eV, axis = 0), dtype=torch.double)*(trap_energies[1]-trap_energies[0])
                    J_tat_matrix[:,:, k*self.row+j]     = J_tat_x



            J_tat_mean[ind, :]                              = J_tat_matrix.mean(-1)
            J_dom_tat[:, :, ind]                            = J_tat_matrix.reshape((self.row, self.col))

            print(f"Percentage: {(ind+1)/indices.numel()*100}%")


        return J_dom_tat, J_tat_mean   



    def calculate_tunnelling_current(self, indices, trap_position = torch.tensor([torch.nan]), sigmaNt = torch.tensor([torch.nan]), energy_diff = torch.tensor([torch.nan]), enable_traps = False):
        
        if self.V.numel() == 0:
            raise ValueError('Error 104: input signal not simulated, in calculate_tunnelling_current')

        if not torch.is_tensor(indices):
            indices                     = torch.tensor(indices)

        if indices[0] < 0 or indices[0] > indices[-1]:
            raise ValueError('Error 105: start index not valid, in calculate_tunnelling_current')

        if indices[-1] >= self.V.shape[-1]:
            raise ValueError('Error 106: stop index not valid, in calculate_tunnelling_current')

        if not torch.is_tensor(trap_position):
            trap_position               = torch.tensor(trap_position)

        if not torch.is_tensor(sigmaNt):
            sigmaNt                     = torch.tensor(sigmaNt)

        if not torch.is_tensor(energy_diff):
            energy_diff                 = torch.tensor(energy_diff)

        if trap_position.numel() > 1:
            raise ValueError('Error 107: trap position cannot have more than one element, in calculate_tunnelling_current')


        if not enable_traps and not(torch.isnan(trap_position) and torch.isnan(sigmaNt) and torch.isnan(energy_diff)):
            warnings.warn("'You selected direct tunneling: trap_position, sigmaNt and energy_diff will be ignored!!!, in calculate_tunnelling_current")

        self.j_dom                      = torch.tensor([], dtype = self.precision)
        self.j_tat_mean                 = torch.tensor([], dtype = self.precision)

        J_dom_tat, J_tat_mean       = self.CurrentFTJ_TAT(indices, torch.tensor(nan), torch.tensor(nan), torch.tensor(nan), True)
        self.j_dom                  = J_dom_tat
        self.j_tunnel_media         = J_tat_mean
        J_tunn_media                = self.j_tunnel_media
        j_dom                       = self.j_dom


        if enable_traps:
            J_dom_tat, J_tat_mean   = self.CurrentFTJ_TAT(indices, trap_position, sigmaNt, energy_diff, False)
            self.j_tat_mean         = J_tat_mean
            self.j_dom              = self.j_dom + J_dom_tat
            self.j_tunnel_media     = self.j_tunnel_media + self.j_tat_mean

        return J_tunn_media, j_dom, J_dom_tat, J_tat_mean