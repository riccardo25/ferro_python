import torch
import numpy as np
import pdb
import time as tt
import warnings
import os
from torch._C import dtype
from tqdm import tqdm                 #pip install tqdm
import bz2
from decimal import Decimal 
import beferrosimulatorcuda as beferro
import pickle
import requests
import shutil
import json



import matplotlib.pyplot as plt

def CHECKTENSOR(tens, precision=torch.double, device='cuda'):
    if not torch.is_tensor(tens):
        return torch.tensor(tens, dtype=precision, device=device)
    else:
        return tens.to(precision).to(device)


########################################### USER FUNCTION TO GET THE CHARGE #####################################
def standard_get_fix_charge(contest, index):
    #in case of fixed charge index is useless
    return contest.sigmarow

def _Qset_from_output(contest, index):
    return contest.Qt_set[:, :, index].transpose(0,1).flatten()

#################################################################################################################

class Seed:
    def __init__(self, engine):
        #control parameters
        self.row                                = CHECKTENSOR(engine.row).clone()
        self.col                                = CHECKTENSOR(engine.col).clone()
        self.a                                  = CHECKTENSOR(engine.a).clone()
        self.b                                  = CHECKTENSOR(engine.b).clone()
        self.c                                  = CHECKTENSOR(engine.c).clone()
        self.d                                  = CHECKTENSOR(engine.d).clone()
        self.t_F                                = CHECKTENSOR(engine.t_F).clone()
        self.t_D                                = CHECKTENSOR(engine.t_D).clone()
        self.Vstart                             = CHECKTENSOR(engine.V[0]).item()

        #save parameters
        self.Pstart                             = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.Ec_dist                            = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.Pr_dist                            = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.Pc_dist                            = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.a_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.b_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.c_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)
        self.d_eff                              = torch.zeros([engine.row, engine.col], dtype=engine.precision, device=engine.device)


    def copy_seed(self, engine):
        #control parameters
        self.row                                = CHECKTENSOR(engine.row).clone()
        self.col                                = CHECKTENSOR(engine.col).clone()
        self.a                                  = CHECKTENSOR(engine.a).clone()
        self.b                                  = CHECKTENSOR(engine.b).clone()
        self.c                                  = CHECKTENSOR(engine.c).clone()
        self.d                                  = CHECKTENSOR(engine.d).clone()
        self.t_F                               = CHECKTENSOR(engine.t_F).clone()
        self.t_D                               = CHECKTENSOR(engine.t_D).clone()
        self.Vstart                             = CHECKTENSOR(engine.V[0]).item()

        #save parameters
        self.Pstart                             = CHECKTENSOR(engine.seed.Pstart).clone()
        self.Ec_dist                            = CHECKTENSOR(engine.seed.Ec_dist).clone()
        self.Pr_dist                            = CHECKTENSOR(engine.seed.Pr_dist).clone()
        self.Pc_dist                            = CHECKTENSOR(engine.seed.Pc_dist).clone()
        self.a_eff                              = CHECKTENSOR(engine.seed.a_eff).clone()
        self.b_eff                              = CHECKTENSOR(engine.seed.b_eff).clone()
        self.c_eff                              = CHECKTENSOR(engine.seed.c_eff).clone()
        self.d_eff                              = CHECKTENSOR(engine.seed.d_eff).clone()
    
    def is_compatible(self, engine):
        return (self.row == engine.row and self.col == engine.col and self.a == engine.a and self.b == engine.b and self.c == engine.c and self.d == engine.d and self.t_F == engine.t_F and self.t_D == engine.t_D ).item()


class Engine:

    @torch.no_grad()
    def __init__(self, device='cuda', precision=torch.double):
        print("Ciao Suzanne and Justine :)")
        self.device                             = device
        self.precision                          = precision    
        ## Paths        
        #path of var saving file        
        self.var_saving_path                    = 'vars/var.pkl'
        #path to save initialization var        iables 
        self.var_seed_path                      = 'vars/seed.pkl'
        #name file of Specogna program (        generated in init_params)
        self.struct_file_name                   = ''
        #path where the specogna program         is located in self PC (absolute is
        #better)        
        self.path_specogna                      = 'C:\\ngsolver\\specogna\\newistance\\'

        self.seed                               = None # MUST be implemented with Seed(self)
                
        ## General constants        
        self.Temp                               = 300                       # [K] temperature
        self.q                                  = 1.60217662e-19            # [C] fundamental charge value
        self.eps0                               = 8.8541878128e-12          # [F/m] Vacuum permittivity
        self.h_r                                = 1.05457168e-34            # [J*s] Planck's reduced constant
        self.Kb                                 = 1.380649e-23              # [J/K] Boltzmann const
        self.m0                                 = 9.109383e-31              # [Kg] Free-electron mass
        
            #   # Simulator Parameters      
        self.theta                              = 0.5                       # theta parameter 0.5=trapez, 1=Euler implicit
        self.structure_type                     = 1                         # 0=>'MFM', 1=>'MFIM', 2=>'MFMIM'
        self.distr_type                         = 'distrab'                 # 'distrab' or 'distrecpc'. realization control parameter
        self.bound_cond                         = 1                         # 'standard' = 0 or 'periodic' = 1
        self.traps                              = 0                         # 'none' = 0, 'static'= 1, 'dynamic (Nanoscale 2020)' = 2, 
                                                                            # 'dynimatic with tunneling' = 3, 'dynamic with tunneling, improved' = 4
        self.enable_integral                    = False                     # Enable the integral version for JMF and JMD (engine.traps == 3 only)

        self.var_J                              = 1e-7                     #epsilon for Jacobian calculation
                
        self.row                                = 6                         # Number of rows of domains
        self.col                                = 6                         # Number of columns of domains
        self.numberofparam                      = 2                         # Number of LKE parameters (alpha, beta, gamma)
        self.t_step                             = 0                         # Time step of the simulation
        #tunnelling parameters      
        self.energy_disc_tunnel                 = 300
        self.length_disc_tunnel                 = 600
                
                
        ## WKB and Band parameters      
        self.mu                                 = 1                         # Electrodes multiplicity
        self.WF_T                               = 4.45 *1.60217662e-19#*q	# [J] Work function top electrode (fe)
        self.WF_B                               = 4.45 *1.60217662e-19#*q	# [J] Work function bottom electrode (ox)
        self.Chi_fe                             = 2.1 *1.60217662e-19#*q	# [J] Electron affinity Ferroel
        self.Chi_ox                             = 1.35 *1.60217662e-19#*q	# [J] Electron affinity ox
        self.m_eff_fe                           = 0.3 *9.109383E-31#*m0     # [Kg] Effective mass ferroel
        self.m_eff_ox                           = 0.2 *9.109383E-31#*m0     # [Kg] Effective mass oxide
        
        
        ## General Model Constants
        self.rho                                = 300e-3                    # [Ohm*m] Damping constant/nominal resistivity of ferroel
        self.k_coupl                            = 2e-10#2e-9                # [m3/F] Domain wall factor     
        self.sigma                              = 0*-0.13                   # [C/m2] Fixed interface charge

        ## ferroelectric parameters
        self.t_F                                = 18.2e-9                   # [m] Ferroelectric thickness
        self.w                                  = 0.5e-9                    # energy-wall size [m]
        self.dd                                 = 5e-9                      # domain size [m]
        self.epsF                               = 33                        # Ferroelectric relative permittivity

        ## Oxide parameters (if Cs_th is set to zero, no oxide layer is considered)
        self.epsD                              = 8                         # Oxide relative permittivity
        self.t_D                               = 1.6e-9                    # [m] dielectric oxide thickness
        
        ## FERROELECTRIC coefficients for LKE
        self.a                                  = -9.45e8#-1.886e9          #[m/F]
        self.b                                  = 2.25e10#9e+10             #[m^5/F/coul^2]
        self.c                                  = 0                         #[m^9/F/coul^4]
        self.d                                  = 0
        self.Ec                                 = 0                         # [V/m] Corcitive Electric Field
        self.Pc                                 = 0                         # [C/m^2] Coercitive Polarization
        self.Pr                                 = 0                         # [C/m^2] Remnant Polarization

        self.sigmaRelEc_a                       = 0.08                      # [] Relative standard deviation of Coercitive Electric field, or alpha: sigma = Relsigma * Ec
        self.sigmaRelPc_b                       = 0.08                      # [] standard deviation of Coercitive Polarization, or beta: sigma = Relsigma * Pc
        self.sigmaRelPr_c                       = 0.08                      # [] standard deviation of Remnant Polarization, or gamma: sigma = Relsigma * Pr

        ## simulator fields     
        self.P                                  = []                        # [C/m^2] Polarization
        self.tempo                              = []                        # [s] interpolated time
        self.V                                  = []                        # [V] interpolated input voltage
        self.VD                                 = []                        # [V] 'average' voltage between ox and ferroel for each domain
        self.Efe_av                             = []                        # avarage Electric field in the ferroelectric ??? don't know
        self.Qt                                 = []                        # [C/m^2] Trapped charge inside between ferroelectric and dielectric materials
        self.Q                                  = []                        # [C] total charge (must be equal to Qmf or Qmd)
        self.Qmf                                = []                        # [C/m^2] charge at Ferroelectric-metal
        self.Qmd                                = []                        # [C/m^2] charge at Dielectric-metal
        self.P_av                               = []                        # [C/m^2] average polarization
        self.VD_av                              = []                        # [V] average oxide voltage
 
        #####################################################################
        #####################################################################
        #                      Tunneling model parameters                   
        # In self simulare are implemplemented 4 types of charge trapping    
        # models, you can select with engine.traps:                          
        # engine.traps = 0 -> no traps
        # -------------------------------------------------------------------
        # engine.traps = 1 -> static traps
        # -------------------------------------------------------------------
        # engine.traps = 2 -> dynamic traps (Nanoscale 2020)
        # -------------------------------------------------------------------
        #         dynamic traps with tunnelling parameters
        # engine.traps = 3 + engine.enable_integral = false -> approximated
        # version with Meff
        # engine.traps = 3 + engine.enable_integral = true -> numerical
        # calculation of the integral
        # -------------------------------------------------------------------
        # engine.traps = 4 -> dynamic traps with tunnelling parameters and 
        # detailed balance principle                                                                
        #####################################################################
        #####################################################################
        
        # ALL traps models parameters
        self.N_disc_traps                       = 10                        # number of traps levels
        self.notset_N_disc_traps_don            = 0                         # # of donor levels (NOT set self value in MAIN. This is calculated accordingly N_disc_traps)
        self.ntr                                = []                        # starting density of traps -> [row, col, trap_level, time]
        self.ntr_don                            = []
        self.Emin0                              = 4*1.60217e-19#*q          # [J] Minimum trap energy
        self.Emax0                              = -0 *1.60217e-19#*q        # [J] Maximum trap energy
        self.Emin0_don                          = 4*1.60217e-19
        self.Emax0_don                          = -0 *1.60217e-19
        self.Nacc                               = 1e17/1.60217e-19          # [1/eV/m^2 /e- charge]=[1/J/m^2]
        self.Nacc_don                           = 1e17/1.60217e-19
        self.Nt                                 = -1                        # [m-2] Trap density always taken as self.Nacc * abs(self.Emin0-self.Emax0) / self.N_disc_traps
        self.Nt_don                             = -1  
        # ------------------------------        -------------------------------------
        # model 1-2     
        self.en0                                = 5e7                       # [s^-1] bias indipendent emission rate 
        # -------------------------------------------------------------------
        # model 3-4
        self.nu                                 = 1e5                       # [s^-1] Escape Rate
        self.N_integr_points                    = 100                       # [] Integration Points (CPU only, not GPU)
        self.sigmaTraps                         = 1e-19                     # [m^2] Traps Area Cross-Section 
        self.sigmaTraps_don                     = 1e-19                     # [m^2] Traps Area Cross-Section 
        self.sigmaEnergy                        = 6.4087e-22                # [J] Traps Energy Cross-Section
        self.sigmaEnergy_don                    = 6.4087e-22                # [J] Traps Energy Cross-Section
        self.Meff                               = 1e14                      # [m^-2] Modes in the metal (only engine.traps = 3 and engine.enable_integral = false )
        self.Edepth                             = 10*1.60217662e-19         # [J] Range of energy integration
        self.IMD_in                             = []                        # [A/m^2] Input traps tunneling current (Metal-Dielectric side)
        self.IMD_out                            = torch.zeros((self.row, self.col), dtype=self.precision, device=self.device)
        self.QtACC                              = []
        self.QtDON                              = []

        self.tr_occ_acc                         = torch.zeros((1), dtype=self.precision, device=self.device)
        self.tr_occ_don                         = torch.zeros((1), dtype=self.precision, device=self.device)


        return 
    
    
    @staticmethod
    def  TwoParamModel_extractabcd(Ec, Pc):
            # This function extract alpha, beta accordingly the 2
            # Parameters Model
            # Ec is the coercitive Electric field 
            # Pc is the coercitive Polarization
            c                                   = 0
            d                                  = 0
            #OLD VALUES
            a                                   = torch.real(3/4 * Ec/Pc)
            b                                   = -torch.real(1/8* Ec/torch.pow(Pc, 3))
            #b                                       = -1/8* Ec/Pc^3 -1/8/(Pc^2)/C0/t_F
            #a                                       = Ec/2/Pc -2*b*Pc^2
            
            return a,b,c,d
    
    
    @staticmethod
    def  TwoParamModel_extractEcPc(a, b): 
        #OLD VALUES 
        Ec                                  = torch.real(4/3*torch.abs(a)*torch.sqrt(torch.abs(a)/6/b))
        Pc                                   = -torch.real(torch.sqrt(torch.abs(a)/6/b))
        #Pc                                      = -sqrt((-a*2*t_F-1/C0)/12/b/t_fe);
        #Ec                                      = 2*a*Pc+4*b*Pc^3;
        Pr                                 = -torch.real(torch.sqrt(torch.abs(a)/2/b))

        return Ec,Pc,Pr

        # Three params model functions
    
    
    @staticmethod
    def ThreeParamModel_extractabcd(Ec, Pc, Pr):
        Ec = Ec.to(torch.float64)
        Pc = Pc.to(torch.float64)
        Pr = Pr.to(torch.float64)
        #3 model param must be computed numerically
        B                                   = torch.tensor([Ec, 0, 0], device = Ec.device, dtype=Ec.dtype)
        A = torch.tensor([  [ 2*Pc,   4*torch.pow(Pc, 3),   6*torch.pow(Pc, 5)],
                            [ 2*Pr,   4*torch.pow(Pr, 3),   6*torch.pow(Pr, 5)],
                            [ 2,     12*torch.pow(Pc, 2),  30*torch.pow(Pc, 4)]], device = Ec.device, dtype=Ec.dtype)
        sol                                 = torch.linalg.lstsq(A, B).solution
        a                                   = sol[0]
        b                                   = sol[1]
        c                                   = sol[2]
        d                                   = 0

        return a,b,c,d
    
    
    @staticmethod
    def ThreeParamModel_extractEcPc(a, b, c):
        #get Corcitive values
        pol                                 = [30*c.item(), 0, 12*b.item(), 0, 2*a.item()]
        roo                                 = torch.from_numpy(np.roots(pol)).to(a.device)
        Pc                                  = -torch.real(roo[ torch.logical_and( torch.real(roo) > 0,  torch.imag(roo)==0)])
        Ec                                  = 2*a*Pc+4*b*torch.pow(Pc, 3)+6*c*torch.pow(Pc, 5)
        #get residual value
        pol1                                = [6*c.item(), 0, 4*b.item(), 0, 2*a.item(), 0]
        roo                                 = torch.from_numpy(np.roots(pol1)).to(a.device)
        Pr                                  = -torch.real(roo[ torch.logical_and( torch.real(roo) > 0,  torch.imag(roo)==0)])
        return Ec, Pc, Pr

    @torch.no_grad()
    def init_params(self, fromEcPc="ab", distrEcPc="distrecpc", structure_type="MFIM"):
        #input parameters check
        self.a                                  = CHECKTENSOR(self.a                        , precision=self.precision, device=self.device)   
        self.b                                  = CHECKTENSOR(self.b                        , precision=self.precision, device=self.device)   
        self.c                                  = CHECKTENSOR(self.c                        , precision=self.precision, device=self.device)     
        self.d                                  = CHECKTENSOR(self.d                        , precision=self.precision, device=self.device)     
        self.t_F                                = CHECKTENSOR(self.t_F                      , precision=self.precision, device=self.device)   
        self.t_D                                = CHECKTENSOR(self.t_D                      , precision=self.precision, device=self.device)    
        self.epsF                               = CHECKTENSOR(self.epsF                     , precision=self.precision, device=self.device)   
        self.epsD                               = CHECKTENSOR(self.epsD                     , precision=self.precision, device=self.device)   
        self.k_coupl                            = CHECKTENSOR(self.k_coupl                  , precision=self.precision, device=self.device)   
        self.dd                                 = CHECKTENSOR(self.dd                       , precision=self.precision, device=self.device)   
        self.w                                  = CHECKTENSOR(self.w                        , precision=self.precision, device=self.device)   
        self.sigmaRelEc_a                       = CHECKTENSOR(self.sigmaRelEc_a             , precision=self.precision, device=self.device)   
        self.sigmaRelPc_b                       = CHECKTENSOR(self.sigmaRelPc_b             , precision=self.precision, device=self.device)   
        self.sigmaRelPr_c                       = CHECKTENSOR(self.sigmaRelPr_c             , precision=self.precision, device=self.device)   
        self.rho                                = CHECKTENSOR(self.rho                      , precision=self.precision, device=self.device)   
        self.row                                = CHECKTENSOR(self.row                      , precision=torch.int64, device=self.device)   
        self.col                                = CHECKTENSOR(self.col                      , precision=torch.int64, device=self.device)     
        self.t_step                             = CHECKTENSOR(self.t_step                   , precision=self.precision, device=self.device)    
        self.out_i                              = 0   
        self.Vfb                                = CHECKTENSOR(0.0                           , precision=self.precision, device=self.device)   

        self.en0                                = CHECKTENSOR(self.en0                      , precision=self.precision, device=self.device) 

        self.mu                                 = CHECKTENSOR(self.mu                       , precision=self.precision, device=self.device)# Electrodes multiplicity
        self.WF_T                               = CHECKTENSOR(self.WF_T                     , precision=self.precision, device=self.device)#*q	# [J] Work function top electrode (fe)
        self.WF_B                               = CHECKTENSOR(self.WF_B                     , precision=self.precision, device=self.device)#*q;	# [J] Work function bottom electrode (ox)
        self.Chi_fe                             = CHECKTENSOR(self.Chi_fe                   , precision=self.precision, device=self.device)#*q;	# [J] Electron affinity Ferroel
        self.Chi_ox                             = CHECKTENSOR(self.Chi_ox                   , precision=self.precision, device=self.device)#*q;	# [J] Electron affinity ox
        self.m_eff_fe                           = CHECKTENSOR(self.m_eff_fe                 , precision=self.precision, device=self.device)#*m0    # [Kg] Effective mass ferroel
        self.m_eff_ox                           = CHECKTENSOR(self.m_eff_ox                 , precision=self.precision, device=self.device)#*m0    # [Kg] Effective mass oxide
        self.N_disc_traps                       = CHECKTENSOR( self.N_disc_traps            , precision=torch.int64, device=self.device) # number of traps levels
        self.notset_N_disc_traps_don            = CHECKTENSOR(self.notset_N_disc_traps_don  , precision=torch.int64, device=self.device) # of donor levels (NOT set self value in MAIN. This is calculated accordingly N_disc_traps)
        self.ntr                                = CHECKTENSOR(self.ntr                      , precision=self.precision, device=self.device) # starting density of traps -> [row, col, trap_level, time]
        self.ntr_don                            = CHECKTENSOR(self.ntr_don                  , precision=self.precision, device=self.device)
        self.Emin0                              = CHECKTENSOR(self.Emin0                    , precision=self.precision, device=self.device)#*q # [J] Minimum trap energy
        self.Emax0                              = CHECKTENSOR(self.Emax0                    , precision=self.precision, device=self.device)#*q # [J] Maximum trap energy
        self.Emin0_don                          = CHECKTENSOR(self.Emin0_don                , precision=self.precision, device=self.device)
        self.Emax0_don                          = CHECKTENSOR(self.Emax0_don                , precision=self.precision, device=self.device)
        self.Nacc                               = CHECKTENSOR(self.Nacc                     , precision=self.precision, device=self.device) # [1/eV/m^2 /e- charge]=[1/J/m^2]
        self.Nacc_don                           = CHECKTENSOR(self.Nacc_don                 , precision=self.precision, device=self.device)
        self.Nt                                 = CHECKTENSOR(self.Nt                       , precision=self.precision, device=self.device) # [m-2] Trap density always taken as self.Nacc * abs(self.Emin0-self.Emax0) / self.N_disc_traps
        self.Nt_don                             = CHECKTENSOR(self.Nt_don                   , precision=self.precision, device=self.device)
        #input value check     
        if type(self.sigma) == float:                               
            self.sigma                          = torch.ones(self.row*self.col, dtype=self.precision, device=self.device)*self.sigma
        else:       
            self.sigma                          = CHECKTENSOR(self.sigma, precision=self.precision, device=self.device).flatten() #row array

        # structure_type, must be 'MFM' (not selectable), 'MFIM', 'MIFIM',defines the structure type 
        
        #error checking
        if (self.numberofparam == 2 and self.sigmaRelPr_c != 0):
            pass
            #warnings.warn('WARNING: numberofparam is setted as 2, but Pr is not 0 or sigmaRelPr is not 0')
        elif (self.numberofparam == 3 and self.sigmaRelPr_c == 0):
            pass
            #warnings.warn('WARNING: numberofparam is setted as 3, but Pr is 0 or sigmaRelPr is 0')
        if type(distrEcPc) == str:
            self.distr_type             = distrEcPc.lower()
        else:
            raise ValueError('ERROR 1: distribution selector not properly set')

            
        #check the condition error
        if self.a >=0:
            raise ValueError('ERROR 2: alpha must be negative')
        
        #structure_type, must be 'MFM' => 0 (not selectable), 'MFIM' => 1, 'MIFIM' => 2
        if type(structure_type) != str:
            raise ValueError('ERROR 3: structure type not regognized')
        if structure_type == 'MFM':
            self.structure_type         = 1
            self.t_D                    = CHECKTENSOR(0.2e-9)
            self.epsD                   = CHECKTENSOR(2000)
        elif structure_type == 'MFIM':
            self.structure_type         = 1
        elif structure_type == 'MIFIM':
            self.structure_type         = 2
            raise ValueError('ERROR 4851: Not debugged yet!')
        else:
            raise ValueError('ERROR 4: structure not implemented')
        
        self.Vfb                        = (self.WF_T-self.WF_B)/self.q; 

        ######################################################################
        ##          Constants definitions                                   ##
        ######################################################################

        if self.structure_type == 1:
            self.CD                             = self.eps0*self.epsD/self.t_D  # [F/m2] capacitï¿½ ossido sotto ferroel
            self.CF                             = self.epsF*self.eps0/self.t_F  # [F/m2]
            self.C0                             = self.CD+self.CF                 # [F/m2]
            self.CS                             = self.CF*self.CD/self.C0         # [F/m2]
            self.C_coupl                        = 1/self.C0             
            self.B                              = -self.CF/self.C0
        elif self.structure_type == 2:      
            self.CDT                            = self.eps0*self.epsD_T/self.t_D_T
            self.CDB                            = self.eps0*self.epsD_B/self.t_D_B
            self.CDS                            = torch.pow(torch.pow(self.CDB, -1) + torch.pow(self.CDT, -1), -1)   
            self.CF                             = self.epsF*self.eps0/self.t_F
            self.CS                             = torch.pow(torch.pow(self.CDB, -1) + torch.pow(self.CDT, -1) + torch.pow(self.CF, -1), -1)         
        else:
            raise ValueError('ERROR 6: structure not implemented')
        if fromEcPc == 'ecpc':
            if self.numberofparam == 2:
                [self.a, self.b, self.c, self.d]= Engine.TwoParamModel_extractabcd(self.Ec, self.Pc)
            elif self.numberofparam == 3:
                [self.a, self.b, self.c, self.d]= Engine.ThreeParamModel_extractabcd(self.Ec, self.Pc, self.Pr)
            else:
                raise ValueError('ERROR 8: Number of parameters (alpha, beta, gamma) not supported yet')
        elif fromEcPc == 'ab':
            if self.numberofparam == 2:
                [self.Ec, self.Pc, self.Pr]	= Engine.TwoParamModel_extractEcPc(self.a, self.b)
            elif self.numberofparam == 3:
                [self.Ec, self.Pc, self.Pr]	= Engine.ThreeParamModel_extractEcPc(self.a, self.b,  self.c)
            else:
                raise ValueError('ERROR 9: Number of parameters(alpha, beta, gamma) not supported yet')
        else:
                raise ValueError('ERROR 9: Invalid argument fromEcPc in init_params(). Set <<ecpc>> to retrive model from Ec and Pc or <<ab>> to use static alpha and beta.')
            
        if self.traps == 2 and self.structure_type == 1:
            if len(self.Nacc.size()) == 0:
                self.Nt                         = torch.ones((self.N_disc_traps), dtype=self.precision, device=self.device)* self.Nacc * torch.abs(self.Emin0-self.Emax0) / self.N_disc_traps.to(self.precision)
            else:
                self.Nt                         = self.Nacc * torch.abs(self.Emin0-self.Emax0) / self.N_disc_traps.to(self.precision)
            
            if len(self.en0.size()) == 0 and self.structure_type == 1:                    
                self.en0                        = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device)*self.en0
        elif self.traps == 4 and self.structure_type == 1:
            #dE remain the same for boh types of traps (the reference
            #is calculated accordingly the donor type).
            if self.Emax0_don < self.Emax0:
                raise ValueError('ERROR 10: Emax0_don must be larger than Emax0')
            elif self.Emin0_don >= self.Edepth or self.Emin0 >= self.Edepth:
                raise ValueError('ERROR 10: Edepth must be much larger than Emin0  or Emin0_don')

            self.notset_N_disc_traps_don    = torch.ceil((self.Emin0_don-self.Emax0_don).abs()/((self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision))).to(torch.int64)
            if len(self.Nacc.size()) == 0 :
                self.Nt                         = torch.ones(self.N_disc_traps, dtype=self.precision, device=self.device) * self.Nacc * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don               	    = torch.ones(self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)   * self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
            else:   
                self.Nt                         = self.Nacc     * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
                self.Nt_don             	    = self.Nacc_don * (self.Emin0-self.Emax0).abs()/self.N_disc_traps.to(self.precision)
        elif self.traps > 4:
            raise ValueError('ERROR 11: engine.traps > 4 are not allowed!')
        elif self.traps >=1 and self.structure_type != 1:
            raise ValueError('ERROR 11: Double layer with traps are not implemented yet!')

        if self.row*self.col>1:
                # load electrostatic matrices:
                #file_name                      	= strcat('FTJ_',str(self.row*self.col),'_size',str((self.dd)*1e9),'nm_Tox',str(fix(self.t_D*1e10)),'_Tfe',str(round(self.t_F*1e9)),'_Al2O3');     
                #new name format
                #B is -CB/C0/dd^2
                if self.structure_type == 1:
                    name                        = "n{:n}tf{:g}td{:g}eox{:g}ef{:g}d{:g}".format(self.row*self.col, self.t_F*1e9, self.t_D*1e9, self.epsD, self.epsF, self.dd*1e9)
                    namefile                    = f'desc_files/{name}/{name}'
                    if (not os.path.isdir(f'desc_files/{name}')) or (not os.path.isfile(namefile+'.conf_vmat.txt')) or (not os.path.isfile(namefile+'.conf_glob.txt')):
                        print(f"Creating {name}")
                        if not os.path.isdir(f'desc_files/{name}'):
                            os.makedirs(f'desc_files/{name}')
                        self.download_structure(name)
                    else: 
                        print(f"Loading {name} structure...")

                    #CHECK THE FILE
                    if os.path.isfile(namefile+'.conf_vmat.txt') or os.path.isfile(namefile+'.conf_glob.txt'):
                        delete_ = False
                        with open(namefile+'.conf_vmat.txt', "r") as f:
                            lines = f.readlines()
                            if "not found" in lines[0].lower():
                                delete_ = True
                        
                        with open(namefile+'.conf_glob.txt', "r") as f:
                            lines = f.readlines()
                            if "not found" in lines[0].lower():
                                delete_ = True
                        
                        if delete_:
                            os.remove(namefile+'.conf')
                            os.remove(namefile+'.conf_glob.txt')
                            os.remove(namefile+'.conf_vmat.txt')
                            raise UsageError("ERROR 57714: The requested structure is not present in the repository. Please contact Riccardo (fontanini.riccardo@spes.uniud.it)")

                    else:
                        raise UsageError("ERROR 15626: Something wrong happend. Contact Riccardo (fontanini.riccardo@spes.uniud.it)")

                    c_temp                      = torch.from_numpy(np.loadtxt(namefile+'.conf_vmat.txt',usecols=2)).to(self.precision).to(device=self.device)
                    b_temp_tot                  = torch.from_numpy(np.loadtxt(namefile+'.conf_glob.txt',usecols=3)).to(self.precision).to(device=self.device)
                    self.B                      = (b_temp_tot[1::2]/self.dd**2).to(self.precision).to(device=self.device)
                    self.D                      = (b_temp_tot[::2]/self.dd**2).to(self.precision).to(device=self.device)
                    self.C_coupl                = torch.reshape(c_temp,(self.row*self.col,self.row*self.col)).to(self.precision).to(device=self.device)
                    self.CpC                    = (self.C_coupl+self.C_coupl.t())
                    

                elif self.structure_type == 2:
                    self.struct_file_name      	= 'n'+str(self.row*self.col)+'tf'+str(self.t_F*1e9)+'tdt'+str(self.t_D_T*1e9)+'tdb'+str(self.t_D_B*1e9)+'edt'+str(self.epsD_T)+'edb'+str(self.epsD_B)+'ef'+str(self.epsF)+'d'+str((self.dd)*1e9)    
                    fileID_C                  	= './desc_files/'+self.struct_file_name+'/'+self.struct_file_name+'.conf_vmat.txt'   #'*_mat.txt'
                    fileID_B                  	= './desc_files/',self.struct_file_name+'/'+self.struct_file_name+'.conf_glob.txt'   #'*_glob.txt'
                    C_temp                    	= torch.from_numpy(np.loadtxt(fileID_C).to(self.precision).to(device=self.device))
                    B_temp                     	= torch.from_numpy(np.loadtxt(fileID_B).to(self.precision).to(device=self.device))
                    self.C_coupl_T             	= -torch.reshape(C_temp[:,3],(self.row*self.col,self.row*self.col)) # 1/C(i,j) elements % TODO: check negative values
                    self.C_coupl_B              = torch.reshape(C_temp[:,2],(self.row*self.col,self.row*self.col))
                    self.B                     	= 1/self.dd^2*B_temp[1:2:-1, 4] # diagonal battery elements 
                    self.D                     	= 1/self.dd^2*B_temp[0:2:-1, 4] # diagonal battery elements 
                    self.C_coupl                = self.C_coupl_T + self.C_coupl_B
                    self.CpC                   	= self.C_coupl + self.C_coupl.t()
                else:
                    raise ValueError('Impossibile type of structure, init_params, Engine')
        
    @torch.no_grad()
    def set_simulator(self, Vsig, time, t_step=0, last_seed=False, P_init=None, Q_set=None):
        self.V                                  = CHECKTENSOR(Vsig)
        self.time                               = CHECKTENSOR(time)
        self.t_step                             = CHECKTENSOR(t_step)

        if not (Q_set is None):
            self.Qt_set                         = CHECKTENSOR(Q_set)
            self._get_fix_charge                = _Qset_from_output #replacing the function
        else:
            self.Qt_set                         = 0.0
            self.sigmarow                       = self.sigma.flatten()
            self._get_fix_charge                = standard_get_fix_charge

        self.P                                  = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
        self.Qt                                 = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
        if self.traps == 4:
            self.QtACC                          = torch.zeros(self.V.shape[-1], device=self.device, dtype=self.precision)
            self.QtDON                          = torch.zeros(self.V.shape[-1], device=self.device, dtype=self.precision)   

        self.seed = Seed(self)
        if last_seed:
            self.load_seed(self.var_seed_path)
            if self.seed.is_compatible(self):
                self.P[:,:,0]                   = self.seed.Pstart
            else:
                raise ValueError('ERROR 55: Error loading seed in set_simulator(). You are tring to load a seed with different parameters. Check your parameters a, b, c, d Pc Ec and V_sign(1).')            
        else:
            if P_init is None:
                #warnings.warn('P_init not chosen, will be generated by simulator instead, in set_simulator')
                self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.seed.Pstart = self.disp_NORM(self.V[0])
                self.P[:,:,0]                   = self.seed.Pstart
            else:
                P_init                          = CHECKTENSOR(P_init)
                if P_init.shape[0] != self.row or P_init.shape[1] != self.col:
                    raise ValueError('ERROR 56: Initial Polarization vector size not matching with size of engine.P(:,:,0) in set_simulator')
                #Controllare l'inizializzazione!!!!!!!!!!!!!!!!!!!!!!!!!
                self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.seed.Pstart = self.disp_NORM(self.V[0])
                self.P[:,:,0]             	    = P_init
                self.seed.Pstart                = P_init.clone()
            self.save_seed(self.var_seed_path)     
        
        
        if self.structure_type == 1:
            if self.traps == 0:
                self.ntr                        = torch.zeros((self.row, self.col, self.N_disc_traps), dtype=self.precision, device=self.device)
            elif self.traps == 2:  #'dynamic'
                self.ntr                        = torch.zeros((self.row, self.col, self.N_disc_traps), dtype=self.precision, device=self.device)
                Vd                              = torch.mv(self.C_coupl.t(), self.P[:,:,0].transpose(0, 1).flatten()+self.sigma) + self.CF/self.C0*(self.V[0]-self.Vfb)
                Vd                              = torch.reshape(Vd, (self.row, self.col)).transpose(0, 1)
                js                              = torch.arange(0, self.N_disc_traps, dtype=self.precision, device=self.device)
                for i in range(0, self.row):
                    for j in range(0, self.col):
                        Et                      = self.WF_B - (self.Chi_ox + self.Emax0) - self.q * Vd[i, j] - (self.Emin0-self.Emax0).abs()/(self.N_disc_traps).to(self.precision)*js 
                        self.ntr[i, j, :]       = self.Nt*(1.0/(1.0+1.0/torch.exp(Et/self.Kb/self.Temp)))
                
                self.Qt[:, :, 0]                = -self.q * self.ntr.sum(2)
                self.ntr                        = torch.reshape(self.ntr.transpose(0, 1), (self.row * self.col, self.N_disc_traps)).transpose(0, 1).flatten()

            elif self.traps == 4:  # dynamic
                self.ntr                        = torch.zeros((self.row, self.col, self.N_disc_traps), dtype=self.precision, device=self.device)
                self.ntr_don                    = torch.zeros((self.row, self.col, self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                Vd                              = torch.mv(self.C_coupl.t(), self.P[:,:,0].transpose(0, 1).flatten()+self.sigma) + self.CF/self.C0*(self.V[0]-self.Vfb)
                Vd                              = torch.reshape(Vd, (self.row, self.col)).transpose(0, 1)
                dE                              = torch.abs(self.Emin0-self.Emax0)/(self.N_disc_traps).to(self.precision)
                js_acc                          = torch.arange(0, self.N_disc_traps, dtype=self.precision, device=self.device)
                js_don                          = torch.arange(0, self.notset_N_disc_traps_don, dtype=self.precision, device=self.device)
                
                for i in range(0, self.row):
                    for j in range(0, self.col):
                        Et_acc                  = self.WF_B - (self.Chi_ox + self.Emax0) - self.q * Vd[i, j] - dE*js_acc
                        #remember: dE remains the same for both
                        Et_don                  = self.WF_B - (self.Chi_ox + self.Emax0_don) - self.q * Vd[i, j] - dE*js_don; 
                        self.ntr[i, j, :]       = self.Nt.flatten()*(1.0/(1.0+torch.exp(Et_acc/self.Kb/self.Temp)))
                        self.ntr_don[i, j, :]   = self.Nt_don.flatten()*(1.0/(1.0+torch.exp(Et_don/self.Kb/self.Temp)))
                
                self.Qt[:, :, 0]                = -self.q*self.ntr.sum(2) + self.q*(self.Nt_don[0]*(self.notset_N_disc_traps_don).to(self.precision) - self.ntr_don.sum(2))
                self.ntr                        = torch.reshape(self.ntr.transpose(0, 1), (self.row * self.col, self.N_disc_traps)).transpose(0, 1).flatten()
                self.ntr_don                    = torch.reshape(self.ntr_don.transpose(0, 1), (self.row * self.col, self.notset_N_disc_traps_don)).transpose(0, 1).flatten()
                
            else:
                raise ValueError('ERROR 5: Traps not implemented for this structure type')   
        elif self.structure_type == 2:
            self.Qt                             = torch.zeros((self.row, self.col))
            self.ntr                            = torch.zeros((self.row*self.col*self.N_disc_traps))
        
    
    def simulate(self, index_start="all", enable_save_ntr=False):
        with torch.no_grad():
            self.transfermemory("cuda")
            
            ################################# ADAPTATION FOR MATLAB ################################
            flat_a_eff                          = torch.flatten(self.seed.a_eff.transpose(0, 1))
            flat_b_eff                          = torch.flatten(self.seed.b_eff.transpose(0, 1))
            flat_c_eff                          = torch.flatten(self.seed.c_eff.transpose(0, 1))
            flat_d_eff                          = torch.flatten(self.seed.d_eff.transpose(0, 1))
            ########################################################################################
            if enable_save_ntr:
                #no reshape or transpose  MUST BE ON CPU TO REDUCE THE AMOUNT OF MEMORY USED DURING THE SIMULATION
                self.tr_occ_acc                 = torch.zeros((self.row*self.col*self.N_disc_traps, self.V.shape[-1]), dtype=self.precision, device="cpu")
                self.tr_occ_don                 = torch.zeros((self.row*self.col*self.notset_N_disc_traps_don, self.V.shape[-1]), dtype=self.precision, device="cpu")
            
            #initialization of NR
            self.out_i                          = 1
            DP_succ                             = torch.tensor(1)
            setup                               = 1
            setup_2                             = 0
            Pol_old                             = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            Qt_old                              = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            f_old                               = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            f                                   = torch.zeros((self.row*self.col), dtype=self.precision, device=self.device)
            Qt_1                                = torch.zeros((self.row*self.col), device= self.device, dtype = self.precision)
            Pol_1                               = torch.zeros((self.row*self.col), device= self.device, dtype = self.precision)
            Pdyn                                = torch.zeros((self.row*self.col, self.row*self.col), dtype=self.precision, device=self.device)
            I                                   = torch.eye(self.row*self.col, dtype=self.precision, device=self.device)
            I_varJ                              = I*self.var_J
            
            if index_start == 'all':
                self.out_i                      = 1                   	
                DP_succ                         = torch.tensor(1)
                setup                           = 1                      	# enable setup = 1
                setup_2                         = 0                     	# enable reset setup
                nan_flag                        = 0                      	# flag to report a NaN Jacobian and retry with smaller step
                PP                              = torch.flatten(self.P[:,:, self.out_i-1].transpose(0,1).clone())
                QQ                              = torch.flatten(self.Qt[:,:, self.out_i-1].transpose(0,1).clone())
                static_                         = torch.mv(self.CpC, PP+QQ+self._get_fix_charge(self, self.out_i-1))
                beferro.MFIMsolver(f, PP, self.V[self.out_i-1], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i-1), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
            elif index_start=='prev':
                DP_succ                         = torch.tensor(1)
                setup                           = 0                     	# enable setup = 1
                setup_2                         = 0                     	# enable reset setup
                nan_flag                        = 0                      	# flag to report a NaN Jacobian and retry with smaller step
                PP                              = torch.flatten(self.P[:,:, self.out_i-1].transpose(0,1).clone())
                QQ                              = torch.flatten(self.Qt[:,:, self.out_i-1].transpose(0,1).clone())
                static_                         = torch.mv(self.CpC, PP+QQ+self._get_fix_charge(self, self.out_i-1))
                beferro.MFIMsolver(f, PP, self.V[self.out_i-1], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i-1), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
            else:
                raise ValueError('ERROR 0: Value of index_start not recognized')
            
            if self.traps == 2:
                ntr_1                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_last                        = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_1[:]                        = self.ntr
                cn_ijk                          = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                en_ijk                          = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk_old                       = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                d_f_ijk                         = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
            elif self.traps == 4:
                ntr_1                           = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ntr_1[:]                        = self.ntr
                ptr_1                           = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                ptr_1[:]                        = self.ntr_don
                ntr_last                        = torch.zeros((self.col*self.row*self.N_disc_traps), dtype=self.precision, device=self.device)
                ptr_last                        = torch.zeros((self.col*self.row*self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                TMD                             = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps)).to(torch.int64)), dtype=self.precision, device=self.device)
                TMF                             = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps)).to(torch.int64)), dtype=self.precision, device=self.device)     
                dE                              = (self.Emax0-self.Emin0).abs()/self.N_disc_traps
                self.IMD_in                     = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)#MUST BE ON CPU TO REDUCE THE AMOUNT OF MEMORY USED DURING THE SIMULATION
                self.IMD_out                    = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
                self.IMF_in                     = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
                self.IMF_out                    = torch.zeros((self.row, self.col, self.V.shape[-1]), dtype=self.precision, device=self.device)
                cnmd                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                cnmf                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                enmd                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)
                enmf                            = torch.zeros((self.row * self.col * self.N_disc_traps), dtype=self.precision, device=self.device)  
                cnmd_don                     	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                cnmf_don                      	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                enmd_don                      	= torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                enmf_don                        = torch.zeros((self.row * self.col * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)  
                
                f_ijk                           = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                d_f_ijk                         = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk_don                    	= torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                d_f_ijk_don                   	= torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)
                f_ijk_old                       = torch.zeros((self.col * self.row * self.N_disc_traps), dtype=self.precision, device=self.device)
                f_ijk_don_old                   = torch.zeros((self.col * self.row * self.notset_N_disc_traps_don), dtype=self.precision, device=self.device)

            

            pbar = tqdm(total = self.V.shape[0])
            while self.out_i < self.V.shape[0]:
                if( DP_succ>1e-5 and setup ==1 ):
                    print(f"SETUP Convergence: {torch.abs(DP_succ)}")
                    self.out_i                  = 1
                    if setup_2 == 0:        
                        setup_2                 = 1
                    else:       
                        self.P[:,:,0]           = self.P[:,:,self.out_i]
                elif setup_2 == 1:  
                    print(f"END of SETUP, starting the simulation... ")
                    self.out_i                  = 1
                    self.P[:,:,0]               = self.P[:,:,self.out_i]
                    self.Qt[:,:,0]              = self.Qt[:,:,self.out_i]
                    if self.traps == 4 and self.structure_type == 1:
                        self.QtACC[0]           = -torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps)).sum(1).mean()*self.q
                        self.QtDON[0]           = -torch.reshape(ptr_1, (self.row*self.col, self.notset_N_disc_traps_don)).sum(1).mean()*self.q +self.Nt_don[0]*self.q*self.notset_N_disc_traps_don
                    setup                       = 0
                    setup_2                     = 0
                    pbar.update(1)
                    pbar.update(1)
                else:
                    pbar.update(1)
                
                Pol_old[:]                      = torch.flatten(self.P[:,:, self.out_i-1].transpose(0, 1)) ### TRANSPOSE FOR MATLAB ACCORDANCE
                Qt_old[:]                       = torch.flatten(self.Qt[:,:, self.out_i-1].transpose(0, 1)) ### TRANSPOSE FOR MATLAB ACCORDANCE
                static_                         = torch.mv(self.CpC, Pol_old + Qt_old + self._get_fix_charge(self, self.out_i-1))
                f_old[:]                        = f #copy the values, not cloning
                
                beferro.MFIMsolver(f_old, Pol_old, self.V[self.out_i-1], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i-1), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
                
                Vd                              = torch.mv(self.C_coupl.t(), (Pol_old+self._get_fix_charge(self, self.out_i-1)+Qt_old)) + self.CF/self.C0*(self.V[self.out_i-1]-self.Vfb)
                if self.traps == 0:
                    relative_delta_ntr          = torch.tensor(0, dtype=self.precision, device=self.device)
                    Qt_1[:]                     = Qt_old
                elif self.traps == 2 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference                    
                    beferro.solver_ntr(f_ijk_old, cn_ijk, en_ijk, Pol_old, Vd, self.row, self.col, ntr_last, self.en0, self.Nt, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.N_disc_traps, self.Temp)
                    delta_ntr                   = self.t_step*f_ijk_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps)).sum(1)
                    relative_delta_ntr          = torch.max(torch.abs(delta_ntr/ntr_1))
                elif self.traps == 4 and self.structure_type == 1:
                    ntr_last[:]                 = ntr_1 #copy of the reference
                    ptr_last[:]                 = ptr_1 #copy of the reference
                    
                    beferro.calc_TMD_TMF(TMD, TMF, self.row, self.col, self.V[self.out_i-1], Vd, self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp)
                    beferro.solver_ntr_dbpm_accanddon(f_ijk_old, d_f_ijk, f_ijk_don_old, d_f_ijk_don, cnmd, enmd, cnmf, enmf, cnmd_don, enmd_don, cnmf_don, enmf_don, ntr_1, ptr_1, TMD, TMF, self.row, self.col, self.V[self.out_i-1], Vd, self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 1)
                    delta_ntr                   = self.t_step*f_ijk_old
                    delta_ptr                   = self.t_step*f_ijk_don_old
                    ntr_1[:]                    = ntr_last + delta_ntr
                    ptr_1[:]                    = ptr_last + delta_ptr
                    Qt_1[:]                     = -self.q*torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps)).sum(1) + self.q*(self.Nt_don[0]*self.notset_N_disc_traps_don - torch.reshape(ptr_1, (self.row*self.col, self.notset_N_disc_traps_don)).sum(1))
                    relative_delta_ntr   	    = torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0).max()
                else:
                    raise ValueError('ERROR 1: Not implemented trap model')
                    
                  
                delta                           = self.t_step * f_old
                Pol_1[:]                        = Pol_old + delta
                relative_delta                  = torch.max(torch.abs(delta/Pol_1))
                index                           = 0
                    
                while (relative_delta>1e-7 or relative_delta_ntr>1e-7 ):
                    static_                     = torch.mv(self.CpC, Pol_1+Qt_1+ self._get_fix_charge(self, self.out_i))
                    beferro.MFIMsolver(f, Pol_1, self.V[self.out_i], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
                    f_tot                       = (Pol_1-Pol_old)/self.t_step + (self.theta*f+(1.0-self.theta)*f_old)
                    Peps                        = ((Pol_1.unsqueeze(-1).repeat( (1, self.row*self.col)) + I*self.var_J))
                    Qeps                        = (Pol_1+Qt_1+self._get_fix_charge(self, self.out_i)).unsqueeze(-1).repeat((1, self.row*self.col)) + I_varJ
                    static_eps                  = torch.matmul(self.CpC, Qeps)
                    beferro.eval_variation(Pdyn, torch.flatten(Peps.transpose(0, 1)), self.V[self.out_i], torch.flatten(static_eps.transpose(0, 1)), self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self._get_fix_charge(self, self.out_i), self.Vfb, self.CD, self.C0, self.CS, 0.0, (self.rho*self.t_F), flat_a_eff, flat_b_eff, flat_c_eff, flat_d_eff, self.B, int(1), int(1))
                    Pdyn                        = Pdyn.transpose(0, 1)
                    fp                          = (Pdyn - f.unsqueeze(-1).repeat(1, self.row*self.col))/self.var_J
                    Jacobian                    = I/self.t_step + fp*self.theta
                    
                    if self.traps == 2 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1 + self._get_fix_charge(self, self.out_i) + Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.solver_ntr(f_ijk, cn_ijk, en_ijk, Pol_1, Vd, self.row, self.col, ntr_1, self.en0, self.Nt, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.N_disc_traps, self.Temp)
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ijk_old - (1-self.theta)*f_ijk)/(1/self.t_step + (1-self.theta)*(cn_ijk+en_ijk))
                        ntr_1                   = ntr_1 - delta_ntr
                        Qt_1                    = -self.q*torch.sum(torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps)), 1)
                        
                    elif self.traps == 4 and self.structure_type == 1:
                        Vd                  	= torch.mv(self.C_coupl.t(), (Pol_1+self._get_fix_charge(self, self.out_i)+Qt_1)) + self.CF/self.C0*(self.V[self.out_i]-self.Vfb)
                        beferro.calc_TMD_TMF(TMD, TMF, self.row, self.col, self.V[self.out_i], Vd, self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, torch.abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp)
                        beferro.solver_ntr_dbpm_accanddon(f_ijk, d_f_ijk, f_ijk_don, d_f_ijk_don, cnmd, enmd, cnmf, enmf, cnmd_don, enmd_don, cnmf_don, enmf_don, ntr_1, ptr_1, TMD, TMF, self.row, self.col, self.V[self.out_i], Vd, self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 1)
                        delta_ntr               = ((ntr_1 - ntr_last)/self.t_step - self.theta*f_ijk_old - (1-self.theta)*f_ijk)/(1/self.t_step - (1-self.theta)*d_f_ijk)
                        ntr_1                   = ntr_1 - delta_ntr
                        delta_ptr               = ((ptr_1 - ptr_last)/self.t_step - self.theta*f_ijk_don_old - (1-self.theta)*f_ijk_don)/(1/self.t_step - (1-self.theta)*d_f_ijk_don)
                        ptr_1                   = ptr_1 - delta_ptr
                        Qt_1                    = -self.q*torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps)).sum(1)+ self.q*(self.Nt_don[0]*self.notset_N_disc_traps_don - torch.reshape(ptr_1, (self.row*self.col, self.notset_N_disc_traps_don)).sum(1))       
                    
                    delta                       = -torch.linalg.lstsq(Jacobian, f_tot, rcond=None).solution
                    Pol_1                       = Pol_1 + delta

                    if torch.isnan(Pol_1).any():
                        raise ValueError('ERROR 69449: Pol_1 became NaN in simulate!!')
                    if self.traps == 2:
                        if torch.isnan(ntr_1).any():
                            raise ValueError('ERROR 15963: ntr_1 became NaN in simulate!!')
                    elif self.traps == 4:
                        if torch.isnan(ntr_1).any() or torch.isnan(ptr_1).any():
                            raise ValueError('ERROR 15963: ntr_1 or ptr_1 became NaN in simulate!!')
                    
                    relative_delta              = torch.max(torch.abs(delta/Pol_1))
                    if self.traps == 0 or self.traps == 1:
                        relative_delta_ntr     	= torch.tensor([0]) #useless placeholder value
                    elif self.traps == 2 or self.traps == 3:
                        relative_delta_ntr   	= torch.max(torch.abs(delta_ntr/ntr_1))
                    elif self.traps == 4:
                        relative_delta_ntr   	= torch.max(torch.cat( ((delta_ntr/ntr_1).abs(), (delta_ptr/ptr_1).abs()), 0))
                    else:
                        raise ValueError('error')
                    index               += 1
                #this.index2(this.out_i)      	= index;
                self.P[:,:,self.out_i]        	= torch.reshape(Pol_1, (self.row, self.col)).transpose(0, 1) #% [C/m2]
                self.Qt[:,:,self.out_i]         = torch.reshape(Qt_1 , (self.row, self.col)).transpose(0, 1)
                
                #if self.traps == 3 and self.structure_type == 1:
                #    
                #    self.ntr                    = torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps))
                #    self.IMD_in[:, self.out_i]  = torch.sum(torch.reshape(Imdin, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                #    self.IMD_out[:, self.out_i] = -torch.sum(torch.reshape(Imdout, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                #    self.IMF_in[:, self.out_i]  = torch.sum(torch.reshape(Imfin, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                #    self.IMF_out[:, self.out_i] = -torch.sum(torch.reshape(Imfout, self.col*self.row, self.N_disc_traps), 2))*self.Nt(1);
                if self.traps == 4 and self.structure_type == 1:
                    #self.ntr                    = torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps))
                    #self.ntr_don                = torch.reshape(ptr_1, (self.row*self.col, self.notset_N_disc_traps_don))
                    self.QtACC[self.out_i]      = -torch.reshape(ntr_1, (self.row*self.col, self.N_disc_traps)).sum(1).mean()*self.q
                    self.QtDON[self.out_i]      = -torch.reshape(ptr_1, (self.row*self.col, self.notset_N_disc_traps_don)).sum(1).mean()*self.q +self.Nt_don[0]*self.q*self.notset_N_disc_traps_don
                    
                    self.IMD_in[:, :, self.out_i]  = torch.reshape(torch.reshape(cnmd*(1-ntr_1/self.Nt[0]),    (self.col*self.row, self.N_disc_traps)).sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    self.IMD_out[:, :, self.out_i] = torch.reshape(torch.reshape(enmd*ntr_1/self.Nt[0],        (self.col*self.row, self.N_disc_traps)).sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    self.IMF_in[:, :, self.out_i]  = torch.reshape(torch.reshape(cnmf*(1-ntr_1/self.Nt[0]),    (self.col*self.row, self.N_disc_traps)).sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    self.IMF_out[:, :,self.out_i]  = torch.reshape(torch.reshape(enmf*ntr_1/self.Nt[0],        (self.col*self.row, self.N_disc_traps)).sum(1)*self.Nt[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    
                    self.IMD_in[:, :,self.out_i]   = self.IMD_in[:, :,self.out_i]     + torch.reshape(torch.reshape(cnmd_don*(1-ptr_1/self.Nt_don[0]),    (self.col*self.row, self.notset_N_disc_traps_don)).sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    self.IMD_out[:, :,self.out_i]  = -(self.IMD_out[:, :,self.out_i]  + torch.reshape(torch.reshape(enmd_don*    ptr_1/self.Nt_don[0],    (self.col*self.row, self.notset_N_disc_traps_don)).sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1) )
                    self.IMF_in[:, :,self.out_i]   = self.IMF_in[:, :,self.out_i]     + torch.reshape(torch.reshape(cnmf_don*(1-ptr_1/self.Nt_don[0]),    (self.col*self.row, self.notset_N_disc_traps_don)).sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1)
                    self.IMF_out[:, :,self.out_i]  = -(self.IMF_out[:, :,self.out_i]  + torch.reshape(torch.reshape(enmf_don*ptr_1/self.Nt_don[0],        (self.col*self.row, self.notset_N_disc_traps_don)).sum(1)*self.Nt_don[0]*self.q,   (self.row, self.col)).transpose(0, 1) )
                    if enable_save_ntr:
                        #no reshape or transpose
                        self.tr_occ_acc[:,self.out_i] = (ntr_1/self.Nt[0]).cpu()
                        self.tr_occ_don[:,self.out_i] = (ptr_1/self.Nt_don[0]).cpu()
                if setup > 0:       
                    DP_succ                     = torch.max(torch.abs((Pol_1-Pol_old)/Pol_old))
                self.out_i                      = self.out_i +1
                #if self.out_i % 100 == 0:
                #    print(str(self.out_i)+'-step: Signal [V]: '+str(self.V[self.out_i].item())+' Completion percentage: '+str(((self.time[self.out_i]/self.time[-1])*100).item())+' %')    
            pbar.close()
            self.calculate_charge()
            self.calculate_voltagefields()
            self.transfermemory("cpu")

    @torch.no_grad()
    def band_diagram(self, timeindex, index_structure=None):
        """
        This function calculates the band diagram. If index_structure is None, 
        it calculates the band diagram with VD_av, otherwise you have to specify in 
        the domain index in index_structure as a tuple

        Usage
        -----
        plt.plot(*engine.band_diagram(idx))

        Parameters
        ----------
        timeindex: int
            time index to calculate the band diagram

        index_structure: tuple of int, optional
            index of the domain to consider (default is None)

        Raises
        ------
        ValueError 
            If timeindex or index_structure are wrong

        """
        if timeindex <0 or timeindex >= len(self.V) or timeindex is None:
            raise ValueError("ERROR 8367: Not valid index in timeindex")

        if index_structure is None:
            VD                          = self.VD_av[timeindex]
        else:
            if len(index_structure) != 2:
                raise ValueError("ERROR 548466: Not valid index in index_structure")
            if index_structure[0] < 0 or index_structure[0] >=self.row or index_structure[1] < 0 or index_structure[1] >self.col:
                raise ValueError("ERROR 563284: Not valid index in index_structure")
            VD                          = self.VD[index_structure[0], index_structure[1], timeindex] 
        
        Ubottom                         = 0
        UD_M                            = self.WF_B/self.q-self.Chi_ox/self.q                                   # [eV] Band at the Metal-Ox disc.
        UD_F                            = self.WF_B/self.q - VD - self.Chi_ox/self.q;                           # [eV] Band at the Ox-Fe discontinuity (for the oxide)
        UF_D                            = self.WF_B/self.q - VD - self.Chi_fe/self.q;                           # [eV] Band at the Ox-Fe discontinuity (for the ferroel)
        UF_M                            = self.WF_B/self.q - self.V[timeindex]+self.Vfb - self.Chi_fe/self.q;   # [eV] Band of ferroelectric at the top contact
        Utop                            = self.WF_B/self.q - self.V[timeindex]+self.Vfb - self.WF_T/self.q;     # [eV] Fermi level of the top contact
        
        y                               = [       Ubottom,   Ubottom,      UD_M, UD_F, UF_D,     UF_M,     Utop,          Utop] 
        x                               = [-1e-9-self.t_D, -self.t_D, -self.t_D,    0,    0, self.t_F, self.t_F, self.t_F+1e-9]
        return [x, y]
        

    @torch.no_grad()
    def band_ACC(self, timeindex, index_structure=None):
        """
        This function calculates the band of acceptor traps. If index_structure is None, 
        it calculates the band diagram with VD_av, otherwise you have to specify in 
        the domain index in index_structure as a tuple

        Usage
        -----
        plt.plot(*engine.band_ACC(idx))

        Parameters
        ----------
        timeindex: int
            time index to calculate the band diagram

        index_structure: tuple of int, optional
            index of the domain to consider (default is None)

        Raises
        ------
        ValueError 
            If timeindex or index_structure are wrong

        """
        if self.traps == 2 or self.traps == 4:
            pass
        else:
            return [] 

        if timeindex <0 or timeindex >= len(self.V) or timeindex is None:
            raise ValueError("ERROR 8367: Not valid index in timeindex")

        if index_structure is None:
            VD                          = self.VD_av[timeindex]
        else:
            if len(index_structure) != 2:
                raise ValueError("ERROR 548466: Not valid index in index_structure")
            if index_structure[0] < 0 or index_structure[0] >=self.row or index_structure[1] < 0 or index_structure[1] >self.col:
                raise ValueError("ERROR 563284: Not valid index in index_structure")
            VD                          = self.VD[index_structure[0], index_structure[1], timeindex] 
        
        Utop                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emax0/self.q;               # [eV] Top of the  traps
        Ubot                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emin0/self.q;               # [eV] Bottom of the  traps
        y                               = [ Utop, Ubot] 
        x                               = [    0,    0]
        return [x, y]

    @torch.no_grad()
    def band_DON(self, timeindex, index_structure=None):
        """
        This function calculates the band of donor traps. If index_structure is None, 
        it calculates the band diagram with VD_av, otherwise you have to specify in 
        the domain index in index_structure as a tuple

        Usage
        -----
        plt.plot(*engine.band_DON(idx))

        Parameters
        ----------
        timeindex: int
            time index to calculate the band diagram

        index_structure: tuple of int, optional
            index of the domain to consider (default is None)

        Raises
        ------
        ValueError 
            If timeindex or index_structure are wrong

        """
        if self.traps == 4:
            pass
        else:
            return [] 

        if timeindex <0 or timeindex >= len(self.V) or timeindex is None:
            raise ValueError("ERROR 8367: Not valid index in timeindex")

        if index_structure is None:
            VD                          = self.VD_av[timeindex]
        else:
            if len(index_structure) != 2:
                raise ValueError("ERROR 548466: Not valid index in index_structure")
            if index_structure[0] < 0 or index_structure[0] >=self.row or index_structure[1] < 0 or index_structure[1] >self.col:
                raise ValueError("ERROR 563284: Not valid index in index_structure")
            VD                          = self.VD[index_structure[0], index_structure[1], timeindex] 
        
        Utop                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emax0_don/self.q;               # [eV] Top of the  traps
        Ubot                            = self.WF_B/self.q - VD - self.Chi_ox/self.q - self.Emin0_don/self.q;               # [eV] Bottom of the  traps
        y                               = [ Utop, Ubot] 
        x                               = [    0,    0]
        return [x, y]
        

    @torch.no_grad()
    def load(self, path = './var.pkl'):
        if path.lower().endswith('.pkl'):

            data                        = bz2.BZ2File(path, "rb")
            loaded                      = pickle.load(data)
            self.__dict__.update(loaded.__dict__)
            del loaded
        elif path.lower().endswith(".json"):
            with open(path) as f:
                data                    = json.load(f)
                self.__dict__.update(data)
                #############################################
                # PUT HERE CORRECTIONS FOR INCOMPATIBILITY
                # only few adjustments for retrocompatibility
                self.t_D                = data["t_ox"]
                del self.t_ox
                self.t_F                = data["t_fe"]
                del self.t_fe
                self.epsD               = data["er_ox"]
                del self.er_ox
                self.epsF               = data["eps_B"]
                del self.eps_B

                self.CF                = data["CB"]
                del self.CB

                
                self.seed.a_eff         = torch.reshape(torch.tensor(data["av"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                self.seed.b_eff         = torch.reshape(torch.tensor(data["bv"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                self.seed.c_eff         = torch.reshape(torch.tensor(data["cv"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                self.seed.d_eff         = torch.reshape(torch.tensor(data["dv"], dtype=self.precision, device="cpu"), [self.row, self.col]).transpose(0, 1)
                del self.av
                del self.bv
                del self.cv
                del self.dv
                ##########################################
                for k in dir(self):
                    v               = getattr(self, k)
                    if type(v) is list:
                        setattr(self, k, torch.tensor(v, dtype=self.precision, device="cpu")) 
                
                
        else:
            raise Exception('File type not recognized!') 
        

    @torch.no_grad()
    def save(self, path = './var.pkl'):

        head, tail                          = os.path.split(path)
        if not os.path.isdir(head):
            os.makedirs(head)
        self.var_saving_path                    = path
        with bz2.BZ2File(path, "wb") as f: 
            pickle.dump(self, f)
    
    @torch.no_grad()
    def load_seed(self, path = './seed.pkl'):

        if path.lower().endswith(".pkl"):
            self.var_seed_path                      = path
            loaded                                  = pickle.load(open(path, 'rb'))
            self.seed.__dict__.update(loaded.__dict__)
            del loaded

        elif path.lower().endswith(".json"):
            with open(path) as f:
                data                    = json.load(f)
                valuecheck              =   data[0] == self.a*self.t_F and \
                                            data[1] == self.b*self.t_F and \
                                            data[2] == self.c*self.t_F and \
                                            data[3] == self.d*self.t_F and \
                                            data[6] == self.V[0]
                pdb.set_trace()
                if valuecheck:
                    self.seed.a_eff     = torch.tensor(data[7], dtype=self.precision)
                    self.seed.b_eff     = torch.tensor(data[8], dtype=self.precision)
                    self.seed.c_eff     = torch.tensor(data[9], dtype=self.precision)
                    self.seed.d_eff     = torch.tensor(data[10], dtype=self.precision)
                    self.seed.Pstart    = torch.tensor(data[13], dtype=self.precision)
                else: 
                    raise Exception('Loading seed not possible! Wrong initial parameters!') 
                
        else:
            raise Exception('File type not recognized!') 

    @torch.no_grad()
    def save_seed(self, path = './seed.pkl'):
        head, tail = os.path.split(path)
        if not os.path.isdir(head):
            os.makedirs(head)
        self.var_seed_path                      = path
        pickle.dump(self.seed, open(path, 'wb'))

    @torch.no_grad()
    def disp_NORM(self, V_iniz):
        a_eff                              	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        b_eff                            	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        c_eff                              	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        d_eff                              	    = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
        P_iniz                             	    = torch.ones([self.row, self.col], device=self.device, dtype=self.precision)
            
        #std. dev. calculation
        if self.distr_type == 'distrecpc':
            sigmaEc_a                        	= torch.abs(self.sigmaRelEc_a * self.Ec)
            sigmaPc_b                          	= torch.abs(self.sigmaRelPc_b * self.Pc)
            if self.numberofparam == 2:
                    sigmaPr_c                	= 0
            elif self.numberofparam == 3:
                    sigmaPr_c                 	= torch.abs(self.sigmaRelPr_c * self.Pr)
            else:
                    raise ValueError('Error 98: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')
        elif self.distr_type == 'distrab':
            sigmaEc_a                        	= torch.abs(self.sigmaRelEc_a * self.a)
            sigmaPc_b                          	= torch.abs(self.sigmaRelPc_b * self.b)
            if self.numberofparam == 2:
                sigmaPr_c                	    = 0
            elif self.numberofparam == 3:
                sigmaPr_c                 	    = abs(self.sigmaRelPr_c * self.c)
            else:
                raise ValueError('Error 99: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')
        else:
            raise ValueError('Error 100: Selector of realization (distr_type) is not setted properly, disp_NORM')


        onemat                                  = torch.ones([self.row,  self.col], dtype=self.precision, device = self.device)
        #realizations
        if self.distr_type=='distrecpc':
            self.Ec_dist                  	    = torch.normal(self.Ec * onemat, sigmaEc_a * onemat)
            self.Pc_dist                        = torch.normal(self.Pc * onemat, sigmaPc_b * onemat)
            if self.numberofparam == 2:
                self.Pr_dist           	        = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
            elif self.numberofparam == 3:
                self.Pr_dist          	        = torch.normal(self.Pr * onemat, sigmaPr_c * onemat)
            else:
                raise ValueError('Error 101: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')
        elif self.distr_type == 'distrab':
                a_eff                           = torch.normal(self.a * onemat, sigmaEc_a * onemat)
                b_eff                           = torch.normal(self.b * onemat, sigmaPc_b * onemat)
                if self.numberofparam == 2:
                    c_eff                       = torch.zeros([self.row, self.col], device=self.device, dtype=self.precision)
                elif self.numberofparam == 3:
                    c_eff                       = torch.normal(self.c * onemat, sigmaPr_c * onemat)
                else:
                    raise ValueError('Error 102: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')                
        else:
            raise ValueError('Error 103: Selector of realization (distr_type) is not setted properly, disp_NORM')

        #conversions
        for xx in range(0, self.row):
            for yy in range(0, self.col):
                # get alpha, beta of (xx, yy) domain, according to the
                # pre-generated distribution
                if self.distr_type == 'distrecpc':
                    if self.numberofparam == 2:
                        [a_, b_, c_, d_]      	= Engine.TwoParamModel_extractabcd(self.Ec_dist[xx, yy], self.Pc_dist[xx, yy])
                    elif self.numberofparam == 3:
                        [a_, b_, c_, d_]     	= Engine.ThreeParamModel_extractabcd(self.Ec_dist[xx, yy], self.Pc_dist[xx, yy], self.Pr_dist[xx, yy])
                    else:
                        raise ValueError('Error 104: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')
                    a_eff[xx, yy]               = a_ * self.t_F # I have to multiply tfe for retrocompatibility
                    b_eff[xx, yy]               = b_ * self.t_F
                    c_eff[xx, yy]               = c_ * self.t_F
                    d_eff[xx, yy]               = d_ * self.t_F
                elif self.distr_type == 'distrab':
                    if self.numberofparam == 2:
                        self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Pr_dist[xx, yy] = Engine.TwoParamModel_extractEcPc(a_eff[xx, yy], b_eff[xx, yy])
                    elif self.numberofparam == 3:
                        self.seed.Ec_dist[xx, yy], self.seed.Pc_dist[xx, yy], self.seed.Pr_dist[xx, yy] = Engine.ThreeParamModel_extractEcPc(a_eff[xx, yy], b_eff[xx, yy],  c_eff[xx, yy])
                    else:
                        raise ValueError('Error 105: Number of parameters(alpha, beta, gamma) not supported yet, disp_NORM')

                    a_eff[xx, yy]               = a_eff[xx, yy] * self.t_F # I have to multiply tfe for retrocompatibility
                    b_eff[xx, yy]               = b_eff[xx, yy] * self.t_F
                    c_eff[xx, yy]               = c_eff[xx, yy] * self.t_F
                    d_eff[xx, yy]               = d_eff[xx, yy] * self.t_F
                
                if self.structure_type == 1: #MFIM
                    # calcuclation of starting Polarization
                    P_roots                     = np.roots([8*d_eff[xx, yy].item(), 0, 6*c_eff[xx, yy].item(), 0, 4*b_eff[xx, yy].item(), 0, 2*a_eff[xx, yy].item()+1/(self.C0.item()), -(V_iniz*self.CD/self.C0).item()])
                    P_roots                     = np.real(P_roots[P_roots.imag == 0 ])    # Only real roots
                    
                    P0                          = np.min(P_roots)

                    if V_iniz > 0:
                        P0                      = np.abs(P0)
                    else:
                        P0                      = -np.abs(P0)

                    P_iniz[xx, yy]              = P0; 
                elif self.structure_type == 2: #MIFIM 
                    P_roots                     = np.roots([8*d_eff[xx,yy], 0, 6*c_eff[xx,yy], 0, 4*b_eff[xx,yy], 0, 2*a_eff[xx,yy]+(self.Cs/(self.CF*self.CDS)), -V_iniz*self.Cs/self.CF])
                    P_roots                     = np.real(P_roots[P_roots.imag == 0 ])    # Only real roots
                    P0                          = np.min(P_roots) # ho tolto il valore assoluto per eliminare P=0
                    if V_iniz > 0:
                        P0                      = np.abs(P0)
                    else:
                        P0                      = -np.abs(P0)
                    P_iniz[xx,yy]               = P0
        return a_eff, b_eff, c_eff, d_eff, P_iniz
    
    @torch.no_grad()
    def conv_pickseed_to_mat(self, name_pick, name_mat):
        import numpy, scipy.io
        import pickle, sys
        aa = Seed(self)
        aa               =pickle.load( open( name_pick, "rb" ) )

        tf = aa.t_F.item()
        scipy.io.savemat(name_mat, mdict={"seed" : np.array([aa.a.item()*tf, aa.b.item()*tf, aa.c.item()*tf, aa.d.item()*tf, 0, 0, aa.Vstart, aa.a_eff.cpu().numpy(), aa.b_eff.cpu().numpy(), aa.c_eff.cpu().numpy(), aa.d_eff.cpu().numpy(), aa.Ec_dist.cpu().numpy(), aa.Pc_dist.cpu().numpy(), aa.Pstart.cpu().numpy()])}  )
    
    @torch.no_grad()
    def calculate_charge (self):
        static_charge                           = torch.zeros((self.row*self.col, len(self.V)), dtype=self.precision, device = self.device)
        for i in range(len(self.V)):
            static_charge[:, i]                 = self._get_fix_charge(self, i)

        if self.structure_type == 1:
            self.P_av                           = torch.reshape(self.P, (self.row*self.col, len(self.V))).mean(0)
            self.Qt_av                          = torch.reshape(self.Qt, (self.row*self.col, len(self.V))).mean(0)
            self.Qint                           = self.Qt_av + torch.reshape(static_charge, (self.row*self.col, len(self.V))).mean(0)
            self.Qmf               	            = (self.dd**2) *torch.matmul(self.B, static_charge) + (self.dd**2) * torch.matmul(self.B, torch.reshape(self.Qt, (self.row*self.col, len(self.V)))) + (self.dd**2)*torch.matmul(self.B+1, torch.reshape(self.P, (self.row*self.col, len(self.V)))) + self.V*self.CF*(self.dd**2)
            self.Qmd              	            = (self.dd**2) *torch.matmul(self.D, static_charge) + (self.dd**2) * torch.matmul(self.D, torch.reshape(self.Qt, (self.row*self.col, len(self.V)))) + (self.dd**2)*torch.matmul(self.D+1, torch.reshape(self.P, (self.row*self.col, len(self.V)))) - self.V*self.CF*(self.dd**2)
            self.Qmf                            = self.Qmf/(self.dd**2)/self.row/self.col
            self.Qmd                            = self.Qmd/(self.dd**2)/self.row/self.col
            if self.traps == 0:
                self.Q                          = self.Qmf
            else:
                self.Q                          = None

    @torch.no_grad()
    def calculate_voltagefields(self):
        Presh                                       = torch.reshape(self.P.transpose(0, 1), (self.row*self.col, len(self.V)))
        Qtresh                                      = torch.reshape(self.Qt.transpose(0, 1), (self.row*self.col, len(self.V)))

        static_charge                               = torch.zeros((self.row*self.col, len(self.V)), dtype=self.precision, device = self.device)
        for i in range(len(self.V)):
            static_charge[:, i]                     = self._get_fix_charge(self, i)
        static_charge                               = torch.reshape(static_charge.transpose(0, 1), (self.row*self.col, len(self.V)))
        
        if self.structure_type == 1:
            self.VD                                     = torch.matmul(self.C_coupl.t(), Presh + Qtresh + static_charge) + self.CF/self.C0*(self.V-self.Vfb)
            self.VD                                     = torch.reshape(self.VD, (self.row, self.col, len(self.V))).transpose(0, 1)
            self.VD_av                                  = torch.reshape(self.VD, (self.row*self.col, len(self.V))).mean(0)
            self.Efe_av                                 = self.CD/self.t_F/self.C0*(self.V-self.Vfb) +1/(self.row*self.col*self.eps0*self.epsF)*torch.matmul((Presh + Qtresh + static_charge).t(), self.B);  

    @torch.no_grad()
    def get_tau(self):
        return self.rho/2/torch.abs(self.a)

    @torch.no_grad()
    def transfermemory(self, device):
        for k in dir(self):
            v               = getattr(self, k)
            if type(v) is torch.Tensor:
                setattr(self, k, v.to(device))    


    def download_file(self, url, filepath):
        with requests.get(url, allow_redirects=True) as r:
            with open(filepath, 'wb') as f:
                f.write(r.content)

    def download_structure(self, name):
        conf_url                        = "https://raw.githubusercontent.com/riccardo25/ferro_python/main/MFIM/{:s}/{:s}.conf".format(name, name)
        conf_file                       = "./desc_files/{:s}/{:s}.conf".format(name, name)
        glob_url                        = "https://raw.githubusercontent.com/riccardo25/ferro_python/main/MFIM/{:s}/{:s}.conf_glob.txt".format(name, name)
        glob_file                       = "./desc_files/{:s}/{:s}.conf_glob.txt".format(name, name)
        vmat_url                        = "https://raw.githubusercontent.com/riccardo25/ferro_python/main/MFIM/{:s}/{:s}.conf_vmat.txt".format(name, name)
        vmat_file                       = "./desc_files/{:s}/{:s}.conf_vmat.txt".format(name, name)
        self.download_file(conf_url, conf_file)
        self.download_file(glob_url, glob_file)
        self.download_file(vmat_url, vmat_file)
        
        
        if os.path.exists(conf_file) and os.path.exists(glob_file) and os.path.exists(vmat_file):
            pass      
        else:
            raise UsageError("ERROR 46625: Something went wrong during the downloading of the structure. Contact Riccardo (fontanini.riccardo@spes.uniud.it)")

        

    def linearization(self, index, frequency):
        index                                                   = CHECKTENSOR(index)
        f_pol                                                   = torch.zeros(self.row*self.col, device=self.device, dtype=self.precision)
        f_acc                                                   = torch.zeros(self.row*self.col*self.N_disc_traps, device=self.device, dtype=self.precision)
        f_don                                                   = torch.zeros(self.row*self.col*self.notset_N_disc_traps_don, device=self.device, dtype=self.precision)
        Npt                                                     = torch.numel(f_pol)+ torch.numel(f_acc)+ torch.numel(f_don)
        Ylin                                                    = torch.zeros(Npt, device=self.device, dtype=self.precision)
        Ycompl                                                  = torch.zeros((index.int().item()), device=self.device, dtype=self.precision)
        nc                                                      = torch.zeros((index.int().item()), device=self.device, dtype=self.precision)
        self.Edepth                                             = 5*self.q
        TMD_0                                                   = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), device=self.device, dtype=self.precision)
        TMF_0                                                   = torch.zeros((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), device=self.device, dtype=self.precision)
        TMD                                                     = torch.zeros(((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), Npt), device=self.device, dtype=self.precision)
        TMF                                                     = torch.zeros(((self.row*self.col*torch.ceil(self.Edepth/((self.Emax0-self.Emin0).abs()/self.N_disc_traps))).int().item(), Npt), device=self.device, dtype=self.precision)
        f_var                                                   = torch.zeros((Npt,Npt), device=self.device, dtype=self.precision)
        
        dE                                                      = torch.tensor((self.Emax0 -self.Emin0).abs()/self.N_disc_traps, device=self.device, dtype=self.precision)
        eps                                                     = torch.tensor(1e-6, device=self.device, dtype=self.precision)
        null_v                                                  = torch.tensor([], dtype=self.precision, device=self.device)
        for k in range(0, torch.numel(index)):
            Pol_0                                               = self.P[:, :, index[k].int().item()].transpose(0,1).flatten()
            fixedcharge                                         = self._get_fix_charge(self, k)
            if torch.numel(torch.tensor(self.tr_occ_acc.size())) > 1:                            
                tr_occ_acc_0                                        = self.tr_occ_acc[:, index[k]]
                tr_occ_don_0                                        = self.tr_occ_don[:, index[k]]
            else:

                tr_occ_acc_0                                        = self.tr_occ_acc
                tr_occ_don_0                                        = self.tr_occ_don


            Qt_0                                                = self.Qt[:, :, index[k].int().item()].transpose(0,1).flatten()
            beferro.calc_TMD_TMF(TMD_0, TMF_0, self.row, self.col, self.V[index[k].int().item()], self.VD[:, :, index[k].int().item()].transpose(0,1).flatten(), self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, torch.abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp)
            
            beferro.solver_ntr_dbpm_accanddon(f_acc, null_v, f_don, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, tr_occ_acc_0*self.Nt[0], tr_occ_don_0*self.Nt_don[0], TMD_0, TMF_0, self.row, self.col, self.V[index[k].int().item()], self.VD[:, :, index[k].int().item()].transpose(0,1).flatten(), self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 0)
            static_                                             = self.CpC*(Pol_0+Qt_0+fixedcharge)
            beferro.MFIMsolver(f_pol, Pol_0, self.V[index[k].int().item()], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, 0, self.rho, self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.B, 0, self.structure_type)
            
            f_notvar                                            = torch.cat((f_pol, f_acc, f_don), 0).unsqueeze(-1).repeat(1, Npt)
            
            y_var                                               = torch.cat((Pol_0, tr_occ_acc_0, tr_occ_don_0), 0).unsqueeze(-1).repeat(1, Npt) + eps*torch.eye(Npt, device = self.device, dtype = self.precision)
            Pol                                                 = y_var[0:self.row*self.col,:]
            ntr                                                 = y_var[self.row*self.col:(self.row*self.col+self.row*self.col*self.N_disc_traps), :] *self.Nt[0]
            ptr                                                 = y_var[self.row*self.col+self.row*self.col*self.N_disc_traps:self.row*self.col+self.row*self.col*self.N_disc_traps+self.row*self.col*self.notset_N_disc_traps_don, :] * self.Nt_don[0]
            Qt                                                  = -self.q*torch.reshape(ntr.transpose(0,1), (self.row*self.col, self.N_disc_traps, Npt)).sum(1) + self.q*(self.Nt_don[0]*self.notset_N_disc_traps_don - torch.reshape(ptr.transpose(0,1), (self.row*self.col, self.notset_N_disc_traps_don, Npt)).sum(1))
            Vd                                                  = torch.matmul(self.C_coupl.transpose(0,1), (Pol+fixedcharge.unsqueeze(-1).repeat(1, Npt) +Qt)) + self.CF/self.C0*(self.V[index[k].int().item()]-self.Vfb)
            static_var                                          = torch.matmul(self.CpC, (Pol+Qt+fixedcharge.unsqueeze(-1).repeat(1, Npt)))
            beferro.eval_TMD_TMF(TMD, TMF, self.row, self.col, self.V[index[k].int().item()], Vd, self.t_F, self.t_D, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.Temp, self.N_disc_traps, self.notset_N_disc_traps_don)
            beferro.eval_bigJ_linear(f_var, TMD, TMF, Pol, self.V[index[k].int().item()], static_var, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, self.t_D, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, 0, self.rho, self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.B, 0, self.structure_type, ntr, ptr, Vd, self.WF_B, self.Chi_ox, self.Chi_fe, self.m_eff_fe, self.m_eff_ox, self.Emax0, abs(self.Emax0-self.Emin0)/self.N_disc_traps, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don)
            Jacobian                                            = -(f_var-f_notvar)/eps
            beferro.solver_ntr_dbpm_accanddon(f_acc, null_v, f_don, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, null_v, tr_occ_acc_0*self.Nt[0], tr_occ_don_0*self.Nt_don[0], TMD_0, TMF_0, self.row, self.col, self.V[index[k].int().item()]+eps, self.VD[:, :, index[k].int().item()].transpose(0,1).flatten(), self.WF_B, self.Chi_ox, self.Chi_fe, self.Emax0, dE, self.Edepth, self.N_disc_traps, self.Temp, self.Nt[0], self.sigmaTraps, self.sigmaEnergy, self.Emax0_don, self.Nt_don[0], self.notset_N_disc_traps_don, self.sigmaTraps_don, self.sigmaEnergy_don, 0)
            beferro.MFIMsolver(f_pol, Pol_0, self.V[index[k].int().item()]+eps, static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, 0, self.rho, self.seed.a_eff, self.seed.b_eff, self.seed.c_eff, self.seed.d_eff, self.B, 0, self.structure_type)
            
            #Jacobian for V = df/dV_eps 
            Jacobian_V                                          = (torch.cat([f_pol, f_acc, f_don], 0) - f_notvar[:,0].flatten())/eps

            Jp_an                                               = 1/(self.t_F*self.rho)*((-2*torch.reshape(self.seed.a_eff.transpose(0, 1), ((self.row*self.col).item(), ) ) - 12*torch.reshape(self.seed.b_eff.transpose(0,1), ((self.row*self.col).item(), ) )*(Pol_0+Qt_0)**2-30*torch.reshape(self.seed.c_eff.transpose(0,1), ((self.row*self.col).item(), ) )*(Pol_0 + Qt_0)**4 * torch.eye(Pol_0.shape[0], device=self.device, dtype=self.precision))-0.5*self.CpC)
            
            pdb.set_trace()
            

            dJ                                                  = torch.abs(torch.diag(Jacobian))
            idx                                                 = dJ[dJ<=1e-5]
            Jacobian[idx,:]                                     = []
            Jacobian[:,idx]                                     = []
            Jacobian_V[idx,:]                                   = []
            
            A                                                   = torch.complex(0,1) *2*torch.pi*frequency*torch.eye(Npt)-Jacobian
            
            #MATLAB EQUILIBRATION: P R C equilibration matrices,
            #starting system => Ay=b, A ill-conditioned, use
            #equilibrate to get matrix B which has better rcond(B) and
            #then solve system Bx=d with d = RPb, the starting y will be y=Cx
            
            
            #[P, R, C]                                           = equilibrate(A)
            #
            #B                                                   = gpuArray(R*P*A*C)
            #
            #d                                                   = R*P*Jacobian_V
            #
            #x                                                   = B\d
            
            
            #    Ylin(:,k)                                           = A\(Jacobian_V);
            #    Ylin(:,k)                                           = x;
            #
            #Ylin(:,k)                                           = [C*x; zeros(numel(idx),1)];
            
            Ylin                                                = torch.linalg.lstsq(A, Jacobian_V, rcond=None).solution

            Pol_lin                                             = Ylin[0:self.row*self.col-1, k]
            ntr_lin                                             = Ylin[self.row*self.col:self.row*self.col+self.row*self.col*self.N_disc_traps-1, k]
            ptr_lin                                             = Ylin[self.row*self.col+self.row*self.col*self.N_disc_traps:-1, k]
            
            Iqs_lin                                             = 0
            Pav_lin                                             = torch.mean(Pol_lin)
            ntr_sum                                             = torch.sum(torch.reshape(ntr_lin.transpose(0,1)*self.Nt[0], self.row*self.col, self.N_disc_traps), 1)
            ptr_sum                                             = torch.sum(torch.reshape(ptr_lin.transpose(0,1)*self.Nt_don[0], self.row*self.col, self.notset_N_disc_traps_don), 1)
            Qtav_lin                                            = -self.q*torch.mean(ntr_sum+ptr_sum)
            Ycompl[k]                                           = torch.complex(0,1)*2*torch.pi*frequency*self.CS + torch.complex(0,1)*2*torch.pi*frequency*(self.CD/self.C0*Pav_lin-self.CF/self.C0*Qtav_lin) + Iqs_lin
            nc[k]                                               = 1/torch.linalg.cond(A)
            print(f'Elaboration percentage: {k/torch.numel(index)*100}% -- V(t) = {self.V[index[k]].item()}V')

        return Ycompl, nc


    def linearization_Rollo(self, index, frequency, ntraps):
        self.transfermemory("cuda")
        w                                       = 2*np.pi*frequency

        dummy                                   = torch.zeros((self.row*self.col, self.N_disc_traps), device=self.device, dtype=self.precision)
            
        f_pol                                   = torch.zeros((self.row*self.col), device=self.device, dtype=self.precision)
        f_ntr                                   = torch.zeros((self.row*self.col*self.N_disc_traps), device=self.device, dtype=self.precision)
        Ylin                                    = torch.zeros((torch.numel(f_pol)+torch.numel(f_ntr)), device="cpu", dtype=self.precision)
        flat_av                                 = self.seed.a_eff.transpose(0, 1).flatten().to(self.device)
        flat_bv                                 = self.seed.b_eff.transpose(0, 1).flatten().to(self.device)
        flat_cv                                 = self.seed.c_eff.transpose(0, 1).flatten().to(self.device)
        flat_dv                                 = self.seed.d_eff.transpose(0, 1).flatten().to(self.device)
    
        f_var                                   = torch.zeros((torch.numel(f_pol)+torch.numel(f_ntr), torch.numel(f_pol)+torch.numel(f_ntr)), device="cpu", dtype=self.precision)
        eps                                     = 1e-5
        Pol_0                                   = self.P[:, :, index].transpose(0, 1).flatten()
        Qt_0                                    = self.Qt[:, :, index].transpose(0, 1).flatten()

        ####################################################### DA CAMBIARE QUANDO SALVO TEST DIO SVELTO
        ntr_0                                   = self.ntr.transpose(0, 1).flatten().clone()
        fixedcharge                             = self._get_fix_charge(self, index)
        static_                                 = torch.mv(self.CpC, Pol_0+Qt_0+fixedcharge)
        beferro.MFIMsolver(f_pol, Pol_0, self.V[index], static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, self.CDS, self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)
        f_pol0                                  = -f_pol.cpu().clone()
        pdb.set_trace()
        Vd0                                    = torch.mv(self.C_coupl.transpose(0, 1), Pol_0+fixedcharge+Qt_0) + self.CF/self.C0*(self.V[index]-self.Vfb)
        beferro.solver_ntr(f_ntr, dummy, dummy, Pol_0, Vd0, self.row, self.col, ntr_0, self.en0, self.Nt, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.N_disc_traps, self.Temp)
        f_ntr0                                  = f_ntr.cpu().clone()
        f_notvar                                = torch.cat((f_pol0, self.q*f_ntr0), 0).unsqueeze(-1).repeat(1, int((self.row*self.col*(1+self.N_disc_traps))))
        y_var                                   = torch.cat(  (Pol_0, ntr_0.flatten()/self.Nt[0]), 0 ).cpu().unsqueeze(-1).repeat(1, int((self.row*self.col*(1+self.N_disc_traps)))) \
                                                        +  eps*torch.eye(int((self.row*self.col*(1+self.N_disc_traps))))
        for r in range (0, int((self.row*self.col*(1+self.N_disc_traps)))):
            Pol                                 = y_var[ :self.row*self.col, r].to(self.device)
            ntr                                 = (self.Nt[0]*torch.reshape(y_var[self.row*self.col:, r], (self.N_disc_traps, self.row*self.col)).to(self.device)).transpose(0, 1)
            Qt                                  = -self.q*ntr.sum(1)
            static_var                          = torch.mv(self.CpC, Pol+Qt+fixedcharge)
            Vd                                  = torch.mv(self.C_coupl.t(), Pol+fixedcharge+Qt) + self.CF/self.C0*(self.V[index]-self.Vfb)


            beferro.solver_ntr(f_ntr, dummy, dummy, Pol, Vd, self.row, self.col, ntr, self.en0, self.Nt, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.N_disc_traps, self.Temp)
            beferro.MFIMsolver(f_pol, Pol, self.V[index], static_var, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_F, fixedcharge, self.Vfb, self.CD, self.C0, self.CS, self.CDS, self.rho*self.t_F, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)
            f_var[:, r]                         = torch.cat((-f_pol, self.q*f_ntr), 0).cpu().clone()
        
        pdb.set_trace()
        Jacobian                                = (f_var-f_notvar)/eps

        #SIAMO ARRIVATI QUI
        mjt                                     = torch.max(Jacobian[self.row*self.col:, :].abs(), 1).unsqueeze(-1).transpose(0, 1)
        
        mjt_sorted, id_sort                     = torch.sort(mjt)
        
        idmax                                   = id_sort[-ntraps+1:, 1]+self.row*self.col
        idmin                                   = id_sort[:-ntraps, 1]+self.row*self.col
        
        Jacobian_remcol                         = np.delete(Jacobian, idmin, 1)
        Jacobian_small                          = np.delete(Jacobian_remcol, idmin, 0)
        Vd_V                                    = torch.mv(self.C_coupl.transpose(0, 1), Pol+fixedcharge+Qt) + self.CF/self.C0*(self.V[index]+eps-self.Vfb)
        beferro.solver_ntr(f_ntr, dummy, dummy, Pol_0, Vd_V, self.row, self.col, ntr, self.en0, self.Nt, self.WF_B, self.Chi_ox, self.Emin0, self.Emax0, self.N_disc_traps, self.Temp)
        beferro.solver_MFIM(f_pol, Pol_0, self.V(index)+eps, static_, self.row, self.col, self.k_coupl, self.dd, self.w, self.t_fe, fixedcharge, self.Vfb, self.CD, self.C0, self.Cs, self.CDS, self.rhov, flat_av, flat_bv, flat_cv, flat_dv, self.B, int(1), self.structure_type)
        Jacobian_V                              = (torch.cat((-f_pol, self.q*f_ntr)) - f_notvar[:, 1])/eps
        
        Jacobian_V_small                        = np.delete(Jacobian_V, idmin, 0)
        
        A                                       = (torch.tensor(1j)*w*torch.eye(Jacobian_small.size(0).int())-Jacobian_small)
        sol                                     = torch.linalg.lstsq(A, Jacobian_V_small, rcond=None).solution
        Ylin[:self.row*self.col]                = sol[:self.row*self.col]
        
        Ylin[idmax]                             = sol[self.row*self.col:]
        
        Pav_lin                                 = torch.mean(Ylin[:self.row*self.col])
        ntr_lin                                 = torch.reshape(Ylin[self.row*self.col:], self.row*self.col, self.N_disc_traps)
        Qtav_lin                                = -torch.mean(ntr_lin.sum(1))
        Ylin                                    = torch.tensor(1j)*w*self.Cs + torch.tensor(1j)*w*(self.CD/self.C0*Pav_lin-self.CF/self.C0*Qtav_lin)
        
        nc                                      = 1/torch.linalg.cond(A)





        return Ylin, nc
        
        
      